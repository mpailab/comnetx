#!/usr/bin/env python3
"""Convert downloaded TGC text files into the format used by Dataset.

The four ``dyn_*`` datasets in ``data/`` are already packaged as NPZ files.
Patent and arxivmath are distributed as text edge/feature/label files and need
the joblib representation consumed by ``src/datasets.py``.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
INFO = ROOT / "datasets-info" / "json" / "tgc.json"
BATCH_COUNTS = (1, 10, 100, 1000)


def load_labels(path: Path, num_nodes: int) -> np.ndarray:
    mapping = np.loadtxt(path, dtype=np.int64)
    if mapping.ndim != 2 or mapping.shape[1] < 2:
        raise ValueError(f"unexpected label format: {path}")
    labels = np.full(num_nodes, -1, dtype=np.int64)
    labels[mapping[:, 0]] = mapping[:, 1]
    if np.any(labels < 0):
        missing = int(np.count_nonzero(labels < 0))
        raise ValueError(f"{path}: {missing} vertices have no label")
    _, labels = np.unique(labels, return_inverse=True)
    return labels.astype(np.int64, copy=False)


def convert_dataset(name: str, overwrite: bool = False) -> None:
    metadata = json.loads(INFO.read_text(encoding="utf-8"))[name]
    num_nodes = int(metadata["n"])
    dataset_dir = DATA / name
    edge_path = dataset_dir / f"{name}.txt"
    feature_text = dataset_dir / "feature.txt"
    label_text = dataset_dir / "node2label.txt"

    required = (edge_path, feature_text, label_text)
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("missing input files: " + ", ".join(missing))

    feature_path = dataset_dir / f"{name}_feat.npy"
    label_path = dataset_dir / f"{name}_label.npy"
    outputs = [
        dataset_dir / f"{name}_coo_adj-{count}_batches.joblib"
        for count in BATCH_COUNTS
    ]
    if not overwrite and feature_path.exists() and label_path.exists() and all(
        path.exists() for path in outputs
    ):
        print(f"{name}: already prepared")
        return

    print(f"{name}: loading features")
    features = np.loadtxt(feature_text, dtype=np.float32)
    if features.shape[0] != num_nodes:
        raise ValueError(
            f"{name}: feature rows={features.shape[0]}, expected {num_nodes}"
        )
    np.save(feature_path, features)
    del features

    labels = load_labels(label_text, num_nodes)
    np.save(label_path, labels)

    print(f"{name}: loading and sorting edges")
    edges = np.loadtxt(edge_path, dtype=np.float64)
    if edges.ndim != 2 or edges.shape[1] < 3:
        raise ValueError(f"unexpected edge format: {edge_path}")
    if edges.shape[0] != int(metadata["m"]):
        raise ValueError(
            f"{name}: edge rows={edges.shape[0]}, expected {metadata['m']}"
        )
    order = np.argsort(edges[:, 2], kind="stable")
    source = edges[order, 0].astype(np.int64, copy=False)
    target = edges[order, 1].astype(np.int64, copy=False)
    if source.min() < 0 or target.min() < 0:
        raise ValueError(f"{name}: negative vertex id")
    if source.max() >= num_nodes or target.max() >= num_nodes:
        raise ValueError(f"{name}: vertex id exceeds declared node count")
    edge_count = source.size

    for count, output in zip(BATCH_COUNTS, outputs):
        batch = np.arange(edge_count, dtype=np.int64) * count // edge_count
        payload = {
            "indices": np.vstack((batch, source, target)),
            "values": np.ones(edge_count, dtype=np.float32),
            "shape": (count, num_nodes, num_nodes),
        }
        joblib.dump(payload, output, compress=3)
        print(f"{name}: wrote {output.relative_to(ROOT)}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "datasets",
        nargs="*",
        default=None,
        choices=["patent", "arxivmath"],
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    for dataset in (args.datasets or ["patent", "arxivmath"]):
        convert_dataset(dataset, overwrite=args.overwrite)


if __name__ == "__main__":
    main()
