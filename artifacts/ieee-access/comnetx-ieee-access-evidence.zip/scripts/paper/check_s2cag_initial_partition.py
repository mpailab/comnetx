#!/usr/bin/env python3
"""Score the unchanged initial Leiden partition on each final S2CAG snapshot.

From the repository root, run
    python scripts/paper/check_s2cag_initial_partition.py --data-dir data
to reconstruct both final graphs and check the saved control and terminal scores.
Without --data-dir, verify the published score identities and archived inputs.
Pass --write with --data-dir to regenerate the JSON. No detector is executed.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from export_s2cag_provenance import digest, read_json, require, tensor_hash

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / 'results/ieee-access-2026-4'
PROVENANCE = RESULTS / 's2cag-paired-20261105/provenance'
OUTPUT = RESULTS / 's2cag-initial-partition-control.json'
DATASETS = ('dyn_pubmed', 'arxivmath')


def load_final(data_dir, dataset, n):
    directory = data_dir / dataset
    if dataset == 'dyn_pubmed':
        with np.load(directory / 'dynamic_pubmed-1000_batches.npz') as graph:
            src, dst = graph['indices']
            weights = graph['values']
        with np.load(directory / 'feat_pubmed-1000_batches.npz') as features:
            reference = features['labels']
    else:
        src, dst = np.loadtxt(directory / 'arxivmath.txt', usecols=(0, 1), dtype=np.int64).T
        weights = np.ones(src.size, dtype=np.float32)
        vertices, raw_labels = np.loadtxt(directory / 'node2label.txt', dtype=np.int64).T
        require(np.array_equal(np.sort(vertices), np.arange(n)), 'Incomplete ArxivMath label mapping')
        # The paired campaign hashed the original TGC class IDs (81 through 111).
        reference = raw_labels[np.argsort(vertices)]
    require(reference.shape == (n,) and min(src.min(), dst.min()) >= 0
            and max(src.max(), dst.max()) < n, f'Invalid vertex indices: {dataset}')
    # The undirected loader adds each record and its transpose. Coalesce in
    # row-major order to reproduce the exact bytes hashed by the paired runner.
    keys, inverse = np.unique(np.r_[src*n + dst, dst*n + src], return_inverse=True)
    values = np.bincount(inverse, weights=np.tile(weights, 2)).astype(np.float32)
    indices = np.stack((keys // n, keys % n))
    fingerprint = hashlib.sha256((str((n, n)) + 'torch.float32').encode())
    fingerprint.update(memoryview(indices).cast('B'))
    fingerprint.update(memoryview(values).cast('B'))
    return indices, values, reference, fingerprint.hexdigest()


def entropy(counts):
    probabilities = counts / counts.sum()
    return float(-np.sum(probabilities * np.log(probabilities)))


def scores(stats):
    weight = stats['total_adjacency_weight']
    q = stats['within_group_weight'] / weight - stats['sum_squared_group_strengths'] / weight**2
    entropy_sum = stats['group_entropy'] + stats['reference_entropy']
    nmi = 2 * stats['mutual_information'] / entropy_sum if entropy_sum else 1.0
    return {'modularity': round(q, 12), 'nmi': round(nmi, 12)}


def score_labels(graph, labels):
    (rows, cols), values, reference, _ = graph
    _, groups, group_counts = np.unique(labels, return_inverse=True, return_counts=True)
    _, classes, class_counts = np.unique(reference, return_inverse=True, return_counts=True)
    strengths = np.bincount(groups[rows], weights=values)
    width = len(class_counts)
    pair, joint = np.unique(groups * width + classes, return_counts=True)
    n = len(reference)
    mi = np.sum((joint / n) * np.log((joint.astype(float) * n) /
                                     (group_counts[pair // width] * class_counts[pair % width])))
    stats = {
        'total_adjacency_weight': float(values.sum(dtype=np.float64)),
        'within_group_weight': float(values[groups[rows] == groups[cols]].sum(dtype=np.float64)),
        'sum_squared_group_strengths': float(strengths @ strengths),
        'group_entropy': round(entropy(group_counts), 14),
        'reference_entropy': round(entropy(class_counts), 14),
        'mutual_information': round(float(mi), 14),
    }
    return stats, scores(stats)


def saved_array(manifest, logical_path, expected_sha, key):
    entry = manifest['npz_files'][logical_path]
    path = PROVENANCE / entry['object']
    require(entry['sha256'] == expected_sha == digest(path), f'Archive checksum mismatch: {logical_path}')
    with np.load(path) as source:
        return source[key]


def check_dataset(dataset, manifest, data_dir, stored):
    initial = read_json(PROVENANCE / 'initial' / f'{dataset}__p999.json')
    hierarchy = saved_array(manifest, f'initial/{dataset}__p999.npz', initial['file_sha256'], 'hierarchy')
    labels = hierarchy[0]
    initial_hash = tensor_hash(labels)
    require(initial_hash == initial['fine_partition_sha256'], f'Initial labels mismatch: {dataset}')
    groups = np.unique(labels).size
    require(groups == initial['community_counts'][0], f'Initial group count mismatch: {dataset}')
    if data_dir is None:
        stats = stored['score_components']
        graph = None
        ref_hash = stored['reference_labels_sha256']
        snapshot = stored['final_snapshot_sha256']
    else:
        graph = load_final(data_dir, dataset, len(labels))
        ref_hash = tensor_hash(graph[2])
        snapshot = graph[3]
        stats, _ = score_labels(graph, labels)
    result = {
        'nodes': len(labels), 'nonempty_groups': groups, 'initial_fine_partition_sha256': initial_hash,
        'reference_labels_sha256': ref_hash, 'final_snapshot_sha256': snapshot,
        'score_components': stats, **scores(stats), 'terminal_checks': {},
    }
    for q in (5, 10):
        protocol = f'999:{q}'
        modes = result['terminal_checks'][protocol] = {}
        for mode in ('full', 'local'):
            for rep in range(1, 6):
                pair = f'{dataset}__random__999-{q}__r{rep:02d}'
                record = read_json(PROVENANCE / 'pairs' / pair / f'{mode}.json')
                end = record['rows'][-1]
                require(record['job']['pair_id'] == pair and record['mode'] == mode
                        and record['initial']['fine_partition_sha256'] == initial_hash
                        and record['input']['reference_labels'] == ref_hash
                        and end['snapshot_sha256'] == snapshot and end['update'] == q,
                        f'Endpoint/input mismatch: {pair}/{mode}')
                terminal = saved_array(manifest, end['label_file'], end['label_file_sha256'], 'labels')
                require(tensor_hash(terminal) == end['label_sha256'] and terminal.shape == labels.shape,
                        f'Terminal partition mismatch: {pair}/{mode}')
                if rep == 1:
                    if graph is None:
                        measured = stored['terminal_checks'][protocol][mode]
                        quality = {metric: measured[metric] for metric in ('modularity', 'nmi')}
                    else:
                        _, quality = score_labels(graph, terminal)
                    modes[mode] = dict(label_sha256=end['label_sha256'], nonempty_groups=np.unique(terminal).size,
                                       **quality)
                item = modes[mode]
                require(end['label_sha256'] == item['label_sha256'] and end['nonempty_groups'] == item['nonempty_groups']
                        and math.isclose(end['modularity'], item['modularity'], rel_tol=0, abs_tol=1e-6)
                        and math.isclose(end['nmi'], item['nmi'], rel_tol=0, abs_tol=1e-12),
                        f'Terminal score/label mismatch: {pair}/{mode}')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--data-dir', type=Path, help='Directory containing dyn_pubmed/ and arxivmath/.')
    parser.add_argument('--write', action='store_true', help='Regenerate the published JSON from graph inputs.')
    args = parser.parse_args()
    if args.write and args.data_dir is None:
        parser.error('--write requires --data-dir')
    stored = {} if args.write else read_json(OUTPUT)
    manifest = read_json(PROVENANCE / 'MANIFEST.json')
    result = {
        'schema': 's2cag-initial-partition-control-v1',
        'provenance': str(PROVENANCE.relative_to(ROOT)),
        'provenance_manifest_sha256': digest(PROVENANCE / 'MANIFEST.json'),
        'definition': 'Keep row 0 of the shared initial Leiden hierarchy through all updates. Score it on the final weighted undirected graph at resolution 1. NMI uses the arithmetic mean of the two entropies.',
        'terminal_checks_per_mode_and_protocol': 5,
        'datasets': {},
    }
    for dataset in DATASETS:
        result['datasets'][dataset] = check_dataset(dataset, manifest, args.data_dir,
                                                    stored.get('datasets', {}).get(dataset))
    if args.write:
        OUTPUT.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    else:
        require(result == stored, 'Control JSON differs from the reconstructed values or archived identities')
    print(json.dumps({dataset: {k: v for k, v in row.items() if k in ('modularity', 'nmi', 'nonempty_groups')}
                      for dataset, row in result['datasets'].items()}))


if __name__ == '__main__':
    main()
