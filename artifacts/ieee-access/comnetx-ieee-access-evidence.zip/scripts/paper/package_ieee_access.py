#!/usr/bin/env python3
"""Build and verify clean IEEE Access manuscript and source/evidence archives.

No experiment or generator is run here. Selection is an explicit allowlist;
optional third-party implementations are replaced by descriptive import stubs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
JOURNAL = Path('journal/ieee-access')
MANIFEST = 'ARTIFACT-MANIFEST.json'
OPTIONAL_ADAPTERS = {
    's2cag': 's2cag', 'magi_model': 'magi', 'mfc': 'mfc_adopted',
    'rough_PRGPT': 'rough_prgpt', 'flmig': 'flmig_adopted', 'dmon': 'adapted_dmon',
}
SCRIPT_NAMES = {
    'launch.py', 'paper/package_ieee_access.py', 'paper/build_ieee_access.sh',
    'paper/profile_smart_workload.py', 'paper/prepare_local_data.py',
    'paper/collect_hardware_info.py', 'paper/audit_adapter_invariants.py',
    'paper/audit_stream_invariants.py',
    'paper/check_core_leiden.py',
    'paper/run_s2cag.sh', 'paper/run_s2cag_pairs.py',
}
OPTIONAL_SCRIPT_NAMES = {'paper/prepare_static_streams.py'}
ANALYSIS_NAMES = {
    'validate_results.py', 'current_results.py', 'extended_results.py',
    'submission_audit.py', 'validated_results.json', 'measurement_ledger.csv',
    'submission_audit_results.json', 'structural_results.py',
    'measurement_manifest.json',
}
PRIVATE_PATH = re.compile(rb'/(?:Users|home)/|[A-Za-z]:\\(?:Users)\\')
TEXT_SUFFIXES = {'.py', '.sh', '.md', '.json', '.csv', '.tex', '.bib', '.txt', '.yml', '.yaml'}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_member(name: str, data: bytes) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name:
        raise ValueError(f'Unsafe archive name: {name}')
    forbidden = {'.git', '.venv', '__pycache__', '.pytest_cache', 'tmp', 'data', 'article'}
    if any(part in forbidden or part.startswith('.venv') for part in path.parts):
        raise ValueError(f'Excluded directory entered archive: {name}')
    if name.endswith('.pyc') or path.name == '.DS_Store':
        raise ValueError(f'Cache entered archive: {name}')
    if path.suffix in TEXT_SUFFIXES and PRIVATE_PATH.search(data):
        raise ValueError(f'Private machine path in {name}; correct the source or selection')


def read_file(root: Path, relative: Path) -> bytes:
    source = root / relative
    if source.is_symlink() or not source.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Symlink or escaping input is not packaged: {relative}')
    if not source.is_file():
        raise FileNotFoundError(source)
    data = source.read_bytes()
    validate_member(relative.as_posix(), data)
    return data


def manuscript_files(root: Path) -> dict[str, bytes]:
    files = {}
    def add(relative):
        relative = Path(relative)
        files[relative.as_posix()] = read_file(root, relative)
    for name in ('main.tex', 'references.bib', 'requirements.txt'):
        add(JOURNAL / name)
    extensions = {'.cls', '.bst', '.sty', '.fd', '.map', '.tfm', '.pfb', '.png'}
    for source in sorted((root / JOURNAL).iterdir()):
        if source.is_file() and source.suffix in extensions:
            add(source.relative_to(root))
    source = files[(JOURNAL / 'main.tex').as_posix()].decode()
    for name in re.findall(r'\\input\{([^}]+)\}', source):
        add(JOURNAL / name)
    for name in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}', source):
        add(JOURNAL / 'figures' / name)
    return files


def optional_stub(module: str, function: str) -> bytes:
    return (
        '"""Placeholder generated for the clean journal distribution.\n\n'
        'The original optional adapter remains in the authors\' local workspace.\n'
        'See docs/third-party-components.md and docs/external-components.json.\n"""\n\n'
        f'def {function}(*args, **kwargs):\n'
        '    raise ImportError(\n'
        f'        "Optional backend {module} is not distributed in this clean artifact. "\n'
        '        "Its external implementation/adapted wrapper must be obtained separately "\n'
        '        "with documented permission and revision; see docs/third-party-components.md."\n'
        '    )\n'
    ).encode()


def evidence_files(root: Path, source_files: dict[str, bytes]) -> tuple[dict[str, bytes], list[str]]:
    files = dict(source_files)
    generated = []
    def add(relative):
        relative = Path(relative)
        files[relative.as_posix()] = read_file(root, relative)
    for name in ('README.md', 'LICENSE', 'Makefile', '.gitignore', '.gitattributes'):
        add(name)
    for folder, pattern in [('src', '*.py'), ('test/unit', '*.py'), ('conf', '*.json'),
                            ('docs', '*'), ('requirements', '*.txt'), ('datasets-info/json', '*.json')]:
        for source in sorted((root / folder).rglob(pattern)):
            if source.is_file() and '__pycache__' not in source.parts:
                relative = source.relative_to(root)
                if relative.parent == Path('src/baselines') and relative.stem in OPTIONAL_ADAPTERS:
                    continue
                add(relative)
    for module, function in OPTIONAL_ADAPTERS.items():
        name = f'src/baselines/{module}.py'
        files[name] = optional_stub(module, function)
        generated.append(name)
    add('test/test_devcontainer_smoke.py')
    add('test/pytest.ini')
    add('datasets-info/paths/local.json')
    for name in sorted(SCRIPT_NAMES):
        add(Path('scripts') / name)
    for name in sorted(OPTIONAL_SCRIPT_NAMES):
        if (root / 'scripts' / name).is_file():
            add(Path('scripts') / name)
    for name in sorted(ANALYSIS_NAMES):
        add(JOURNAL / 'analysis' / name)
    history = sorted((root / 'results/ieee-access-2026-2').glob('*.json'))
    if len(history) != 26:
        raise ValueError('Expected 26 immutable historical JSON files; review selection before changing this count')
    for source in history:
        add(source.relative_to(root))
    diagnostics = root / 'results/ieee-access-2026-3/structural-diagnostics'
    if not (diagnostics / 'scope-sizes.json').is_file():
        raise FileNotFoundError('The current structural diagnostics are required')
    for source in sorted(diagnostics.rglob('*')):
        if source.is_file() and source.suffix in {'.json', '.md', '.txt', '.csv', '.npz'}:
            add(source.relative_to(root))
    return files, generated


def write_archive(path: Path, files: dict[str, bytes], kind: str, generated=()) -> dict:
    for name, data in files.items():
        validate_member(name, data)
    manifest = {
        'schema_version': 1, 'artifact': kind,
        'files_sha256': {name: sha256(data) for name, data in sorted(files.items())},
        'generated_optional_backend_stubs': sorted(generated),
        'policy': 'Explicit clean allowlist; no datasets/environments/private paths/internal review notes; optional external sources excluded.',
    }
    payload = dict(files)
    payload[MANIFEST] = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payload.items()):
            item = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if name.endswith('.sh') else 0o644
            item.external_attr = mode << 16
            archive.writestr(item, data)
    return verify_archive(path)


def verify_archive(path: Path) -> dict:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate archive entries')
        manifest = json.loads(archive.read(MANIFEST))
        expected = manifest['files_sha256']
        if set(names) != set(expected) | {MANIFEST}:
            raise ValueError('Archive members differ from manifest')
        for name, digest in expected.items():
            data = archive.read(name)
            validate_member(name, data)
            if sha256(data) != digest:
                raise ValueError(f'SHA256 mismatch: {name}')
    return {'archive': path.name, 'files': len(expected), 'sha256': sha256(path.read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'output/submission')
    parser.add_argument('--dry-run', action='store_true', help='Inspect the selection without writing archives')
    parser.add_argument('--verify', type=Path, help='Verify an already-created archive')
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify_archive(args.verify), indent=2))
        return
    root = args.root.resolve()
    source = manuscript_files(root)
    evidence, stubs = evidence_files(root, source)
    source['README.txt'] = (
        'IEEE Access manuscript source. Compile journal/ieee-access/main.tex with '
        'pdfLaTeX, BibTeX, then pdfLaTeX twice from that directory. '
        'Template resources are preserved for manuscript preparation. '
        'The separate evidence archive contains the generator, ComNetX core, tests and records.\n'
    ).encode()
    if args.dry_run:
        print(json.dumps({'source_files': len(source), 'evidence_files': len(evidence),
                          'optional_backend_stubs': stubs, 'selected_paths': sorted(evidence)}, indent=2))
        return
    reports = [
        write_archive(args.output_dir / 'comnetx-ieee-access-source.zip', source, 'manuscript-source'),
        write_archive(args.output_dir / 'comnetx-ieee-access-evidence.zip', evidence, 'source-evidence-code', stubs),
    ]
    (args.output_dir / 'SHA256SUMS').write_text(''.join(f"{r['sha256']}  {r['archive']}\n" for r in reports))
    print(json.dumps(reports, indent=2))


if __name__ == '__main__':
    main()
