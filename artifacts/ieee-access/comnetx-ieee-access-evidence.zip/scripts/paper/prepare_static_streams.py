#!/usr/bin/env python3
"""Replay the four archived static-graph streams from public source arrays.

The saved canonical-edge permutations preserve the observed stream order. They
do not reconstruct the unknown RNG that originally produced that order. Every
output array and metadata field is checked against docs/dataset-inputs.json
before any file is written. Compressed NPZ file bytes need not match the
historical archives; their uncompressed arrays and metadata must match exactly.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "docs" / "dataset-inputs.json"
DATASETS = ("cora", "acm", "citeseer", "pubmed")
BATCH_COUNTS = (1, 10, 100, 1000)


def array_hash(array: np.ndarray) -> str:
    return hashlib.sha256(array.tobytes(order="C")).hexdigest()


def check_array(array: np.ndarray, expected: dict, description: str) -> None:
    if (
        list(array.shape) != expected["shape"]
        or array.dtype.str != expected["dtype"]
        or array_hash(array) != expected["sha256_c_order_bytes"]
    ):
        raise ValueError(f"{description}: array differs from the archived input")


def canonical_edges(edges: np.ndarray, num_nodes: int) -> np.ndarray:
    """Return sorted unique directed edges without discarding self-loops."""
    edges = np.asarray(edges, dtype=np.int64)
    if edges.ndim != 2 or edges.shape[1] != 2 or not len(edges):
        raise ValueError("expected a nonempty two-column edge array")
    if edges.min() < 0 or edges.max() >= num_nodes:
        raise ValueError("edge endpoint outside the source vertex range")
    return np.unique(edges, axis=0)


def load_adgc(name: str, source_dir: Path):
    """Read the checked Cora/ACM/Citeseer distribution after extraction."""
    adjacency = np.load(source_dir / f"{name}_adj.npy", allow_pickle=False)
    features = np.load(source_dir / f"{name}_feat.npy", allow_pickle=False)
    labels = np.load(source_dir / f"{name}_label.npy", allow_pickle=False)
    if adjacency.ndim != 2 or adjacency.shape[0] != adjacency.shape[1]:
        raise ValueError(f"{name}: source adjacency must be square")
    nonzero = adjacency != 0
    np.fill_diagonal(nonzero, False)
    if not np.array_equal(nonzero, nonzero.T):
        raise ValueError(f"{name}: source topology is not symmetric")
    edges = np.argwhere(np.triu(nonzero, k=1)).astype(np.int64)
    return edges, features.astype(np.float32), labels.astype(np.int64).reshape(-1)


def load_pubmed(source_dir: Path):
    """Read the exact PyG AttributedGraphDataset PubMed distribution.

    The source contains a SciPy CSR NPZ. Reading its documented arrays directly
    keeps this preparation step dependent on NumPy alone. Duplicate CSR entries,
    if present, are summed in source precision before conversion to float32.
    """
    with np.load(source_dir / "attrs.npz", allow_pickle=False) as sparse:
        if sparse["format"].item() != b"csr":
            raise ValueError("PubMed attrs.npz must contain a CSR matrix")
        shape = tuple(int(value) for value in sparse["shape"])
        indptr = sparse["indptr"]
        columns = sparse["indices"]
        values = sparse["data"]
    if (
        len(shape) != 2
        or indptr.shape != (shape[0] + 1,)
        or indptr[0] != 0
        or indptr[-1] != len(values)
        or len(columns) != len(values)
        or np.any(np.diff(indptr) < 0)
        or np.any(columns < 0)
        or np.any(columns >= shape[1])
    ):
        raise ValueError("PubMed attrs.npz has invalid CSR arrays")
    dense = np.zeros(shape, dtype=values.dtype)
    rows = np.repeat(np.arange(shape[0]), np.diff(indptr))
    np.add.at(dense, (rows, columns), values)
    features = dense.astype(np.float32)

    raw_labels = np.loadtxt(source_dir / "labels.txt", dtype=np.int64, ndmin=2)
    if raw_labels.shape != (shape[0], 2) or not np.array_equal(
        raw_labels[:, 0], np.arange(shape[0])
    ):
        raise ValueError("PubMed labels must be in source vertex order")
    labels = raw_labels[:, 1] - 1
    raw_edges = np.loadtxt(source_dir / "edgelist.txt", dtype=np.int64, ndmin=2)
    return canonical_edges(raw_edges, shape[0]), features, labels


def apply_permutation(edges: np.ndarray, permutation: np.ndarray) -> np.ndarray:
    if (
        permutation.ndim != 1
        or permutation.dtype.kind not in "iu"
        or len(permutation) != len(edges)
        or not np.array_equal(np.sort(permutation), np.arange(len(edges)))
    ):
        raise ValueError("saved stream order must be a complete edge permutation")
    return edges[permutation]


def build_payloads(
    name: str,
    ordered_edges: np.ndarray,
    features: np.ndarray,
    labels: np.ndarray,
    num_batches: int,
):
    """Create the historical NPZ schema, including paired undirected bins."""
    if num_batches < 1:
        raise ValueError("num_batches must be positive")
    if features.ndim != 2 or labels.shape != (features.shape[0],):
        raise ValueError("features and labels must have the same vertex count")
    directed = name == "pubmed"
    ordered_edges = np.asarray(ordered_edges, dtype=np.int64)
    num_edges = len(ordered_edges)
    canonical_edges(ordered_edges, features.shape[0])
    counts = np.full(num_batches, num_edges // num_batches, dtype=np.int64)
    counts[: num_edges % num_batches] += 1
    batches = np.repeat(np.arange(num_batches, dtype=np.int64), counts)
    edges = ordered_edges
    if not directed:
        if np.any(ordered_edges[:, 0] >= ordered_edges[:, 1]):
            raise ValueError("undirected source order must contain upper-triangle edges")
        edges = np.concatenate((ordered_edges, ordered_edges[:, ::-1]), axis=0)
        batches = np.tile(batches, 2)

    def integer(value):
        return np.array([value], dtype=np.int64)

    dynamic = {
        "indices": edges.T.copy(),
        "values": np.ones(len(edges), dtype=np.float32),
        "batch_indices": batches,
        "num_batches": integer(num_batches),
        "num_nodes": integer(features.shape[0]),
        "batch_size_approx": integer(num_edges // num_batches),
        "dataset_name": np.array([name]),
        "is_directed": np.array([directed], dtype=np.bool_),
        # Retain historical metadata; no RNG is invoked during replay.
        "seed": integer(42),
        "original_source": np.array(["attr_graphs" if directed else "small_graphs"]),
        "feat_dim": integer(features.shape[1]),
        "num_classes": integer(len(np.unique(labels))),
    }
    attributes = {
        "num_nodes": integer(features.shape[0]),
        "num_batches": integer(num_batches),
        "features": np.asarray(features, dtype=np.float32),
        "labels": np.asarray(labels, dtype=np.int64),
    }
    return dynamic, attributes


def check_payload(payload: dict, expected: dict) -> None:
    specs = {**expected["arrays"], **expected["metadata_specs"]}
    if set(payload) != set(specs):
        raise ValueError(f"{expected['path']}: NPZ members differ from the archive")
    for name, spec in specs.items():
        check_array(payload[name], spec, f"{expected['path']}:{name}")


def replay_dataset(
    name: str,
    source_dir: Path,
    output_dir: Path,
    manifest: dict,
    overwrite: bool = False,
):
    if name == "pubmed":
        edges, features, labels = load_pubmed(source_dir)
    else:
        edges, features, labels = load_adgc(name, source_dir)
    expected_order = manifest["stream_order"]["permutations"][f"dyn_{name}"]
    check_array(edges, expected_order["canonical_edges"], f"{name}:source topology")
    order_path = ROOT / expected_order["path"]
    if hashlib.sha256(order_path.read_bytes()).hexdigest() != expected_order["sha256"]:
        raise ValueError(f"{name}: saved permutation file hash mismatch")
    permutation = np.load(order_path, allow_pickle=False)
    check_array(permutation, expected_order["array"], f"{name}:permutation")
    ordered = apply_permutation(edges, permutation)
    expected_files = {item["path"]: item for item in manifest["files"]}

    outputs = []
    # Validate all eight payloads before changing any output file.
    for count in BATCH_COUNTS:
        dynamic, attributes = build_payloads(name, ordered, features, labels, count)
        for prefix, payload in (("dynamic", dynamic), ("feat", attributes)):
            relative = f"data/dyn_{name}/{prefix}_{name}-{count}_batches.npz"
            expected = expected_files[relative]
            check_payload(payload, expected)
            path = output_dir / f"dyn_{name}" / Path(relative).name
            if path.exists() and not overwrite:
                with np.load(path, allow_pickle=False) as existing:
                    check_payload(dict(existing), expected)
            else:
                outputs.append((path, payload, expected))

    for path, payload, expected in outputs:
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(path, **payload)
        with np.load(path, allow_pickle=False) as saved:
            check_payload(dict(saved), expected)
    print(f"{name}: verified eight NPZ payloads; wrote {len(outputs)} files")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in DATASETS:
        parser.add_argument(f"--{name}", type=Path, help=f"extracted {name} source directory")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "data")
    parser.add_argument("--manifest", type=Path, default=MANIFEST)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    selected = [(name, getattr(args, name)) for name in DATASETS if getattr(args, name)]
    if not selected:
        parser.error("provide at least one extracted source directory")
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 2:
        parser.error("the dataset manifest must use schema version 2")
    for name, source_dir in selected:
        replay_dataset(name, source_dir, args.output_dir, manifest, args.overwrite)


if __name__ == "__main__":
    main()
