#!/usr/bin/env python3
"""Export and verify portable paired S2CAG evidence without running detectors.

Only environment executable/BLAS paths are reduced to basenames. Original
JSON hashes and changed JSON pointers preserve the transformation record.
Saved label/hierarchy NPZ files are deduplicated by their original byte hashes.
The original campaign and optional execution sources are never modified.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
from statistics import mean, median
import tempfile
import zipfile

import numpy as np

SCHEMA = 's2cag-public-provenance-v1'
MANIFEST = 'MANIFEST.json'
SPEC = importlib.util.spec_from_file_location(
    '_s2cag_provenance_runner', Path(__file__).with_name('run_s2cag_pairs.py'))
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(Path(path).read_bytes())


def read_json(path):
    return json.loads(Path(path).read_text())


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def safe_relative(name):
    path = PurePosixPath(name)
    require(isinstance(name, str) and not path.is_absolute()
            and '..' not in path.parts and '\\' not in name and path.parts,
            f'Unsafe relative path: {name!r}')
    return path.as_posix()


def safe_read(root, name):
    name = safe_relative(name)
    path = root / name
    require(not path.is_symlink() and path.resolve().is_relative_to(root.resolve()),
            f'Symlink/escaping input: {name}')
    return path.read_bytes()


def pointer_part(value):
    return str(value).replace('~', '~0').replace('/', '~1')


def portable_json(value):
    """Change only the two permitted fields; never log their private values."""
    result = deepcopy(value)
    changed = []

    def basename(container, key, pointer):
        value = container.get(key)
        if isinstance(value, str):
            replacement = PurePosixPath(value.replace('\\', '/')).name
            if replacement != value:
                container[key] = replacement
                changed.append(pointer + '/' + pointer_part(key))

    def visit(item, pointer=''):
        if isinstance(item, dict):
            env = item.get('environment')
            if isinstance(env, dict):
                ep = pointer + '/environment'
                basename(env, 'executable', ep)
                for index, library in enumerate(env.get('blas', [])):
                    if isinstance(library, dict):
                        basename(library, 'filepath', ep + f'/blas/{index}')
            for key, child in item.items():
                visit(child, pointer + '/' + pointer_part(key))
        elif isinstance(item, list):
            for index, child in enumerate(item):
                visit(child, pointer + f'/{index}')

    visit(result)
    return result, sorted(changed)


def tensor_hash(array):
    """Equivalent to runner.tensor_hash for the archived dense int64 labels."""
    array = np.ascontiguousarray(array)
    require(array.dtype == np.int64, 'Expected saved int64 label/hierarchy array')
    h = hashlib.sha256()
    h.update(str(tuple(array.shape)).encode())
    h.update(b'torch.int64')
    h.update(memoryview(array).cast('B'))
    return h.hexdigest()


def selected_paths(root):
    campaign = read_json(root / 'campaign.json')
    require(campaign['status'] == 'complete', 'Cannot export incomplete campaign')
    require(campaign['plan'] == runner.make_plan(campaign['config']), 'Plan/configuration mismatch')
    json_paths = {'campaign.json', 'config.json', 'paired-summary.json'}
    npz_paths = set()
    for job in campaign['plan']['jobs']:
        prepared_path = f"prepared/{job['cell_id']}.json"
        json_paths.add(prepared_path)
        prepared = read_json(root / prepared_path)
        initial_path = safe_relative(prepared['initial_file'])
        npz_paths.add(initial_path)
        json_paths.add(PurePosixPath(initial_path).with_suffix('.json').as_posix())
        for mode in ('full', 'local'):
            result_path = f"pairs/{job['pair_id']}/{mode}.json"
            json_paths.add(result_path)
            for row in read_json(root / result_path)['rows']:
                npz_paths.add(safe_relative(row['label_file']))
    return campaign, sorted(json_paths), sorted(npz_paths)


def verify_public(directory):
    root = Path(directory).resolve()
    manifest = read_json(root / MANIFEST)
    require(manifest['schema'] == SCHEMA, 'Unknown public provenance schema')
    mapped = manifest['npz_files']
    expected_files = {MANIFEST}
    for name, metadata in manifest['json_files'].items():
        data = safe_read(root, name)
        require(sha(data) == metadata['exported_sha256'], f'JSON hash mismatch: {name}')
        require(not re.search(rb'/(?:Users|home|scratch)/', data),
                f'Unexpected private path outside the permitted transformation: {name}')
        _, remaining = portable_json(json.loads(data))
        require(not remaining, f'Private machine path remains: {name}')
        require(all(p.endswith('/environment/executable')
                    or ('/environment/blas/' in p and p.endswith('/filepath'))
                    for p in metadata['changed_json_pointers']), f'Unexpected redaction: {name}')
        expected_files.add(name)
    for original, metadata in mapped.items():
        safe_relative(original)
        expected = metadata['sha256']
        require(re.fullmatch(r'[0-9a-f]{64}', expected) is not None, f'Invalid NPZ digest: {original}')
        require(metadata['object'] == f'objects/{expected}.npz', f'Invalid NPZ mapping: {original}')
        require(sha(safe_read(root, metadata['object'])) == expected, f'NPZ hash mismatch: {original}')
        expected_files.add(metadata['object'])
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(actual == expected_files, 'Unexpected or missing public files')

    campaign, json_paths, npz_paths = selected_paths(root)
    require(set(json_paths) == set(manifest['json_files']), 'JSON allowlist differs from campaign')
    require(set(npz_paths) == set(mapped), 'NPZ allowlist differs from campaign')
    require(campaign['config'] == read_json(root / 'config.json'), 'Saved config changed')
    require(campaign['source_fingerprint'] == runner.json_hash(campaign['source_files']),
            'Execution-source fingerprint mismatch')
    require(campaign['source_archive_sha256'] == manifest['execution_sources_archive_sha256'],
            'Execution-source archive identity mismatch')
    require(campaign['source_fingerprint'] == manifest['source_fingerprint'], 'Source identity mismatch')

    def object_path(original):
        original = safe_relative(original)
        require(original in mapped, f'Unmapped NPZ: {original}')
        return root / mapped[original]['object']

    def array(original, member):
        with np.load(object_path(original), allow_pickle=False) as archive:
            require(archive.files == [member], f'Unexpected NPZ members: {original}')
            return archive[member]

    # validate_pair already implements admission and timer/score arithmetic.
    # Resolve its historical label paths through the explicit object map.
    old_digest = runner.digest
    runner.digest = lambda path: digest(object_path(Path(path).relative_to(root).as_posix()))
    pairs = []
    environments = None
    initial_checked = set()
    stream_initial = {}
    final_snapshots = {}
    label_trajectories = {}
    repeated_labels_equal = True
    update_records = 0
    try:
        for job in campaign['plan']['jobs']:
            prepared = read_json(root / 'prepared' / (job['cell_id'] + '.json'))
            initial = prepared['initial']
            initial_file = prepared['initial_file']
            require(mapped[initial_file]['sha256'] == initial['file_sha256'], 'Initial NPZ file changed')
            require(read_json(root / PurePosixPath(initial_file).with_suffix('.json')) == initial,
                    'Initial metadata differs from preparation')
            if initial_file not in initial_checked:
                hierarchy = array(initial_file, 'hierarchy')
                require(hierarchy.shape == (campaign['config']['comnetx']['depth'], prepared['input']['nodes']),
                        'Initial hierarchy dimensions mismatch')
                require(tensor_hash(hierarchy) == initial['hierarchy_sha256'], 'Initial tensor hash mismatch')
                require(tensor_hash(hierarchy[0]) == initial['fine_partition_sha256'], 'Initial fine-label hash mismatch')
                counts = [int(np.unique(row).size) for row in hierarchy]
                require(counts == initial['community_counts'], 'Initial community counts mismatch')
                for fine, coarse in zip(hierarchy[:-1], hierarchy[1:]):
                    require(np.unique(np.stack([fine, coarse], axis=1), axis=0).shape[0] == np.unique(fine).size,
                            'Initial hierarchy is not nested')
                initial_checked.add(initial_file)
            require(initial['initial_graph_sha256'] == prepared['input']['batches'][0],
                    'Initial graph identity mismatch')
            stream = (job['dataset'], job['feature_mode'], job['protocol'].split(':')[0])
            identity = (initial['hierarchy_sha256'], prepared['input']['features'],
                        prepared['input']['reference_labels'], initial['initial_graph_sha256'])
            require(stream not in stream_initial or stream_initial[stream] == identity,
                    'Initialization/features differ across repeats or subdivisions')
            stream_initial[stream] = identity
            records = {}
            for mode in ('full', 'local'):
                result = read_json(root / 'pairs' / job['pair_id'] / (mode + '.json'))
                for key, expected in (('job', job), ('config', campaign['config']),
                                      ('source_fingerprint', campaign['source_fingerprint']),
                                      ('input', prepared['input']), ('initial', initial),
                                      ('expected_updates', prepared['expected_updates'])):
                    require(result[key] == expected, f'Result differs from campaign/preparation: {key}')
                environment = {k: result['environment'].get(k) for k in runner.ENVIRONMENT_KEYS}
                require(environments is None or environments == environment, 'Execution environments differ')
                environments = environment
                hashes = []
                for row in result['rows']:
                    update_records += 1
                    labels = array(row['label_file'], 'labels')
                    require(labels.shape == (result['input']['nodes'],), 'Output label dimensions mismatch')
                    require(tensor_hash(labels) == row['label_sha256'], 'Output label tensor hash mismatch')
                    require(int(np.unique(labels).size) == row['nonempty_groups'], 'Output group count mismatch')
                    if 'backend_preprocessing_seconds' in row:
                        require(math.isclose(row['processing_wall_seconds'] - row['backend_preprocessing_seconds'],
                                             row['processing_excluding_preprocessing_seconds'],
                                             rel_tol=1e-12, abs_tol=1e-9), 'Timer subtraction mismatch')
                    hashes.append(row['label_sha256'])
                key = (job['cell_id'], mode)
                repeated_labels_equal &= key not in label_trajectories or label_trajectories[key] == hashes
                label_trajectories[key] = hashes
                final = result['rows'][-1]['snapshot_sha256']
                require(stream not in final_snapshots or final_snapshots[stream] == final,
                        'Final snapshot differs across repeats or subdivisions')
                final_snapshots[stream] = final
                records[mode] = result
            pairs.append(runner.validate_pair(records['full'], records['local'], root))
    finally:
        runner.digest = old_digest

    cells = {}
    for pair in pairs:
        cells.setdefault(pair['cell_id'], []).append(pair)
    cells = {key: {'repetitions': len(values), 'paired_repeats': values,
                   'mean_delta_q': mean(p['delta_q'] for p in values),
                   'mean_delta_nmi': mean(p['delta_nmi'] for p in values),
                   'median_speedup': {timer: median(p['speedup'][timer] for p in values)
                                      for timer in values[0]['speedup']}}
             for key, values in cells.items()}
    reconstructed = dict(schema=runner.SCHEMA, status='validated', cells=cells,
        note='Fixed-seed repetitions assess runtime repeatability, not variation across independent graphs/features. No historical records pooled.')
    require(reconstructed == read_json(root / 'paired-summary.json'), 'Reconstructed summary differs')
    return dict(status='passed', paired_executions=len(pairs), method_executions=2*len(pairs),
                update_records=update_records, label_files=len(mapped)-len(initial_checked),
                initial_hierarchies=len(initial_checked), mapped_npz_files=len(mapped),
                unique_npz_objects=len({v['object'] for v in mapped.values()}),
                json_files=len(manifest['json_files']), summary_reconstructed=True,
                repeated_label_trajectories_equal=repeated_labels_equal,
                scientific_measurements_executed=False,
                limitations='Input graph/reference-label arrays and optional execution-source ZIP are not redistributed. Their recorded identities are preserved; Q/NMI are checked as recorded, not recalculated from input datasets.')


def export(source, destination, received_zip=None):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    require(not destination.exists(), 'Destination already exists; choose a new directory')
    require(not destination.is_relative_to(source), 'Export cannot be inside the immutable source campaign')
    received_zip = Path(received_zip).resolve() if received_zip else source.with_suffix('.zip')
    campaign, json_paths, npz_paths = selected_paths(source)
    execution_zip = source / 'execution-sources.zip'
    require(digest(execution_zip) == campaign['source_archive_sha256'], 'Execution-source ZIP changed')
    with zipfile.ZipFile(execution_zip) as archive:
        require(set(archive.namelist()) == set(campaign['source_files']), 'Execution-source ZIP members differ')
        for name, expected in campaign['source_files'].items():
            require(sha(archive.read(name)) == expected, f'Execution source changed: {name}')
    originals = {name: safe_read(source, name) for name in json_paths + npz_paths}
    with zipfile.ZipFile(received_zip) as archive:
        names = set(archive.namelist())
        for name, data in originals.items():
            archive_name = name if name in names else source.name + '/' + name
            require(sha(archive.read(archive_name)) == sha(data), f'Extracted input differs from received ZIP: {name}')
    manifest = dict(schema=SCHEMA, received_archive_sha256=digest(received_zip),
                    execution_sources_archive_sha256=campaign['source_archive_sha256'],
                    source_fingerprint=campaign['source_fingerprint'], json_files={}, npz_files={},
                    transformation='Only environment.executable and environment.blas[*].filepath are replaced by basenames; numerical records and original NPZ bytes are unchanged.',
                    excluded=['jobs/', 'paths.json', 'execution-sources.zip'],
                    identity_note='Original JSON/source/received-archive hashes retain identities of files not redistributed. Independent public verification covers the exported records and mapped NPZ objects.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix='.s2cag-export-', dir=destination.parent))
    try:
        for name in json_paths:
            sanitized, pointers = portable_json(json.loads(originals[name]))
            data = json_bytes(sanitized)
            path = temporary / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            manifest['json_files'][name] = dict(original_sha256=sha(originals[name]),
                exported_sha256=sha(data), changed_json_pointers=pointers)
        (temporary/'objects').mkdir()
        for name in npz_paths:
            expected = sha(originals[name])
            obj = f'objects/{expected}.npz'
            path = temporary/obj
            if not path.exists():
                path.write_bytes(originals[name])
            manifest['npz_files'][name] = dict(sha256=expected, object=obj)
        (temporary/MANIFEST).write_bytes(json_bytes(manifest))
        result = verify_public(temporary)
        temporary.rename(destination)
        return result
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', nargs='?', type=Path)
    parser.add_argument('destination', nargs='?', type=Path)
    parser.add_argument('--received-zip', type=Path)
    parser.add_argument('--verify-public', type=Path, metavar='DIRECTORY')
    args = parser.parse_args()
    if args.verify_public:
        if args.source or args.destination or args.received_zip:
            parser.error('--verify-public is used by itself')
        result = verify_public(args.verify_public)
    else:
        if not args.source or not args.destination:
            parser.error('source and destination are required for export')
        result = export(args.source, args.destination, args.received_zip)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
