#!/usr/bin/env python3
"""Exercise the public Leiden and ComNetX paths on a synthetic, data-free stream."""
from __future__ import annotations

import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'src'))

import torch
from launcher import dynamic_launch


def main():
    # Three disjoint pairs, followed by an undirected bridge between two pairs.
    initial = torch.zeros((6, 6), dtype=torch.float32)
    for u, v in ((0, 1), (2, 3), (4, 5)):
        initial[u, v] = initial[v, u] = 1
    delta = torch.zeros_like(initial)
    delta[1, 2] = delta[2, 1] = 1
    stream = torch.stack((initial.to_sparse_coo(), delta.to_sparse_coo()))
    dataset = SimpleNamespace(name='synthetic_leiden_check', adj=stream,
                              features=None, label=None, is_directed=False)
    outcomes = {}
    for mode in ('naive', 'smart'):
        rows = dynamic_launch(
            dataset, '999:1', 'leidenalg', mode=mode,
            smart_subcoms_depth=2, smart_neighborhood_step=1,
            use_gpu=False, cache_dir=None, verbose=0, ground_truth_metrics=False,
        )
        assert len(rows) == 1, 'The initial snapshot must not be a measured update'
        final = rows[0]
        assert math.isfinite(final['Final modularity'])
        assert final['Final modularity'] > 0, 'The synthetic graph should yield nontrivial communities'
        assert abs(final['modularity'] - final['Final modularity']) < 1e-6
        outcomes[mode] = {'updates': len(rows), 'final_modularity': final['Final modularity']}
    print(json.dumps({'example': 'synthetic six-vertex positive update',
                      'backend': 'public leidenalg', 'outcomes': outcomes}, indent=2))


if __name__ == '__main__':
    main()
