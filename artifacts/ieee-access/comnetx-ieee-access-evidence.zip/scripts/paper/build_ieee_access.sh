#!/usr/bin/env bash
# Build the manuscript with the pdfLaTeX engine expected by the Access template.
set -euo pipefail

if [[ ${1:-} == "--help" || ${1:-} == "-h" ]]; then
    cat <<'USAGE'
Usage: scripts/paper/build_ieee_access.sh [BUILD_DIRECTORY]

Builds journal/ieee-access/main.tex with pdfLaTeX, BibTeX, and two further
pdfLaTeX passes. The default build directory is output/pdf/ieee-access-build.
All auxiliary files and compiler logs stay in the build directory.

Use an existing TeX Live, MacTeX, MiKTeX, or portable TinyTeX installation.
Set TEX_BIN to its binary directory if pdflatex and bibtex are not on PATH.
No compiler, package, or system configuration is installed by this script.
USAGE
    exit 0
fi

if [[ $# -gt 1 ]]; then
    printf 'Expected at most one build-directory argument.\n' >&2
    exit 2
fi

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo_dir=$(cd -- "$script_dir/../.." && pwd)
source_dir="$repo_dir/journal/ieee-access"
build_dir=${1:-"$repo_dir/output/pdf/ieee-access-build"}

if [[ -n ${TEX_BIN:-} ]]; then
    export PATH="$TEX_BIN:$PATH"
fi

for program in pdflatex bibtex; do
    if ! command -v "$program" >/dev/null 2>&1; then
        printf '%s was not found. Install a TeX distribution or set TEX_BIN.\n' "$program" >&2
        exit 127
    fi
done

if [[ ! -f "$source_dir/main.tex" || ! -f "$source_dir/references.bib" ]]; then
    printf 'Manuscript sources were not found in %s.\n' "$source_dir" >&2
    exit 2
fi

mkdir -p -- "$build_dir"
build_dir=$(cd -- "$build_dir" && pwd)

run_latex() {
    local pass=$1
    printf 'pdfLaTeX pass %s\n' "$pass"
    if ! (cd -- "$source_dir" && pdflatex \
        -interaction=nonstopmode -halt-on-error -file-line-error \
        -output-directory="$build_dir" main.tex) \
        >"$build_dir/pdflatex-pass-$pass.stdout" 2>&1; then
        tail -n 45 "$build_dir/pdflatex-pass-$pass.stdout" >&2
        printf 'Compilation failed; see %s.\n' "$build_dir/main.log" >&2
        exit 1
    fi
}

run_latex 1
printf 'BibTeX\n'
if ! (cd -- "$build_dir" && \
    BIBINPUTS="$source_dir:${BIBINPUTS:-}" \
    BSTINPUTS="$source_dir:${BSTINPUTS:-}" \
    bibtex main) >"$build_dir/bibtex.stdout" 2>&1; then
    cat "$build_dir/bibtex.stdout" >&2
    exit 1
fi
run_latex 2
run_latex 3

# Large output-routine boxes also occur in the official Access template's
# supplied access.log; do not mistake those footer overlays for missing text.
# Unresolved references, however, must prevent a successful submission build.
if grep -Eq 'There were undefined references|Citation .* undefined|Reference .* undefined' \
    "$build_dir/main.log"; then
    printf 'Unresolved citations or references remain; see %s.\n' "$build_dir/main.log" >&2
    exit 1
fi
if grep -Fq 'Rerun to get cross-references right' "$build_dir/main.log"; then
    run_latex 4
    if grep -Eq 'There were undefined references|Rerun to get cross-references right' \
        "$build_dir/main.log"; then
        printf 'Cross-references did not settle; see %s.\n' "$build_dir/main.log" >&2
        exit 1
    fi
fi

printf 'Built %s\n' "$build_dir/main.pdf"
printf 'Compiler diagnostics: %s\n' "$build_dir/main.log"
