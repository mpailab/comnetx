# ComNetX — IEEE Access source and reproducibility package

The journal manuscript is `journal/ieee-access/main.tex`. The accompanying
package contains the ComNetX implementation, tests, archived measurements,
selection and figure generators, and manuscript assets. Publication of this
prepared code package to an external repository is a separate author action;
this README does not assert that an online repository already contains it.

Use the clean evidence archive as the starting tree for a future public code
release. The local working directory also retains optional third-party sources
and internal historical material that the packager deliberately excludes.

The historical conference material in `article/` is retained locally and is
excluded from the journal submission package. None of the commands below writes
that historical directory.

## Rebuild the evidence and manuscript

Use Python 3.12 in a fresh virtual environment. The evidence-only dependencies
are smaller than those needed for new graph computations:

Install a TeX distribution providing pdfLaTeX and BibTeX before running these
commands: evidence regeneration also compiles the method diagram. For a portable
installation, set `TEX_BIN` to its binary directory; the Makefile adds it to
`PATH` for both evidence and manuscript builds.

```bash
python3 -m venv .venv-journal
.venv-journal/bin/python -m pip install -r requirements/ieee-access-evidence.txt
make evidence PYTHON=.venv-journal/bin/python
make audit PYTHON=.venv-journal/bin/python
make pdf
make package PYTHON=.venv-journal/bin/python
```

`make pdf` requires pdfLaTeX and BibTeX on `PATH` and writes
`output/pdf/comnetx-ieee-access.pdf`. Set `TEX_BIN=/path/to/tex/bin` when using a portable TeX installation.
`make package` creates a manuscript source archive and a source/evidence/code
archive in `output/submission/`; both have SHA256 manifests and are checked after
writing. Run `make package-check` to inspect the selected contents without
creating the final archives.

For core computation and tests:

```bash
.venv-journal/bin/python -m pip install -r requirements/ieee-access-core.txt
make verify PYTHON=.venv-journal/bin/python
```

This tests the implementation and regenerates current journal evidence; it does
not rerun the original Linux/GPU experiment campaign. Existing archived results
are immutable. The local diagnostic measurements in
`results/ieee-access-2026-3/structural-diagnostics/` measure working-graph sizes;
their times are not substitutes for the archived server times.

For new paired S²CAG measurements, use one server command:

```bash
bash scripts/paper/run_s2cag.sh --paths-config datasets-info/paths/cn69.json
```

It prepares a dedicated environment and runs the confirmatory series directly
(20 pairs / 40 processes). See the [server instructions](docs/s2cag-paired-reruns-ru.md).

## Contents and execution limits

- `src/`, `test/`, `conf/`, `scripts/`: ComNetX core, regression tests,
  configurations, and reproducibility utilities.
- `results/ieee-access-2026-2/`: original measurement JSON files, including
  records explicitly excluded from current manuscript comparisons.
- `results/ieee-access-2026-3/structural-diagnostics/`: separately identified
  structural diagnostics.
- `journal/ieee-access/`: manuscript, bibliography, generated assets, and
  evidence/audit programs.
- `docs/reproducibility.md`: exact commands, dataset layout, experiment settings,
  and the distinction between evidence regeneration and new measurements.
- `docs/dataset-provenance.md` and `docs/dataset-inputs.json`: checked public
  source distributions, input-array hashes and preserved stream-order metadata.
- `docs/third-party-components.md`: external component provenance and packaging
  exclusions; `docs/external-components.json` records pins and local hashes.

Core Leiden execution uses the public `igraph` and `leidenalg` packages. Native
DF-Leiden requires the separately supplied `dynamic_graphs_communities` binding;
that binding and its historical binary are not available in this package.
S²CAG execution requires upstream code and an adapted experiment wrapper whose
redistribution permission has not been established. The clean package therefore
includes its archived evidence and provenance, and a clear unavailable-backend
stub, rather than redistributing those sources. Other optional external
backends follow the same conservative exclusion policy. These limits do not
prevent rebuilding tables/figures or running the core Leiden implementation.

The existing root MIT notice is retained for ComNetX-authored code. It does not
relicense external implementations, datasets, or IEEE template resources.
