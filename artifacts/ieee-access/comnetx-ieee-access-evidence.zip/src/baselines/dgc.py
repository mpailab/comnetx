import argparse
import time
import torch

try:
    from dynamic_graphs_communities import AlgorithmOptions, LDLeiden, DFLeiden, Leidenalg, Networkit
except ImportError as exc:
    _BACKEND_IMPORT_ERROR = exc
    AlgorithmOptions = None
    LDLeiden = None
    DFLeiden = None
    Networkit = None

    class Leidenalg:
        """Small compatibility wrapper for the public ``leidenalg`` package.

        The optional ``dynamic_graphs_communities`` wheel is not distributed
        publicly.  Static/full and ComNetX Leiden runs do not need its native
        dynamic implementations, so keep those runs available through the
        already-vendored pure-Python adapter.  Native DF/LD-Leiden requests
        still fail explicitly in ``create_leiden`` below.
        """

        def __init__(self, adj, directed=True, options=None, partition=None):
            self.adj = adj.coalesce() if adj.is_sparse else adj.to_sparse_coo().coalesce()
            self.directed = directed
            self._partition = partition
            self._modularity = None

        def update(self, delta):
            delta = delta.coalesce() if delta.is_sparse else delta.to_sparse_coo().coalesce()
            self.adj = (self.adj + delta).coalesce()

        def apply(self, *args, **kwargs):
            from baselines.leiden import leidenalg_partition
            from metrics import Metrics

            start = time.perf_counter()
            self._partition = leidenalg_partition(
                self.adj,
                init_partition=self._partition,
            )
            self._modularity = Metrics.modularity(
                self.adj,
                self._partition,
                directed=self.directed,
            )
            return (time.perf_counter() - start) * 1000.0

        def partition(self):
            if self._partition is None:
                raise RuntimeError("Leidenalg.apply() must be called before partition()")
            return torch.as_tensor(self._partition, dtype=torch.long)

        def modularity(self):
            if self._modularity is None:
                raise RuntimeError("Leidenalg.apply() must be called before modularity()")
            return float(self._modularity)

ALG_CLASS = {
    "leidenalg": Leidenalg,
    "networkit": Networkit,
    "ldleiden": LDLeiden,
    "dfleiden": DFLeiden
}


def _apply_ldleiden(algo, timing_info=None):
    try:
        update_ms, run_ms = algo.apply(with_update_timing=True)
    except TypeError as exc:
        if "with_update_timing" not in str(exc):
            raise
        run_ms = algo.apply()
        update_ms = None

    if timing_info is not None:
        timing_info["algorithm_time"] = timing_info.get("algorithm_time", 0.0) + run_ms / 1000
        if update_ms is not None:
            timing_info["conversion_time"] = timing_info.get("conversion_time", 0.0) + update_ms / 1000


def create_leiden(method: str, adj, options=None, partition=None):
    if method not in ALG_CLASS:
        raise ValueError(f"Unknown method: {method}")

    if ALG_CLASS[method] is None:
        raise ImportError(
            f"{method} requires the optional dynamic_graphs_communities package, "
            "which is not installed in this environment"
        ) from _BACKEND_IMPORT_ERROR

    # В режиме directed == False методы из ALG_CLASS осуществляют симметризацию матрицы adj
    # Так как симметризация уже была произведена в Dataset, всегда используем directed == True
    # Метод networkit выбрасывает исключение при directed == True, поэтому оставляем False
    directed = True if method != "networkit" else False

    kwargs = {"directed": directed}
    if options is not None:
        kwargs["options"] = options
    if partition is not None:
        kwargs["partition"] = partition
    return ALG_CLASS[method](adj, **kwargs)

def _run_leiden(
    method,
    adj: torch.Tensor,
    init_partition=None,
    options=None,
    timing_info=None
):
    conversion_time = 0.0

    # Move to CPU if needed (the algorithm expects CPU tensors)
    if adj.device.type == "cuda":
        time_s = time.time()
        adj = adj.cpu()
        time_e = time.time()
        conversion_time += time_e - time_s

    # Instantiate and update (this includes building internal structures)
    time_s = time.time()
    if options is not None and AlgorithmOptions is not None:
        options = AlgorithmOptions(**options)

    algo = create_leiden(method, adj, options, partition = init_partition)

    time_e = time.time()
    conversion_time += time_e - time_s
    if timing_info is not None:
        timing_info["conversion_time"] = timing_info.get("conversion_time", 0.0) + conversion_time

    # Run the Leiden algorithm
    if method == "ldleiden":
        _apply_ldleiden(algo, timing_info=timing_info)
    else:
        time_s = time.time()
        run_ms = algo.apply()
        if timing_info is not None:
            timing_info["algorithm_time"] = timing_info.get("algorithm_time", 0.0) + run_ms / 1000

    return algo.partition().to(torch.long)
