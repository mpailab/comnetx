"""Placeholder generated for the clean journal distribution.

The original optional adapter remains in the authors' local workspace.
See docs/third-party-components.md and docs/external-components.json.
"""

def mfc_adopted(*args, **kwargs):
    raise ImportError(
        "Optional backend mfc is not distributed in this clean artifact. "
        "Its external implementation/adapted wrapper must be obtained separately "
        "with documented permission and revision; see docs/third-party-components.md."
    )
