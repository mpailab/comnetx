"""Placeholder generated for the clean journal distribution.

The original optional adapter remains in the authors' local workspace.
See docs/third-party-components.md and docs/external-components.json.
"""

def rough_prgpt(*args, **kwargs):
    raise ImportError(
        "Optional backend rough_PRGPT is not distributed in this clean artifact. "
        "Its external implementation/adapted wrapper must be obtained separately "
        "with documented permission and revision; see docs/third-party-components.md."
    )
