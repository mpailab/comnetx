# Static dataset inputs and source equivalence

Verified on 29 October 2026. The companion `dataset-inputs.json` identifies all
32 local NPZ inputs for Cora, ACM, Citeseer and PubMed, including file SHA-256,
array shapes, dtypes, array SHA-256, and stored metadata. The checks below compare
the actual input arrays with downloaded distributions. They establish equivalent
inputs; they do not reconstruct the original acquisition history or establish
which download command was used for the historical experiments.

The evidence package contains this documentation, its manifest, and four saved
edge permutations in `docs/stream-order/`. Dataset graphs, features and labels
are not redistributed by that package. The public distributions below, together
with these permutations, reproduce every array and metadata field in all 32
historical NPZ inputs. This was verified by generating a separate set of files
and comparing all 256 arrays directly against the untouched originals.

## Verified source distributions

| Local input | Verified topology | Verified features and labels |
| --- | --- | --- |
| `dyn_cora` | Exact edge-set equality with the author's Planetoid `ind.cora.graph`, after symmetrization and removal of self-loops; also exact equality with the ADGC adjacency | Exact equality with ADGC Cora, without reordering vertices |
| `dyn_citeseer` | Exact edge-set equality with the author's Planetoid `ind.citeseer.graph`, after symmetrization and removal of self-loops; ADGC adjacency gives the same graph after removing its 124 diagonal entries | Exact equality with ADGC Citeseer, without reordering vertices |
| `dyn_acm` | Exact edge-set equality with ADGC ACM; 26,256 stored orientations of 13,128 undirected edges | Exact equality with ADGC ACM after conversion to the local float32 feature and int64 label dtypes |
| `dyn_pubmed` | Exact equality with the 44,338 directed arcs, including three self-loops, in the distribution linked by PyG `AttributedGraphDataset` | Exact float32 equality with its source float64 CSR features, and exact labels after subtracting one from the source class IDs |

For every dataset, all local edge weights are one. Equality of topology above
means equality of complete edge sets with the same vertex identifiers, not just
matching counts. The public download's edge order need not equal the stored
stream order.

The primary Planetoid repository is
[kimiyoung/planetoid](https://github.com/kimiyoung/planetoid), associated with
[Yang, Cohen and Salakhutdinov, ICML 2016](https://proceedings.mlr.press/v48/yanga16.html).
The checked graph files are pinned to commit
`af6abf468a772cc055bec88c52e4d6f51b7c37e3`:

- [Cora graph](https://raw.githubusercontent.com/kimiyoung/planetoid/af6abf468a772cc055bec88c52e4d6f51b7c37e3/data/ind.cora.graph),
  SHA-256 `58f13302f39dde8852dad6fe6d15b89b077b6d7f837626bce671ef80344b383d`.
- [Citeseer graph](https://raw.githubusercontent.com/kimiyoung/planetoid/af6abf468a772cc055bec88c52e4d6f51b7c37e3/data/ind.citeseer.graph),
  SHA-256 `d79a4ef9d3e7169aee8946145f6b7306e35bc79bffad26346cfb94e10e9912a7`.

ADGC is a public distribution, rather than a claim about the original creators
of each graph. Its
[dataset index at commit 334f96aa8e67f6da033a71a26eae150b85d5e5c9](https://github.com/yueliu1999/Awesome-Deep-Graph-Clustering/blob/334f96aa8e67f6da033a71a26eae150b85d5e5c9/dataset/README.md)
links these checked downloads:

- [Cora archive](https://drive.google.com/uc?export=download&id=1_LesghFTQ02vKOBUfDP8fmDF1JP3MPrJ),
  SHA-256 `83294c21a0694619565c3e7212c5420a94f73c551f3d296356e5c959f295281f`.
- [Citeseer archive](https://drive.google.com/uc?export=download&id=1dEsxq5z5dc35tS3E46pg6pc2LUMlF6jF),
  SHA-256 `78d004ef05ee6dc01ffe09d5eff4f30425f3bc0a4f98632aabd89ededab0ea0d`.
- [ACM archive](https://drive.google.com/uc?export=download&id=19j7zmQ-AMgzTX7yZoKzUK5wVxQwO5alx),
  SHA-256 `48cb431fe6760de74aa801e26d0627026236107b7e90ac0781b43b26d778fb9b`.

The checked PubMed archive is linked by the official
[PyG AttributedGraphDataset loader](https://pytorch-geometric.readthedocs.io/en/latest/_modules/torch_geometric/datasets/attributed_graph_dataset.html),
which attributes this dataset collection to
[Scaling Attributed Network Embedding to Massive Graphs](https://vldb.org/pvldb/vol14/p37-yang.pdf).
The [download](https://drive.google.com/uc?export=download&id=1DOK3FfslyJoGXUSCSrK5lzdyLfIwOz6k)
has SHA-256 `c5c5d81880bd51b75c702fc93eeeb07504616676628a5c4ece637260e405eaf8`.
Its members `pubmed.attr/{edgelist.txt,attrs.npz,labels.txt}` were compared.
This is not the 44,324-edge undirected Planetoid PubMed variant.

Google Drive file IDs do not supply immutable version pins here. The archive
hashes identify the exact downloaded bytes that were checked. The Git commit
pins identify the checked repository files, not the historical experiment's
software environment.

## What is known about stream order

Every local dynamic NPZ records `seed=42`. Cora, ACM and Citeseer record
`original_source=small_graphs`; PubMed records `original_source=attr_graphs`.
These are stored metadata values, not independently recovered generator names.

The following properties were checked across all four datasets and all four
batch counts, B in {1, 10, 100, 1000}:

1. Ordered `indices`, `values`, features and labels are identical across B.
2. For each undirected graph, the first M records have source less than target.
   The remaining M records are their reversals, in precisely the same order.
3. For an undirected graph, `batch_indices` assigns consecutive bins to the
   first M records with the sizes produced by `numpy.array_split(..., B)`,
   then repeats those same labels for the reversed half. For directed PubMed,
   the same bin-size rule applies to all M records.

The original random-number generator has not been recovered.
`default_rng(42).permutation`, `RandomState(42).permutation`, and Python
`Random(42).sample` did not reproduce the order when applied to lexicographically
ordered upper-triangle edges; for PubMed, both the downloaded edge order and
lexicographic edge order were tried. This does not exclude another generator,
another initial order, or prior random draws. The seed alone is insufficient
to regenerate the exact historical streams.

Exact replay instead uses the preserved permutations in `docs/stream-order/`.
For each graph, form a lexicographically sorted unique list of source edges;
for undirected graphs use only entries with source less than target, and for
directed PubMed retain all directed entries, including self-loops. Each saved
integer is the index of an archived ordered edge in that canonical list. The
manifest records each permutation's file and array hashes and its canonical
edge-list hash. This preserves the observed protocol without attributing it to
an unverified RNG or redistributing graph endpoints or node features.

## Recreate all static-stream inputs

Download the three ADGC archives and the PyG PubMed archive linked above. Check
their archive SHA-256 values against the manifest before extraction. Place the
extracted files in the following layout; Cora and Citeseer already have their
named directory inside the ZIP, while the ACM ZIP has its files at top level:

```text
SOURCE_DIR/
  cora/{cora_adj.npy,cora_feat.npy,cora_label.npy}
  acm/{acm_adj.npy,acm_feat.npy,acm_label.npy}
  citeseer/{citeseer_adj.npy,citeseer_feat.npy,citeseer_label.npy}
  pubmed.attr/{attrs.npz,edgelist.txt,labels.txt}
```

From the repository root, using Python with NumPy installed:

```bash
python scripts/paper/prepare_static_streams.py \
  --cora SOURCE_DIR/cora --acm SOURCE_DIR/acm \
  --citeseer SOURCE_DIR/citeseer --pubmed SOURCE_DIR/pubmed.attr \
  --output-dir data
```

The command applies the verified source normalizations, checks the canonical
topology, applies the saved permutation, constructs 1-, 10-, 100- and 1000-bin
inputs, and verifies every output array and metadata field against the
manifest. Existing files are verified and left in place; `--overwrite` explicitly
permits replacing them. A source with different topology, features, labels or
vertex ordering fails the array checks before output is written for that graph.
The script uses NumPy alone; it reads the PubMed CSR arrays without requiring
SciPy or a community-detection package.

Replay was checked with NumPy 1.26.4. Complete NPZ member sets, shapes, dtypes and
`numpy.array_equal` matched the originals for all **256 arrays in 32 files**.
The historical compressed-file SHA-256 values identify the original files;
recompression can change NPZ file bytes without changing their arrays. The
preparation command therefore validates array hashes, including metadata array
hashes, rather than requiring identical compressed bytes.

## Loader transformations and update meaning

`src/datasets.py` loads `indices`, `values` and `batch_indices`, constructs sparse
adjacency tensors, and applies `A + A.T` to sources marked undirected. A
`force_undirected` run also symmetrizes a directed source. This additive
symmetrization preserves reciprocal source entries as additional weight.

The undirected static NPZ inputs already store both orientations of every edge.
After loader symmetrization, the completed graph therefore has weight two for
each undirected edge. For a `p:q` maintenance protocol, the loader takes the
first p coarse bins as initialization and divides the stored records in the
last bin into at most q chunks. Each chunk is symmetrized separately. An update
can therefore increase the weight of a previously introduced edge; it need not
introduce a distinct new edge. For the `999:10` tail, Cora has 10 stored records
representing five distinct undirected edges, ACM has 26 representing 13, and
Citeseer has eight representing four. Cora's first five updates add weight one
to those edges and its last five raise their weights to two.

These transformations are part of the archived protocol. The input manifest
does not alter the original NPZ files or recorded results. On a completed
undirected graph, uniform multiplication of all weights by two leaves modularity
unchanged; intermediate weighted updates still have to be interpreted as the
actual additive stream.

## Check preserved original input files

Run this from the repository root, in a Python environment with NumPy. It checks
all manifest file hashes and every recorded array hash, shape and dtype. This
integrity check is separate from the source comparisons described above.

```bash
python - <<'PY'
import hashlib
import json
from pathlib import Path
import numpy as np

manifest = json.loads(Path('docs/dataset-inputs.json').read_text())
for item in manifest['files']:
    path = Path(item['path'])
    assert path.stat().st_size == item['bytes'], path
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], path
    with np.load(path, allow_pickle=False) as payload:
        for key, expected in item['arrays'].items():
            array = payload[key]
            assert list(array.shape) == expected['shape'], (path, key)
            assert array.dtype.str == expected['dtype'], (path, key)
            actual = hashlib.sha256(array.tobytes(order='C')).hexdigest()
            assert actual == expected['sha256_c_order_bytes'], (path, key)
        for key, expected in item['metadata'].items():
            assert payload[key].tolist() == expected, (path, key)
print(f"Verified {len(manifest['files'])} exact input files")
PY
```

To repeat a source comparison, first obtain a download whose SHA-256 matches
the manifest. For an ADGC archive, load its `*_adj.npy`, `*_feat.npy`, and
`*_label.npy` with `allow_pickle=False`; remove the adjacency diagonal; compare
the complete nonzero edge set against the local `indices`; compare float32
features and int64 labels with `numpy.array_equal`. For PubMed, compare the
complete directed edge set without removing its diagonal, convert the CSR
`attrs.npz` to float32, and subtract one from the source class IDs before the
same array equality checks. No vertex permutation was needed in these checks.
