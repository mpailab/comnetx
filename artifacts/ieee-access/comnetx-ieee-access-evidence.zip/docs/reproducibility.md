# Reproducibility instructions

The **6 November 2026 availability-section revision** retains the completed
S²CAG paired campaign, broad literature review, and detailed method diagram.
The manuscript now gives a concise availability statement and empirical
limitations; the full provenance and exclusion history remain documented here.
Measurements and execution provenance are unchanged from r3.
Independent checks of the summary and complete execution archive passed. The
fixed distribution for this revision is identified by
[`ieee-access-r6-20261106`](https://github.com/mpailab/comnetx/tree/ieee-access-r6-20261106/artifacts/ieee-access).

The [r5 distribution](https://github.com/mpailab/comnetx/tree/ieee-access-r5-20261106/artifacts/ieee-access)
contains the same scientific content before the availability-section edit.
The [r4 distribution](https://github.com/mpailab/comnetx/tree/ieee-access-r4-20261106/artifacts/ieee-access)
contains the shorter review and simplified diagram. The [r3 distribution](https://github.com/mpailab/comnetx/tree/ieee-access-r3-20261105/artifacts/ieee-access)
contains the same measurements before the editorial revision. The manuscript
PDF, source ZIP, evidence ZIP, and SHA-256 checksums for the **earlier
2 November 2026 revision** are available in the fixed
[`ieee-access-r2-20261102` repository snapshot](https://github.com/mpailab/comnetx/tree/ieee-access-r2-20261102/artifacts/ieee-access).
That snapshot contains the archived results used by that revision and excludes
the new paired S²CAG campaign. It is not a download link for the current revision.

## Three different operations

1. `make evidence` regenerates current journal tables, macros and vector figures
   from archived JSON records. It does not execute community detectors.
2. `make audit` checks record arithmetic, source hashes, algebraic identities,
   labels, references and available manuscript assets using the current audit
   program. A successful audit is not a new experiment.
3. New measurements run the current implementation on separately obtained
   datasets. Their versions, hardware and initialization must be recorded; they
   must not replace or silently modify archived measurements.

Use `make evidence audit pdf package` for a complete rebuild, with
`PYTHON=path/to/python` and `TEX_BIN=/path/to/tex/bin` as needed. The package
script itself uses only Python's standard library. It writes deterministic ZIP
contents, checks every archived file against its SHA256 manifest, rejects
private machine paths, and excludes datasets, local environments, caches and
internal review notes. The manifest identifies generated optional-backend stubs.

Evidence regeneration compiles the method diagram, so it also needs pdfLaTeX.
A normal TeX Live/MacTeX installation supplies the dependencies. A minimal TeX
installation needs IEEEtran, algorithms, algorithmicx, multirow, cite,
standalone, PGF/TikZ and Courier in addition to the usual LaTeX tools and fonts.

## New paired S²CAG campaign and execution provenance

`results/ieee-access-2026-4/s2cag-paired-20261105/paired-summary.json` is the
supplied, immutable result summary. It contains four settings: PubMed and
ArxivMath under `999:5` and `999:10`, with five full/local pairs per setting
(20 pairs and 40 method executions). The generator independently checks pair
identities, repeat/update counts, finite values, full/local time ratios,
modularity and NMI differences, and the summary aggregates. It reports means
and sample standard deviations for times and medians of the five paired
speedups. The recorded final nonempty-community counts describe the returned
partition; they must not be interpreted as the requested solver cluster count.

The summary's `status: validated` records the runner's validation result.
Independent review subsequently checked all 20 pairs, 40 method executions,
300 per-method update records and saved label arrays, 600 backend traces and
two shared initial hierarchies. The summary was regenerated exactly from those
records. Input and snapshot fingerprints match within every pair and repetition;
both subdivisions end at the same graph snapshot. The five saved label
trajectories within each method/setting are identical, not merely equal in
their final quality scores. All 32 files in the execution-source archive match
repository commit `418de09509cb3737287091b5a489e0937f6e2388`.

The distributable evidence is in
`results/ieee-access-2026-4/s2cag-paired-20261105/provenance/`. It contains the
40 method-result JSON files, preparation records, campaign/configuration
metadata, and source hashes. A manifest maps the 302 logical NPZ paths
(300 update-label arrays and two initial hierarchies) to 61 unique objects
identified by SHA-256. Identical files share one stored object; no label payload
is discarded. The executable and BLAS-library paths are reduced to basenames in
public environment records, while package versions, thread counts, hardware,
measurements and hashes are preserved. Optional third-party implementation
sources are represented by their hashes rather than redistributed. The original
received archive, including its complete source snapshot, remains unchanged
locally.

Verify this public subset without running a detector:

```bash
python scripts/paper/export_s2cag_provenance.py --verify-public \
  results/ieee-access-2026-4/s2cag-paired-20261105/provenance
```

The verifier needs NumPy and the standard library. It checks the manifest,
label and hierarchy payloads, paired records, and reconstructed summary.
`make audit` includes this check.

The recorded configuration uses 64-dimensional random features with seed 42;
S²CAG `sub` with T=10, alpha=1, tau=7, five internal calls, SVD seed 0, ten
oversampling columns and 100 rounding iterations; and ComNetX with L=3, r=1
and mean aggregation (`normalized` in the configuration). Initialization uses
public `leidenalg` with resolution 1, seed 1 and two iterations. The run files
record the following environment separately from that of the original campaign:

| Component | Recorded paired-campaign value |
|---|---|
| Host CPU | Two AMD EPYC 7742 processors, 64 cores each |
| Visible GPU | One NVIDIA A100-SXM4-80GB; driver 580.178.04 |
| Python | 3.10.13 on Linux x86-64 |
| Numeric stack | NumPy 1.26.4, SciPy 1.10.1, scikit-learn 1.5.2 |
| Tensor stack | PyTorch 2.3.1, CUDA 12.1; TensorFlow 2.16.2 |
| Initializer | igraph 1.0.0, leidenalg 0.12.0 |
| CPU threads | Eight for the recorded numerical libraries; PyTorch inter-op threads: one |

The tensor path uses CUDA; the S²CAG solver uses NumPy/SciPy on the CPU.
The run files also retain their installed-package lists and BLAS details.
The environment is identical across all 40 executions. The initial hierarchy
has 55 communities per level on PubMed and 8,167 per level on ArxivMath; the
8,248 count in the older structural diagnostics belongs to that different
series. The configuration presets alone are not substituted for these recorded
values.

The new observations remain a separate campaign. Their times are not pooled
with the original measurements, and their repeatability does not establish
variation across independent graphs or random-feature seeds. They do not
recover the configuration of the old S²CAG subdivision/window/growth records.

The campaign records hashes of its graph and reference-label tensors rather
than redistributing those input arrays. The provenance check establishes their
equality across paired/repeated runs; it is not a fresh recomputation of graph
metrics from the external datasets. Exact random-feature tensor hashes should
be checked when rerunning: the retained seed and dimension alone do not guarantee
byte-identical draws across platforms.

## Python and backend settings

The core/evidence requirements describe the tested local Python 3.12 setup;
the paired S²CAG runner has its own Python 3.10/3.11 requirements.
They are not a recovered lockfile of the historical Linux experiment server.
The article records that server's Python/PyTorch/TensorFlow versions; exact
historical native bindings and per-run configurations are not recoverable from
all JSON files. The original server description and the recorded new environment
above describe separate campaigns and must not be interchanged.

Core Leiden calls use resolution 1 by default, `seed=True` (integer 1) and
`n_iterations=2`; full mode receives the previous partition, local quotient calls
do not. The usual configuration is L=3, r=1. Random features use 64 dimensions,
seed 42 unless explicitly overridden; the feature-seed study uses seeds 1–5.
The preserved S²CAG adapter uses `sub`, propagation order T=10, five solver
calls, alpha=1 and tau=7, with SVD seed 0 and 100 rounding iterations. Its
gamma argument is unused in the `sub` branch. The last call is returned; the
five calls are not independent replicates. Full previous labels determine only
the requested cluster count, without warm-starting the spectral solver. See
[S²CAG configuration and provenance](s2cag-reproducibility.md) for actual
output-count limits, included/excluded timing stages and feature transformations.
The later subdivision/window/growth records lack exact execution provenance;
they are retained as archive diagnostics, not treated as matched continuations
of the main feature comparison.

The native-growth launcher now installs the first snapshot only through the
constructor and applies `update()` only to subsequent deltas. Bootstrap `p:q`
priming remains unchanged. Historical native DF-Leiden growth records are
preserved for inspection and excluded from current comparisons until a verified
rerun is available. Fixing code does not repair historical measurements.

## Dataset preparation and local structural diagnostics

`make core-example` runs the public Leiden baseline and ComNetX on a synthetic
six-vertex stream. It needs the core Python dependencies, but no dataset files,
optional baseline implementations or native dynamic binding.

Data are deliberately not redistributed. Obtain the exact input versions from
the dataset resources cited by the manuscript; preprocessing and edge ordering
matter. The original processed inputs have not been rehosted by this package.
Use `datasets-info/paths/local.json` for the following relative layout:

```text
data/dyn_cora/{dynamic_cora,feat_cora}-1000_batches.npz
data/dyn_pubmed/{dynamic_pubmed,feat_pubmed}-1000_batches.npz
data/arxivmath/{arxivmath.txt,feature.txt,node2label.txt}
```

The loader also expects the corresponding 1-, 10-, and 100-bin files for the
other protocols. [Dataset provenance](dataset-provenance.md) identifies the
checked public source downloads and their hashes. After obtaining and extracting
those exact distributions, replay the four static streams with NumPy alone:

```bash
python scripts/paper/prepare_static_streams.py \
  --cora INPUTS/cora --acm INPUTS/acm --citeseer INPUTS/citeseer \
  --pubmed INPUTS/pubmed.attr --output-dir data
```

Point the first three arguments at directories containing the corresponding
`*_adj.npy`, `*_feat.npy` and `*_label.npy` files; a ZIP may have a wrapper
directory. The PubMed directory must contain `attrs.npz`, `edgelist.txt` and
`labels.txt`. The script uses the preserved permutations in `docs/stream-order/`
and checks every output array and metadata field against `dataset-inputs.json`.
It replays the archived ordering without claiming to recover the original RNG.
Compressed NPZ bytes may differ even when every stored array matches. Existing
outputs are checked and retained unless an explicit overwrite is requested.

`scripts/paper/prepare_local_data.py arxivmath patent` separately converts the
TGC text inputs into the loader's NumPy/joblib representations.

An example production profile on separately acquired inputs is:

```bash
python scripts/paper/profile_smart_workload.py \
  --datasets dyn_cora dyn_pubmed arxivmath \
  --batches 999:10 --methods leidenalg \
  --paths-config datasets-info/paths/local.json \
  --cache-dir tmp/communities-local \
  --output-dir results/local-new-measurements --name scope-sizes \
  --smart-depth 3 --smart-radius 1 --aggregation-mode sum \
  --variants full --max-updates 10 --force-undirected --ground-truth-metrics
```

Do not pool these local times with server timings. `ru_maxrss` is reported as a
process peak, converted from bytes on macOS and KiB on Linux.

The configurations under `conf/ieee_access/` are explicit starting points for
new runs. Older `conf/paper_icdm/` presets are retained as configuration evidence;
their filenames alone do not establish that a particular archived run used an
identical source revision. `scripts/launch.py CONFIG --paths-config
 datasets-info/paths/local.json` writes new results to the directory selected by
`RESULTS_DIR`; choose a fresh directory.

## Optional implementations

Consult `third-party-components.md` before attempting an optional backend. The
clean package intentionally cannot execute S²CAG, MAGI, MFC, PRGPT or FLMIG until
the excluded integrations have been obtained with appropriate permission. It
cannot execute native DF-Leiden without its separate binding. The packaged
adapter placeholders raise a descriptive ImportError. No optional backend is
silently substituted for a different algorithm.

`external-components.json` gives source URLs, pinned observed upstream commits
where verified, and SHA256 hashes of the local sources that were excluded. These
pins identify inspected copies; they do not establish that the inspected public
HEAD was the exact historical measurement revision. To inspect an upstream pin,
clone its URL into a separate external directory, check out the recorded commit,
and compare individual files using `shasum -a 256` or `sha256sum`. Renamed or
adapted files can legitimately have different hashes and require an explicit
integration patch and renewed validation.
