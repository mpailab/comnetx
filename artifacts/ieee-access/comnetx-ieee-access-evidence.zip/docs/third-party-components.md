# External component provenance and distribution scope

This is a record of the files inspected for this artifact, not a general legal
opinion. The ComNetX root MIT notice is not treated as permission to redistribute
all code found in the working directory.

| Component | Local evidence | Clean package policy |
|---|---|---|
| S²CAG | No LICENSE in the local copy; GitHub repository metadata reports no detected license at inspected commit | Exclude vendored source and adapted experiment wrapper; keep measurement JSON, source URL, pin and local hashes |
| MAGI | No LICENSE in local copy or detected in inspected upstream repository metadata | Exclude vendored source and dependent wrapper |
| MFC-TopoReg | No LICENSE in local copy or detected in inspected upstream repository metadata | Exclude vendored source and dependent wrapper |
| PRGPT | No LICENSE in local copy or detected in inspected upstream repository metadata | Exclude vendored source, weights and dependent wrapper |
| FLMIG | No LICENSE or pinned upstream provenance established for the local copy | Exclude vendored source and dependent wrapper |
| DMoN | Local Apache-2.0 LICENSE and source notices are present | Not needed for the current journal results; excluded with other optional implementations to keep the execution scope explicit |
| Leiden/igraph | Installed from public packages with their own license distributions | Do not vendor; pin package versions in requirements |
| Native DF/LD-Leiden | Separate `dynamic_graphs_communities` binding is unavailable | Do not vendor or claim exact rerun capability |
| IEEE Access template, style and font resources | Supplied manuscript-template resources | Preserve for manuscript compilation; root MIT notice does not apply |

Primary upstream sources inspected on 29 October 2026:

- [S²CAG](https://github.com/HKBU-LAGAS/S2CAG), pinned commit
  `51c567962ea2dddd200b446d99faccb224f29977`.
- [MAGI](https://github.com/EdisonLeeeee/MAGI), pinned commit
  `6313854c0748d58fee11e84d7e6b73221e9c1557`.
- [MFC-TopoReg](https://github.com/kundtx/MFC-TopoReg), pinned commit
  `7161b67d0f0542c75190cf45f066c1f445a1cf61`.
- [PRGPT](https://github.com/KuroginQin/PRGPT), pinned commit
  `a4f22b0b402b4813a1a20b5e642af54caf81166a`.

On 31 October 2026, the original public [DF-Leiden repository](https://github.com/puzzlef/leiden-communities-openmp-dynamic)
was verified against footnote 1 of the [authors' paper](https://arxiv.org/html/2405.11658v4#S1).
This is the public algorithm implementation to cite. It does not identify the
revision of the private Python binding used for the archived measurements;
that revision was not saved, and current upstream must not be presented as an
exact substitute for the measured binary. The binding's import name remains
documented only as an integration dependency, not as a public repository citation.

The preserved S²CAG adapter's parameters, output-count rules, timing boundaries,
and per-series provenance limits are documented in
[s2cag-reproducibility.md](s2cag-reproducibility.md).

The absence of a detected repository license is recorded as uncertainty, not as
proof that no permission could ever be obtained. Authors can add an optional
implementation to a future package after its redistribution basis and source
revision have been documented. Keep upstream notices and validate the integrated
code; do not silently expand the root license to cover it.

The clean package contains generated fail-fast modules in place of the excluded
optional adapters. The original local files remain untouched. Their individual
hashes and the observed upstream pins are in `external-components.json`; the
archive manifest identifies the generated placeholders. Tables and figures use
archived records and do not import these adapters.
