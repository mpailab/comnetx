"""Check and render the completed, separately paired S2CAG campaign.

Only the supplied per-pair observations enter these tables. Historical runs
remain in their own series. A summary cannot validate absent execution metadata.
"""
from pathlib import Path
import hashlib
import json
import math
from statistics import mean, median, stdev

RELATIVE = Path('results/ieee-access-2026-4/s2cag-paired-20261105/paired-summary.json')
SOURCE_SHA256 = '7971096f8541d05d09ce1c5b93397f86ab61926e847b68bd10ef31e6e8175c8a'
TIMERS = ('processing_excluding_preprocessing_seconds', 'processing_wall_seconds')
DATASETS = {'dyn_pubmed': 'PubMed', 'arxivmath': 'ArxivMath'}


def close(actual, expected):
    assert math.isfinite(actual) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), (actual, expected)


def generate_confirmatory(root, journal, table):
    path = root / RELATIVE
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SOURCE_SHA256, 'The supplied campaign summary changed'
    source = json.loads(raw)
    assert source['schema'] == 's2cag-pairs-v1' and source['status'] == 'validated'
    expected = {f'{d}__random__999-{q}' for d in DATASETS for q in (5, 10)}
    assert set(source['cells']) == expected
    rows, timing_rows, cells, identities = [], [], {}, set()
    for dataset, display in DATASETS.items():
        for q in (5, 10):
            key = f'{dataset}__random__999-{q}'
            cell = source['cells'][key]
            pairs = cell['paired_repeats']
            assert cell['repetitions'] == len(pairs) == 5
            assert sorted(p['repetition'] for p in pairs) == list(range(1, 6))
            for pair in pairs:
                assert pair['cell_id'] == key and pair['updates'] == q
                assert pair['pair_id'] == f"{key}__r{pair['repetition']:02}"
                assert pair['pair_id'] not in identities
                identities.add(pair['pair_id'])
                f, l = pair['final']['full'], pair['final']['local']
                for output in (f, l):
                    assert math.isfinite(output['modularity'])
                    assert 0 <= output['nmi'] <= 1
                    assert type(output['nonempty_groups']) is int and output['nonempty_groups'] > 0
                close(pair['delta_q'], l['modularity'] - f['modularity'])
                close(pair['delta_nmi'], l['nmi'] - f['nmi'])
                for mode in ('full', 'local'):
                    t = pair['time'][mode]
                    assert 0 < t[TIMERS[0]] <= t[TIMERS[1]]
                for timer in TIMERS:
                    close(pair['speedup'][timer], pair['time']['full'][timer] / pair['time']['local'][timer])
            close(cell['mean_delta_q'], mean(p['delta_q'] for p in pairs))
            close(cell['mean_delta_nmi'], mean(p['delta_nmi'] for p in pairs))
            timings = {}
            for timer in TIMERS:
                ratios = [p['speedup'][timer] for p in pairs]
                close(cell['median_speedup'][timer], median(ratios))
                timings[timer] = {
                    mode: {'mean': mean(p['time'][mode][timer] for p in pairs),
                           'sample_sd': stdev(p['time'][mode][timer] for p in pairs)}
                    for mode in ('full', 'local')}
                timings[timer]['speedup'] = {'median': median(ratios), 'min': min(ratios), 'max': max(ratios)}
            # One printed quality/count value is valid only if all repetitions agree.
            final = pairs[0]['final']
            assert all(p['final'] == final for p in pairs)
            def timing(mode, timer=TIMERS[0]):
                t = timings[timer][mode]
                return f"{t['mean']:.3f}$\\pm${t['sample_sd']:.3f}"
            rows.append([display, f'$999{{:}}{q}$',
                *(f"{final['full'][metric]:.4f}/{final['local'][metric]:.4f}" for metric in ('modularity', 'nmi')),
                f"{final['full']['nonempty_groups']:,}/{final['local']['nonempty_groups']:,}",
                timing('full'), timing('local'), f"{timings[TIMERS[0]]['speedup']['median']:.2f}"])
            timing_rows.append([display, f'$999{{:}}{q}$', timing('full', TIMERS[1]),
                timing('local', TIMERS[1]), f"{timings[TIMERS[1]]['speedup']['median']:.2f}"])
            cells[key] = dict(dataset=dataset, protocol=f'999:{q}', repetitions=5,
                final=final, quality_and_group_counts_equal_across_repetitions=True,
                timings=timings, delta_q=cell['mean_delta_q'], delta_nmi=cell['mean_delta_nmi'])
    table('s2cag_confirmatory_rows.tex', rows)
    table('s2cag_confirmatory_wall_rows.tex', timing_rows)
    result = dict(source=RELATIVE.as_posix(), source_sha256=hashlib.sha256(raw).hexdigest(),
        paired_executions=len(identities), method_executions=2 * len(identities),
        timing_statistic='Mean and sample standard deviation over five fixed-input executions',
        ratio_statistic='Median of the five paired full/local ratios',
        cluster_count='Nonempty communities in the reported partition of the entire graph',
        cells=cells)
    (journal/'analysis/confirmatory_results.json').write_text(json.dumps(result, indent=2)+'\n')
    return result
