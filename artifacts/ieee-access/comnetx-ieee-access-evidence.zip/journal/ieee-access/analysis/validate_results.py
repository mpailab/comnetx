#!/usr/bin/env python3
"""Regenerate the IEEE Access article from ieee-access-2026-2.

The active entry point delegates selection, validation, tables, and quantitative
plots to current_results.py. This module supplies shared vector drawing helpers
and the method diagram. Historical validators and legacy_main are retained for
reference only; they are not called by the article regeneration command.
"""

from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev
from typing import Any, Iterable

import reportlab
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[3]
JOURNAL = ROOT / "journal" / "ieee-access"
ANALYSIS = JOURNAL / "analysis"
FIGURES = JOURNAL / "figures"
GENERATED = JOURNAL / "generated"
REPORTLAB_FONTS = Path(reportlab.__file__).resolve().parent / "fonts"
FIGURE_FONT = "ComNetXFigureSans"
FIGURE_FONT_BOLD = "ComNetXFigureSans-Bold"
pdfmetrics.registerFont(TTFont(FIGURE_FONT, REPORTLAB_FONTS / "Vera.ttf"))
pdfmetrics.registerFont(TTFont(FIGURE_FONT_BOLD, REPORTLAB_FONTS / "VeraBd.ttf"))

EXPERIMENTS = (
    ROOT
    / "results"
    / "icdm-2026-1"
    / "measurements"
    / "experiment_measurements.json"
)
WORKLOADS = (
    ROOT
    / "results"
    / "icdm-2026-1"
    / "measurements"
    / "workload_profiles.json"
)
NEIGHBORHOODS = (
    ROOT
    / "results"
    / "icdm-2026-1"
    / "measurements"
    / "neighborhood_measurements.json"
)
CUT_METRICS = (
    ROOT
    / "results"
    / "icdm-2026-1"
    / "measurements"
    / "cut_metrics.json"
)
DATA_INFO = {
    "dyn_cora": ROOT / "datasets-info" / "json" / "dyn_attr.json",
    "dyn_acm": ROOT / "datasets-info" / "json" / "dyn_attr.json",
    "dyn_citeseer": ROOT / "datasets-info" / "json" / "dyn_attr.json",
    "dyn_pubmed": ROOT / "datasets-info" / "json" / "dyn_attr.json",
    "patent": ROOT / "datasets-info" / "json" / "tgc.json",
    "arxivmath": ROOT / "datasets-info" / "json" / "tgc.json",
}

DATASETS = (
    "dyn_cora",
    "dyn_acm",
    "dyn_citeseer",
    "patent",
    "dyn_pubmed",
    "arxivmath",
)
from current_results import DISPLAY

STREAM_KIND = {
    "dyn_cora": "stored artificial order",
    "dyn_acm": "stored artificial order",
    "dyn_citeseer": "stored artificial order",
    "dyn_pubmed": "stored artificial order",
    "patent": "timestamp order",
    "arxivmath": "timestamp order",
}
EXPECTED_SHORT_COUNTS = {
    "dyn_cora": 1,
    "dyn_acm": 1,
    "dyn_citeseer": 1,
    "patent": 1,
    "dyn_pubmed": 5,
    "arxivmath": 5,
}
EXPECTED_SHORT_UPDATES = {
    "dyn_cora": 10,
    "dyn_acm": 10,
    "dyn_citeseer": 8,
    "patent": 10,
    "dyn_pubmed": 10,
    "arxivmath": 10,
}

BLUE = "#2F5D8A"
ORANGE = "#C5672A"
INK = "#252A2E"
MID = "#727A80"
LIGHT = "#D9DEE2"

def load_records(path: Path) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = payload["records"]
    assert payload["record_count"] == len(records), path
    return records


def select(
    records: Iterable[dict[str, Any]],
    **criteria: Any,
) -> list[dict[str, Any]]:
    return [
        record
        for record in records
        if all(record.get(key) == value for key, value in criteria.items())
    ]


def only(records: list[dict[str, Any]], context: str) -> dict[str, Any]:
    assert len(records) == 1, f"{context}: expected one record, got {len(records)}"
    return records[0]


def avg(records: list[dict[str, Any]], key: str) -> float:
    assert records
    return mean(float(record[key]) for record in records)


def sd(records: list[dict[str, Any]], key: str) -> float:
    values = [float(record[key]) for record in records]
    return stdev(values) if len(values) > 1 else 0.0


def record_ids(records: Iterable[dict[str, Any]]) -> list[str]:
    return [record["bundle_record_id"] for record in records]


def fmt_time(value: float) -> str:
    if value >= 100:
        return f"{value:.1f}"
    if value >= 10:
        return f"{value:.2f}"
    return f"{value:.3f}"


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def data_info() -> dict[str, dict[str, Any]]:
    cache: dict[Path, dict[str, Any]] = {}
    out: dict[str, dict[str, Any]] = {}
    for dataset, path in DATA_INFO.items():
        if path not in cache:
            cache[path] = json.loads(path.read_text(encoding="utf-8"))
        out[dataset] = cache[path][dataset]
    return out


def validate_short_horizon(
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for dataset in DATASETS:
        common = {
            "measurement_family": "single_container_real_graph",
            "base_dataset": dataset,
            "batch_strategy": "999:10",
            "method": "leidenalg",
        }
        full = select(records, **common, mode="naive")
        local = select(
            records,
            **common,
            mode="smart",
            subcoms_depth="3",
            radius="1",
        )
        expected = EXPECTED_SHORT_COUNTS[dataset]
        assert len(full) == expected, (dataset, "full", len(full))
        assert len(local) == expected, (dataset, "local", len(local))
        expected_updates = EXPECTED_SHORT_UPDATES[dataset]
        assert {record["updates"] for record in full + local} == {
            expected_updates
        }
        assert all(len(record["series"]) == record["updates"] for record in full + local)

        full_time = avg(full, "total_time")
        local_time = avg(local, "total_time")
        out[dataset] = {
            "updates": expected_updates,
            "repetitions": expected,
            "full": {
                "q": avg(full, "final_modularity"),
                "nmi": avg(full, "final_nmi"),
                "time_mean": full_time,
                "time_sd": sd(full, "total_time"),
                "record_ids": record_ids(full),
            },
            "local": {
                "q": avg(local, "final_modularity"),
                "nmi": avg(local, "final_nmi"),
                "time_mean": local_time,
                "time_sd": sd(local, "total_time"),
                "record_ids": record_ids(local),
            },
            "delta_q": avg(local, "final_modularity")
            - avg(full, "final_modularity"),
            "delta_nmi": avg(local, "final_nmi") - avg(full, "final_nmi"),
            "speedup": full_time / local_time,
        }
    return out


def validate_backend_repeatability(
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for dataset in ("dyn_pubmed", "arxivmath"):
        out[dataset] = {}
        for method in ("leidenalg", "dfleiden", "s2cag"):
            base_mode = "dynamic" if method == "dfleiden" else "naive"
            common = {
                "measurement_family": "single_container_real_graph",
                "base_dataset": dataset,
                "batch_strategy": "999:10",
                "method": method,
            }
            base = select(records, **common, mode=base_mode)
            local = select(
                records,
                **common,
                mode="smart",
                subcoms_depth="3",
                radius="1",
            )
            assert len(base) == len(local) == 5, (dataset, method)
            assert all(record["updates"] == 10 for record in base + local)
            if method == "s2cag":
                assert {record["feature_mode"] for record in base + local} == {
                    "dataset"
                }
                assert {str(record["iterations"]) for record in base + local} == {"10"}
            base_time = avg(base, "total_time")
            local_time = avg(local, "total_time")
            out[dataset][method] = {
                "base_mode": base_mode,
                "base": {
                    "q": avg(base, "final_modularity"),
                    "nmi": avg(base, "final_nmi"),
                    "time_mean": base_time,
                    "time_sd": sd(base, "total_time"),
                    "record_ids": record_ids(base),
                },
                "local": {
                    "q": avg(local, "final_modularity"),
                    "nmi": avg(local, "final_nmi"),
                    "time_mean": local_time,
                    "time_sd": sd(local, "total_time"),
                    "record_ids": record_ids(local),
                },
                "speedup": base_time / local_time,
            }
    return out


def validate_long_horizon(records: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for dataset in ("dyn_pubmed", "arxivmath"):
        out[dataset] = {}
        for method in ("leidenalg", "dfleiden"):
            base_mode = "dynamic" if method == "dfleiden" else "naive"
            common = {
                "measurement_family": "single_container_real_graph",
                "base_dataset": dataset,
                "batch_strategy": "9:500",
                "method": method,
                "force_undirected": True,
                "updates": 500,
            }
            base = only(select(records, **common, mode=base_mode), f"{dataset}/{method}/base")
            local = only(
                select(
                    records,
                    **common,
                    mode="smart",
                    subcoms_depth="3",
                    radius="1",
                ),
                f"{dataset}/{method}/local",
            )
            assert len(base["series"]) == len(local["series"]) == 500
            q_deltas = [
                float(local_row["modularity"]) - float(base_row["modularity"])
                for base_row, local_row in zip(base["series"], local["series"])
            ]
            worst_index = min(range(len(q_deltas)), key=q_deltas.__getitem__)
            out[dataset][method] = {
                "base_mode": base_mode,
                "base": {
                    "q": float(base["final_modularity"]),
                    "nmi": float(base["final_nmi"]),
                    "time": float(base["total_time"]),
                    "record_id": base["bundle_record_id"],
                },
                "local": {
                    "q": float(local["final_modularity"]),
                    "nmi": float(local["final_nmi"]),
                    "time": float(local["total_time"]),
                    "record_id": local["bundle_record_id"],
                },
                "delta_q": float(local["final_modularity"])
                - float(base["final_modularity"]),
                "delta_nmi": float(local["final_nmi"])
                - float(base["final_nmi"]),
                "speedup": float(base["total_time"]) / float(local["total_time"]),
                "trajectory_delta_q_mean": mean(q_deltas),
                "trajectory_delta_q_worst": q_deltas[worst_index],
                "trajectory_delta_q_worst_update": worst_index + 1,
                "series": {
                    "base_q": [float(row["modularity"]) for row in base["series"]],
                    "local_q": [float(row["modularity"]) for row in local["series"]],
                    "base_time": [float(row["time"]) for row in base["series"]],
                    "local_time": [float(row["time"]) for row in local["series"]],
                },
            }
    return out


DSBM_RE = re.compile(
    r"^dsbm-(?P<regime>random|hubs|community)-1024-58-mc"
    r"(?P<changes>290|1450)-(?P<seed>4[2-6])$"
)


def validate_dsbm(records: list[dict[str, Any]]) -> dict[str, Any]:
    dsbm = select(records, measurement_family="single_container_dsbm")
    assert len(dsbm) == 60
    grouped: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for record in dsbm:
        match = DSBM_RE.match(record["base_dataset"])
        assert match, record["base_dataset"]
        assert record["batch_strategy"] == "0:99"
        assert record["updates"] == len(record["series"]) == 99
        grouped[(int(match["changes"]), match["regime"])].append(record)

    out: dict[str, Any] = {}
    for changes in (290, 1450):
        rate = "0.01" if changes == 290 else "0.05"
        out[rate] = {}
        for regime in ("random", "hubs", "community"):
            rows = grouped[(changes, regime)]
            assert len(rows) == 10
            by_seed: dict[int, dict[str, dict[str, Any]]] = defaultdict(dict)
            for record in rows:
                match = DSBM_RE.match(record["base_dataset"])
                assert match
                by_seed[int(match["seed"])][record["mode"]] = record
            assert sorted(by_seed) == list(range(42, 47))

            paired = []
            for seed, modes in sorted(by_seed.items()):
                assert set(modes) == {"naive", "smart"}
                base, local = modes["naive"], modes["smart"]
                paired.append(
                    {
                        "seed": seed,
                        "speedup": float(base["total_time"])
                        / float(local["total_time"]),
                        "delta_q": float(local["final_modularity"])
                        - float(base["final_modularity"]),
                        "delta_nmi": float(local["final_nmi"])
                        - float(base["final_nmi"]),
                        "base_id": base["bundle_record_id"],
                        "local_id": local["bundle_record_id"],
                    }
                )
            speedups = [row["speedup"] for row in paired]
            out[rate][regime] = {
                "changed_edges_per_update": changes,
                "seeds": 5,
                "speedup_mean": mean(speedups),
                "speedup_sd": stdev(speedups),
                "speedup_min": min(speedups),
                "speedup_max": max(speedups),
                "worst_delta_q": min(row["delta_q"] for row in paired),
                "worst_delta_nmi": min(row["delta_nmi"] for row in paired),
                "paired": paired,
            }
    return out


def validate_workloads(
    records: list[dict[str, Any]],
    nodes: dict[str, int],
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for dataset in ("dyn_cora", "dyn_pubmed", "arxivmath"):
        out[dataset] = {}
        for variant in ("full", "no_closure", "no_contraction"):
            record = only(
                select(
                    records,
                    measurement_family="single_container_workload_profiles",
                    base_dataset=dataset,
                    method="leidenalg",
                    mode="smart",
                    variant=variant,
                    subcoms_depth=3,
                    radius=1,
                ),
                f"workload/{dataset}/{variant}",
            )
            profile = record["profile"]
            assert record["aggregation"] == "sum"
            assert record["device"] == "cuda"
            rows = profile["rows"]
            assert len(rows) == record["updates_profiled"]
            contracted = [
                row["contracted_nodes_by_level"][-1] / nodes[dataset] * 100.0
                for row in rows
            ]
            closure = [
                row["closure_vertices_by_level"][-1] / nodes[dataset] * 100.0
                for row in rows
            ]
            out[dataset][variant] = {
                "updates": record["updates_profiled"],
                "q": float(record["final_modularity"]),
                "time": float(record["total_profiled_time"]),
                "contracted_nodes_pct_mean": mean(contracted),
                "closure_nodes_pct_mean": mean(closure),
                "record_id": record["bundle_record_id"],
            }
    return out


def validate_neighborhoods(records: list[dict[str, Any]]) -> dict[str, Any]:
    assert len(records) == 6
    out: dict[str, Any] = {}
    for dataset in DATASETS:
        record = only(
            select(
                records,
                measurement_family="article_neighborhood_growth",
                base_dataset=dataset,
            ),
            f"neighborhood/{dataset}",
        )
        assert len(record["neighborhood_series"]) == record["updates"]
        out[dataset] = {
            "updates": record["updates"],
            "affected_mean": float(record["B0_mean"]),
            "b1_pct_mean": float(record["B1_pct_mean"]),
            "b2_pct_mean": float(record["B2_pct_mean"]),
            "b3_pct_mean": float(record["B3_pct_mean"]),
            "b4_pct_mean": float(record["B4_pct_mean"]),
            "record_id": record["bundle_record_id"],
        }
    return out


def validate_topology_ablation(
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for dataset in ("dyn_cora", "dyn_pubmed", "arxivmath"):
        full_records = select(
            records,
            measurement_family="single_container_real_graph",
            base_dataset=dataset,
            batch_strategy="999:10",
            method="leidenalg",
            mode="naive",
        )
        assert len(full_records) == EXPECTED_SHORT_COUNTS[dataset]
        full_time = avg(full_records, "total_time")
        out[dataset] = {
            "full": {
                "q": avg(full_records, "final_modularity"),
                "time": full_time,
                "record_ids": record_ids(full_records),
            },
            "points": [],
        }
        for level in range(1, 5):
            for radius in range(3):
                if (level, radius) == (3, 1):
                    family = "single_container_real_graph"
                elif dataset == "dyn_cora":
                    family = "article_completion_real_graph"
                else:
                    family = "single_container_real_graph"
                matches = select(
                    records,
                    measurement_family=family,
                    base_dataset=dataset,
                    batch_strategy="999:10",
                    method="leidenalg",
                    mode="smart",
                    subcoms_depth=str(level),
                    radius=str(radius),
                )
                expected = (
                    EXPECTED_SHORT_COUNTS[dataset]
                    if (level, radius) == (3, 1)
                    else 1
                )
                assert len(matches) == expected, (
                    dataset,
                    level,
                    radius,
                    family,
                    len(matches),
                )
                local_time = avg(matches, "total_time")
                out[dataset]["points"].append(
                    {
                        "level": level,
                        "radius": radius,
                        "q": avg(matches, "final_modularity"),
                        "time": local_time,
                        "speedup": full_time / local_time,
                        "repetitions": len(matches),
                        "record_ids": record_ids(matches),
                    }
                )
        assert len(out[dataset]["points"]) == 12
    return out


def validate_directed_control(records: list[dict[str, Any]]) -> dict[str, Any]:
    directed = select(
        records,
        measurement_family="single_container_directed_control",
        batch_strategy="999:10",
        method="leidenalg",
    )
    assert len(directed) == 4
    out: dict[str, Any] = {}
    for dataset in ("dyn_pubmed", "arxivmath"):
        full = only(
            select(directed, base_dataset=dataset, mode="naive"),
            f"directed/{dataset}/full",
        )
        local = only(
            select(
                directed,
                base_dataset=dataset,
                mode="smart",
                subcoms_depth="3",
                radius="1",
            ),
            f"directed/{dataset}/local",
        )
        assert full["force_undirected"] is local["force_undirected"] is False
        assert full["updates"] == local["updates"] == 10
        assert len(full["series"]) == len(local["series"]) == 10
        out[dataset] = {
            "updates": 10,
            "full": {
                "q": float(full["final_modularity"]),
                "nmi": float(full["final_nmi"]),
                "time": float(full["total_time"]),
                "record_id": full["bundle_record_id"],
            },
            "local": {
                "q": float(local["final_modularity"]),
                "nmi": float(local["final_nmi"]),
                "time": float(local["total_time"]),
                "record_id": local["bundle_record_id"],
            },
            "speedup": float(full["total_time"]) / float(local["total_time"]),
        }
    return out


def validate_gamma_sweep(records: list[dict[str, Any]]) -> dict[str, Any]:
    sweep = select(
        records,
        measurement_family="gamma_sweep",
        batch_strategy="999:50",
        method="leidenalg",
    )
    assert len(sweep) == 12
    expected_updates = {"dyn_pubmed": 44, "arxivmath": 50}
    out: dict[str, Any] = {}
    for dataset in ("dyn_pubmed", "arxivmath"):
        out[dataset] = {}
        for gamma in (0.5, 1.0, 2.0):
            stored_gamma: str | None = None if gamma == 1.0 else f"{gamma:g}"
            full = only(
                select(
                    sweep,
                    base_dataset=dataset,
                    mode="naive",
                    resolution=stored_gamma,
                ),
                f"gamma/{dataset}/{gamma}/full",
            )
            local = only(
                select(
                    sweep,
                    base_dataset=dataset,
                    mode="smart",
                    resolution=stored_gamma,
                    subcoms_depth="3",
                    radius="1",
                ),
                f"gamma/{dataset}/{gamma}/local",
            )
            updates = expected_updates[dataset]
            assert full["force_undirected"] is local["force_undirected"] is True
            assert full["updates"] == local["updates"] == updates
            assert len(full["series"]) == len(local["series"]) == updates
            full_q = float(full["final_modularity"])
            local_q = float(local["final_modularity"])
            full_time = float(full["total_time"])
            local_time = float(local["total_time"])
            out[dataset][str(gamma)] = {
                "updates": updates,
                "gamma": gamma,
                "full_q": full_q,
                "local_q": local_q,
                "delta_q": local_q - full_q,
                "full_nmi": float(full["final_nmi"]),
                "local_nmi": float(local["final_nmi"]),
                "full_time": full_time,
                "local_time": local_time,
                "speedup": full_time / local_time,
                "record_ids": [full["bundle_record_id"], local["bundle_record_id"]],
            }
    return out


def validate_feature_ablation(records: list[dict[str, Any]]) -> dict[str, Any]:
    rows = select(
        records,
        measurement_family="single_container_real_graph",
        batch_strategy="999:100",
        method="s2cag",
    )
    rows = [row for row in rows if row["base_dataset"] in {"dyn_cora", "dyn_pubmed"}]
    assert len(rows) == 12
    expected_updates = {"dyn_cora": 10, "dyn_pubmed": 44}
    out: dict[str, Any] = {}
    for dataset in ("dyn_cora", "dyn_pubmed"):
        out[dataset] = {}
        for feature_mode in ("dataset", "random", "onehot"):
            out[dataset][feature_mode] = {}
            for mode in ("naive", "smart"):
                criteria: dict[str, Any] = {
                    "base_dataset": dataset,
                    "feature_mode": feature_mode,
                    "mode": mode,
                }
                if mode == "smart":
                    criteria.update(subcoms_depth="3", radius="1")
                record = only(
                    select(rows, **criteria),
                    f"features/{dataset}/{feature_mode}/{mode}",
                )
                updates = expected_updates[dataset]
                assert record["updates"] == len(record["series"]) == updates
                assert str(record["iterations"]) == "10"
                assert record["force_undirected"] is (dataset == "dyn_pubmed")
                if mode == "smart":
                    assert record["aggregation"] == "norm"
                out[dataset][feature_mode][mode] = {
                    "updates": updates,
                    "q": float(record["final_modularity"]),
                    "nmi": float(record["final_nmi"]),
                    "time": float(record["total_time"]),
                    "record_id": record["bundle_record_id"],
                }
    return out


def validate_cut_metrics(records: list[dict[str, Any]]) -> dict[str, Any]:
    assert len(records) == 4
    definitions = {record["cut_metrics"]["definition"] for record in records}
    assert len(definitions) == 1
    out: dict[str, Any] = {"definition": definitions.pop(), "datasets": {}}
    for dataset in ("dyn_pubmed", "arxivmath"):
        out["datasets"][dataset] = {}
        for mode in ("naive", "smart"):
            record = only(
                select(
                    records,
                    measurement_family="leiden_cut_metrics",
                    base_dataset=dataset,
                    batch_strategy="999:10",
                    method="leidenalg",
                    mode=mode,
                ),
                f"cut/{dataset}/{mode}",
            )
            assert record["force_undirected"] is True
            assert record["resolution"] == 1.0
            assert record["updates"] == 10
            if mode == "smart":
                assert record["smart_depth"] == 3 and record["smart_radius"] == 1
            metrics = record["cut_metrics"]
            assert metrics["num_nodes"] > 0
            assert metrics["num_clusters"] == metrics["nonzero_volume_clusters"]
            out["datasets"][dataset][mode] = {
                "q": float(record["final_modularity"]),
                "conductance_mean": float(metrics["conductance_mean"]),
                "ncut": float(metrics["ncut"]),
                "clusters": int(metrics["num_clusters"]),
                "record_id": record["bundle_record_id"],
            }
    return out


def emit_rows(
    info: dict[str, dict[str, Any]],
    short: dict[str, Any],
    repeatability: dict[str, Any],
    long_horizon: dict[str, Any],
    workloads: dict[str, Any],
    neighborhoods: dict[str, Any],
    dsbm: dict[str, Any],
    topology: dict[str, Any],
    directed: dict[str, Any],
    gamma_sweep: dict[str, Any],
    feature_ablation: dict[str, Any],
    cut_metrics: dict[str, Any],
) -> None:
    dataset_rows = []
    short_rows = []
    for dataset in DATASETS:
        meta = info[dataset]
        dataset_rows.append(
            f"{DISPLAY[dataset]} & {meta['n']:,} & {meta['m']:,} & "
            f"{STREAM_KIND[dataset]} & {short[dataset]['updates']} \\\\"
        )
        row = short[dataset]
        short_rows.append(
            f"{DISPLAY[dataset]} & {row['full']['q']:.4f} & "
            f"{row['local']['q']:.4f} & {row['full']['nmi']:.3f} & "
            f"{row['local']['nmi']:.3f} & {fmt_time(row['full']['time_mean'])} & "
            f"{fmt_time(row['local']['time_mean'])} & {row['speedup']:.1f}$\\times$ \\\\"
        )

    backend_rows = []
    backend_names = {
        "leidenalg": "Leiden",
        "dfleiden": "DF-Leiden",
        "s2cag": "S$^2$CAG",
    }
    for dataset in ("dyn_pubmed", "arxivmath"):
        for method in ("leidenalg", "dfleiden", "s2cag"):
            row = repeatability[dataset][method]
            base, local = row["base"], row["local"]
            backend_rows.append(
                f"{DISPLAY[dataset]} & {backend_names[method]} & "
                f"{base['q']:.3f}/{local['q']:.3f} & "
                f"{base['nmi']:.3f}/{local['nmi']:.3f} & "
                f"{fmt_time(base['time_mean'])} ({base['time_sd']:.3f})/"
                f"{fmt_time(local['time_mean'])} ({local['time_sd']:.3f}) & "
                f"{row['speedup']:.1f}$\\times$ \\\\"
            )

    long_rows = []
    for dataset in ("dyn_pubmed", "arxivmath"):
        for method in ("leidenalg", "dfleiden"):
            row = long_horizon[dataset][method]
            base, local = row["base"], row["local"]
            long_rows.append(
                f"{DISPLAY[dataset]} & {backend_names[method]} & "
                f"{base['q']:.3f}/{local['q']:.3f} & "
                f"{base['nmi']:.3f}/{local['nmi']:.3f} & "
                f"{fmt_time(base['time'])}/{fmt_time(local['time'])} & "
                f"{row['speedup']:.2f}$\\times$ \\\\"
            )

    workload_rows = []
    variant_names = {
        "full": "Full ComNetX",
        "no_closure": "Radius-only scope",
        "no_contraction": "Vertex-level graphs",
    }
    for dataset in ("dyn_cora", "dyn_pubmed", "arxivmath"):
        for variant in ("full", "no_closure", "no_contraction"):
            row = workloads[dataset][variant]
            workload_rows.append(
                f"{DISPLAY[dataset]} & {variant_names[variant]} & {row['updates']} & "
                f"{row['q']:.3f} & {fmt_time(row['time'])} & "
                f"{row['closure_nodes_pct_mean']:.2f} & "
                f"{row['contracted_nodes_pct_mean']:.2f} \\\\"
            )

    neighborhood_rows = []
    for dataset in DATASETS:
        row = neighborhoods[dataset]
        neighborhood_rows.append(
            f"{DISPLAY[dataset]} & {row['affected_mean']:.1f} & "
            f"{row['b1_pct_mean']:.2f} & {row['b2_pct_mean']:.2f} & "
            f"{row['b3_pct_mean']:.2f} & {row['b4_pct_mean']:.2f} \\\\"
        )

    dsbm_rows = []
    regime_names = {
        "random": "random",
        "hubs": "hub-centered",
        "community": "community-internal",
    }
    for rate in ("0.01", "0.05"):
        for regime in ("random", "hubs", "community"):
            row = dsbm[rate][regime]
            dsbm_rows.append(
                f"{row['changed_edges_per_update']} & {regime_names[regime]} & "
                f"{row['speedup_mean']:.2f} $\\pm$ {row['speedup_sd']:.3f} & "
                f"${row['worst_delta_q']:.4f}$ & "
                f"${row['worst_delta_nmi']:.4f}$ \\\\"
            )

    gamma_rows = []
    for dataset in ("dyn_pubmed", "arxivmath"):
        for gamma in (0.5, 1.0, 2.0):
            row = gamma_sweep[dataset][str(gamma)]
            gamma_rows.append(
                f"{DISPLAY[dataset]} & {gamma:g} & {row['updates']} & "
                f"{row['full_q']:.4f}/{row['local_q']:.4f} & "
                f"${row['delta_q']:.4f}$ & {row['speedup']:.1f}$\\times$ \\\\"
            )

    feature_rows = []
    feature_names = {
        "dataset": "dataset features",
        "random": "random features",
        "onehot": "one-hot features",
    }
    mode_names = {"naive": "Full", "smart": "ComNetX"}
    for feature_mode in ("dataset", "random", "onehot"):
        for mode in ("naive", "smart"):
            cora = feature_ablation["dyn_cora"][feature_mode][mode]
            pubmed = feature_ablation["dyn_pubmed"][feature_mode][mode]
            feature_rows.append(
                f"{mode_names[mode]}, {feature_names[feature_mode]} & "
                f"${cora['q']:.3f}$/{cora['nmi']:.3f}/{fmt_time(cora['time'])} & "
                f"${pubmed['q']:.3f}$/{pubmed['nmi']:.3f}/{fmt_time(pubmed['time'])} \\\\"
            )

    directed_rows = []
    for dataset in ("dyn_pubmed", "arxivmath"):
        row = directed[dataset]
        full, local = row["full"], row["local"]
        directed_rows.append(
            f"{DISPLAY[dataset]} & {full['q']:.3f}/{local['q']:.3f} & "
            f"{full['nmi']:.3f}/{local['nmi']:.3f} & "
            f"{fmt_time(full['time'])}/{fmt_time(local['time'])} & "
            f"{row['speedup']:.1f}$\\times$ \\\\"
        )

    cut_rows = []
    cut_mode_names = {"naive": "Full", "smart": "ComNetX"}
    for dataset in ("dyn_pubmed", "arxivmath"):
        for mode in ("naive", "smart"):
            row = cut_metrics["datasets"][dataset][mode]
            cut_rows.append(
                f"{DISPLAY[dataset]} & {cut_mode_names[mode]} & {row['q']:.3f} & "
                f"{row['clusters']:,} & {row['conductance_mean']:.6f} & "
                f"{row['ncut']:.3f} \\\\"
            )

    # Keep the closing rule inside each input file.  A file boundary between a
    # row terminator and booktabs' \bottomrule can make TeX reject \noalign.
    write_text(GENERATED / "dataset_rows.tex", "\n".join(dataset_rows) + "\n\\bottomrule")
    write_text(GENERATED / "short_results_rows.tex", "\n".join(short_rows) + "\n\\bottomrule")
    write_text(GENERATED / "backend_rows.tex", "\n".join(backend_rows) + "\n\\bottomrule")
    write_text(GENERATED / "long_horizon_rows.tex", "\n".join(long_rows) + "\n\\bottomrule")
    write_text(GENERATED / "workload_rows.tex", "\n".join(workload_rows) + "\n\\bottomrule")
    write_text(GENERATED / "neighborhood_rows.tex", "\n".join(neighborhood_rows) + "\n\\bottomrule")
    write_text(GENERATED / "dsbm_rows.tex", "\n".join(dsbm_rows) + "\n\\bottomrule")
    write_text(GENERATED / "gamma_rows.tex", "\n".join(gamma_rows) + "\n\\bottomrule")
    write_text(
        GENERATED / "feature_ablation_rows.tex",
        "\n".join(feature_rows) + "\n\\bottomrule",
    )
    write_text(GENERATED / "directed_rows.tex", "\n".join(directed_rows) + "\n\\bottomrule")
    write_text(GENERATED / "cut_metric_rows.tex", "\n".join(cut_rows) + "\n\\bottomrule")

    arxiv_short = short["arxivmath"]
    arxiv_long = long_horizon["arxivmath"]["leidenalg"]
    pubmed_topology = next(
        point
        for point in topology["dyn_pubmed"]["points"]
        if point["level"] == 2 and point["radius"] == 0
    )
    arxiv_topology = next(
        point
        for point in topology["arxivmath"]["points"]
        if point["level"] == 1 and point["radius"] == 0
    )
    macros = f"""
\\newcommand{{\\ArxivShortSpeedup}}{{{arxiv_short['speedup']:.1f}}}
\\newcommand{{\\ArxivShortFullQ}}{{{arxiv_short['full']['q']:.3f}}}
\\newcommand{{\\ArxivShortLocalQ}}{{{arxiv_short['local']['q']:.3f}}}
\\newcommand{{\\ArxivShortQGap}}{{{abs(arxiv_short['delta_q']):.3f}}}
\\newcommand{{\\ArxivLongSpeedup}}{{{arxiv_long['speedup']:.1f}}}
\\newcommand{{\\ArxivLongFullQ}}{{{arxiv_long['base']['q']:.3f}}}
\\newcommand{{\\ArxivLongLocalQ}}{{{arxiv_long['local']['q']:.3f}}}
\\newcommand{{\\ArxivLongQGap}}{{{abs(arxiv_long['delta_q']):.3f}}}
\\newcommand{{\\ArxivLongFullNMI}}{{{arxiv_long['base']['nmi']:.3f}}}
\\newcommand{{\\ArxivLongLocalNMI}}{{{arxiv_long['local']['nmi']:.3f}}}
\\newcommand{{\\DSBMHighRandomSpeedup}}{{{dsbm['0.05']['random']['speedup_mean']:.2f}}}
\\newcommand{{\\DSBMHighHubSpeedup}}{{{dsbm['0.05']['hubs']['speedup_mean']:.2f}}}
\\newcommand{{\\PubMedTopologyQ}}{{{pubmed_topology['q']:.4f}}}
\\newcommand{{\\PubMedTopologySpeedup}}{{{pubmed_topology['speedup']:.1f}}}
\\newcommand{{\\ArxivTopologyQ}}{{{arxiv_topology['q']:.4f}}}
\\newcommand{{\\ArxivTopologySpeedup}}{{{arxiv_topology['speedup']:.1f}}}
"""
    write_text(GENERATED / "metrics_macros.tex", macros)


def new_canvas(
    name: str,
    width_in: float,
    height_in: float,
    *,
    output_path: Path | None = None,
) -> tuple[canvas.Canvas, float, float]:
    """Create a deterministic vector PDF canvas in the article figure folder."""
    path = output_path if output_path is not None else FIGURES / name
    path.parent.mkdir(parents=True, exist_ok=True)
    width = width_in * 72.0
    height = height_in * 72.0
    pdf = canvas.Canvas(
        str(path),
        pagesize=(width, height),
        pageCompression=1,
        invariant=1,
        initialFontName=FIGURE_FONT,
    )
    pdf.setTitle("ComNetX validated evidence figure")
    pdf.setAuthor("ComNetX authors")
    pdf.setCreator("journal/ieee-access/analysis/validate_results.py")
    return pdf, width, height


def draw_text(
    pdf: canvas.Canvas,
    x: float,
    y: float,
    value: str,
    size: float = 7.0,
    font: str = FIGURE_FONT,
    align: str = "left",
    color: str = INK,
) -> None:
    pdf.setFillColor(HexColor(color))
    pdf.setFont(font, size)
    if align == "center":
        pdf.drawCentredString(x, y, value)
    elif align == "right":
        pdf.drawRightString(x, y, value)
    else:
        pdf.drawString(x, y, value)


def draw_backed_text(
    pdf: canvas.Canvas,
    x: float,
    y: float,
    value: str,
    size: float,
    *,
    font: str = FIGURE_FONT,
    align: str = "left",
    color: str = INK,
    pad_x: float = 1.2,
    pad_y: float = 0.7,
) -> None:
    """Draw a small opaque text halo so annotations stay clear of marks."""
    width = stringWidth(value, font, size)
    if align == "center":
        left = x - width / 2
    elif align == "right":
        left = x - width
    else:
        left = x
    pdf.saveState()
    pdf.setFillColor(HexColor("#FFFFFF"))
    pdf.setStrokeColor(HexColor("#FFFFFF"))
    pdf.roundRect(
        left - pad_x,
        y - size * 0.24 - pad_y,
        width + 2 * pad_x,
        size * 1.02 + 2 * pad_y,
        1.1,
        stroke=0,
        fill=1,
    )
    pdf.restoreState()
    draw_text(pdf, x, y, value, size, font, align, color)


def draw_vertical_text(
    pdf: canvas.Canvas,
    x: float,
    y: float,
    value: str,
    size: float = 6.3,
    font: str = FIGURE_FONT,
) -> None:
    """Draw a centered vertical axis label without overlapping tick labels."""
    pdf.saveState()
    pdf.translate(x, y)
    pdf.rotate(90)
    draw_text(pdf, 0, -size / 3, value, size=size, font=font, align="center")
    pdf.restoreState()


def wrapped_lines(value: str, font: str, size: float, max_width: float) -> list[str]:
    words = value.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = word if not current else f"{current} {word}"
        if stringWidth(candidate, font, size) <= max_width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_wrapped(
    pdf: canvas.Canvas,
    x: float,
    y: float,
    value: str,
    max_width: float,
    size: float = 6.5,
    leading: float = 8.0,
    font: str = FIGURE_FONT,
    color: str = INK,
) -> None:
    for index, line in enumerate(wrapped_lines(value, font, size, max_width)):
        draw_text(pdf, x, y - index * leading, line, size=size, font=font, color=color)


def draw_marker(
    pdf: canvas.Canvas,
    x: float,
    y: float,
    shape: str,
    radius: float,
    stroke: str,
    fill: str | None,
) -> None:
    pdf.setStrokeColor(HexColor(stroke))
    pdf.setFillColor(HexColor(fill) if fill else HexColor("#FFFFFF"))
    pdf.setLineWidth(0.8)
    if shape == "circle":
        pdf.circle(x, y, radius, stroke=1, fill=1)
    elif shape == "square":
        pdf.rect(x - radius, y - radius, 2 * radius, 2 * radius, stroke=1, fill=1)
    elif shape == "triangle":
        path = pdf.beginPath()
        path.moveTo(x, y + radius)
        path.lineTo(x - radius, y - radius)
        path.lineTo(x + radius, y - radius)
        path.close()
        pdf.drawPath(path, stroke=1, fill=1)
    elif shape == "star":
        path = pdf.beginPath()
        for point in range(10):
            angle = math.pi / 2 + point * math.pi / 5
            r = radius if point % 2 == 0 else radius * 0.42
            px = x + math.cos(angle) * r
            py = y + math.sin(angle) * r
            if point == 0:
                path.moveTo(px, py)
            else:
                path.lineTo(px, py)
        path.close()
        pdf.drawPath(path, stroke=1, fill=1)
    else:
        raise ValueError(shape)


def draw_panel_axes(
    pdf: canvas.Canvas,
    x0: float,
    y0: float,
    width: float,
    height: float,
    xmin: float,
    xmax: float,
    ymin: float,
    ymax: float,
    xticks: list[float],
    yticks: list[float],
    xlog: bool = False,
    xformat: str = "{:.0f}",
    yformat: str = "{:.2f}",
    tick_size: float = 5.7,
) -> tuple[Any, Any]:
    def tx(value: float) -> float:
        if xlog:
            return x0 + (math.log10(value) - math.log10(xmin)) / (
                math.log10(xmax) - math.log10(xmin)
            ) * width
        return x0 + (value - xmin) / (xmax - xmin) * width

    def ty(value: float) -> float:
        return y0 + (value - ymin) / (ymax - ymin) * height

    pdf.setStrokeColor(HexColor(INK))
    pdf.setLineWidth(0.6)
    pdf.line(x0, y0, x0, y0 + height)
    pdf.line(x0, y0, x0 + width, y0)
    for value in yticks:
        y = ty(value)
        pdf.setStrokeColor(HexColor(LIGHT))
        pdf.setLineWidth(0.45)
        pdf.line(x0, y, x0 + width, y)
        draw_text(
            pdf,
            x0 - 3,
            y - tick_size * 0.38,
            yformat.format(value),
            tick_size,
            align="right",
        )
    for value in xticks:
        if value < xmin or value > xmax:
            continue
        x = tx(value)
        pdf.setStrokeColor(HexColor(INK))
        pdf.setLineWidth(0.45)
        pdf.line(x, y0, x, y0 - 2.5)
        draw_text(pdf, x, y0 - 10.5, xformat.format(value), tick_size, align="center")
    return tx, ty


def polyline(
    pdf: canvas.Canvas,
    points: list[tuple[float, float]],
    color: str,
    dashed: bool = False,
    width: float = 1.0,
) -> None:
    pdf.setStrokeColor(HexColor(color))
    pdf.setLineWidth(width)
    pdf.setDash(3, 2) if dashed else pdf.setDash()
    path = pdf.beginPath()
    for index, (x, y) in enumerate(points):
        if index == 0:
            path.moveTo(x, y)
        else:
            path.lineTo(x, y)
    pdf.drawPath(path, stroke=1, fill=0)
    pdf.setDash()


def plot_long_horizon(long_horizon: dict[str, Any]) -> None:
    pdf, page_width, page_height = new_canvas("long_horizon.pdf", 7.16, 2.35)
    left = 38.0
    bottom = 31.0
    gap = 36.0
    panel_width = (page_width - left - 16.0 - gap) / 2
    panel_height = page_height - bottom - 24.0
    prepared: dict[str, dict[str, list[float]]] = {}
    for dataset in ("dyn_pubmed", "arxivmath"):
        series = long_horizon[dataset]["leidenalg"]["series"]
        gaps = [local - base for local, base in zip(series["local_q"], series["base_q"])]
        cumulative_full: list[float] = []
        cumulative_local: list[float] = []
        full_sum = 0.0
        local_sum = 0.0
        for full_time, local_time in zip(series["base_time"], series["local_time"]):
            full_sum += full_time
            local_sum += local_time
            cumulative_full.append(full_sum)
            cumulative_local.append(local_sum)
        speed = [full / local for full, local in zip(cumulative_full, cumulative_local)]
        prepared[dataset] = {"gap": gaps, "speed": speed}

    max_updates = max(len(row["gap"]) for row in prepared.values())
    tick_step = 100 if max_updates >= 500 else 20
    update_ticks = [1] + list(range(tick_step, max_updates + 1, tick_step))
    gap_min = min(min(row["gap"]) for row in prepared.values())
    gap_max = max(max(row["gap"]) for row in prepared.values())
    gap_pad = max((gap_max - gap_min) * 0.08, 0.002)
    gap_ymin = gap_min - gap_pad
    gap_ymax = max(0.0, gap_max) + gap_pad
    gap_ticks = [gap_ymin + i * (gap_ymax - gap_ymin) / 4 for i in range(5)]
    x0 = left
    draw_text(pdf, x0 + panel_width / 2, page_height - 12, "Per-update modularity deviation", 7.5, FIGURE_FONT_BOLD, "center")
    tx_gap, ty_gap = draw_panel_axes(
        pdf,
        x0,
        bottom,
        panel_width,
        panel_height,
        1,
        max_updates,
        gap_ymin,
        gap_ymax,
        update_ticks,
        gap_ticks,
        yformat="{:.3f}",
    )
    if gap_ymin <= 0 <= gap_ymax:
        pdf.setStrokeColor(HexColor(INK))
        pdf.setLineWidth(0.55)
        pdf.line(x0, ty_gap(0), x0 + panel_width, ty_gap(0))
    draw_text(pdf, x0 + panel_width / 2, 8, "Processed update batch", 6.3, align="center")
    draw_vertical_text(pdf, 7, bottom + panel_height / 2, "Local minus full modularity")

    speed_min = min(min(row["speed"]) for row in prepared.values())
    speed_max = max(max(row["speed"]) for row in prepared.values())
    speed_ymin = min(1.0, speed_min) * 0.95
    speed_ymax = speed_max * 1.06
    speed_ticks = [speed_ymin + i * (speed_ymax - speed_ymin) / 4 for i in range(5)]
    x1 = left + panel_width + gap
    draw_text(pdf, x1 + panel_width / 2, page_height - 12, "Cumulative processing-time ratio", 7.5, FIGURE_FONT_BOLD, "center")
    tx_speed, ty_speed = draw_panel_axes(
        pdf,
        x1,
        bottom,
        panel_width,
        panel_height,
        1,
        max_updates,
        speed_ymin,
        speed_ymax,
        update_ticks,
        speed_ticks,
        yformat="{:.1f}",
    )
    if speed_ymin <= 1 <= speed_ymax:
        pdf.setStrokeColor(HexColor(INK))
        pdf.setLineWidth(0.55)
        pdf.setDash(2, 2)
        pdf.line(x1, ty_speed(1), x1 + panel_width, ty_speed(1))
        pdf.setDash()
    draw_text(pdf, x1 + panel_width / 2, 8, "Processed update batch", 6.3, align="center")
    draw_vertical_text(pdf, x1 - 25, bottom + panel_height / 2, "Full/local time")

    styles = {
        "dyn_pubmed": (BLUE, False, DISPLAY["dyn_pubmed"]),
        "arxivmath": (ORANGE, True, DISPLAY["arxivmath"]),
    }
    for dataset, (color, dashed, label) in styles.items():
        polyline(
            pdf,
            [(tx_gap(index), ty_gap(value)) for index, value in enumerate(prepared[dataset]["gap"], 1)],
            color,
            dashed,
        )
        polyline(
            pdf,
            [(tx_speed(index), ty_speed(value)) for index, value in enumerate(prepared[dataset]["speed"], 1)],
            color,
            dashed,
        )
    legend_y = page_height - 23
    legend_x = x1 + panel_width - 105
    for offset, dataset in enumerate(("dyn_pubmed", "arxivmath")):
        color, dashed, label = styles[dataset]
        y = legend_y - offset * 10
        polyline(pdf, [(legend_x, y), (legend_x + 15, y)], color, dashed, 1.0)
        draw_text(pdf, legend_x + 19, y - 2.2, label, 6.0)
    pdf.showPage()
    pdf.save()

def plot_dsbm(dsbm: dict[str, Any]) -> None:
    pdf, page_width, page_height = new_canvas("dsbm_speedup.pdf", 3.5, 2.65)
    categories = [
        (rate, regime)
        for rate in ("0.01", "0.05")
        for regime in ("random", "hubs", "community")
    ]
    left = 91.0
    right = 23.0
    bottom = 26.0
    top = 19.0
    plot_width = page_width - left - right
    plot_height = page_height - bottom - top
    xmin, xmax = 0.7, 4.65

    def tx(value: float) -> float:
        return left + (value - xmin) / (xmax - xmin) * plot_width

    pdf.setStrokeColor(HexColor(INK))
    pdf.setLineWidth(0.6)
    pdf.line(left, bottom, left + plot_width, bottom)
    for tick in (1, 2, 3, 4):
        x = tx(tick)
        pdf.setStrokeColor(HexColor(LIGHT))
        pdf.setLineWidth(0.45)
        pdf.line(x, bottom, x, bottom + plot_height)
        draw_text(pdf, x, bottom - 10, str(tick), 5.8, align="center")
    break_even = tx(1.0)
    pdf.setStrokeColor(HexColor(INK))
    pdf.setLineWidth(0.7)
    pdf.setDash(2, 2)
    pdf.line(break_even, bottom, break_even, bottom + plot_height)
    pdf.setDash()
    draw_text(pdf, break_even + 3, bottom + plot_height - 7, "break-even", 5.7)

    step = plot_height / 6
    regime_names = {
        "random": "random",
        "hubs": "hub-centered",
        "community": "community-internal",
    }
    for index, (rate, regime) in enumerate(categories):
        y = bottom + plot_height - step * (index + 0.5)
        row = dsbm[rate][regime]
        color = BLUE if rate == "0.01" else ORANGE
        shape = "circle" if rate == "0.01" else "square"
        label = f"{row['changed_edges_per_update']}  {regime_names[regime]}"
        draw_text(pdf, left - 5, y - 2.2, label, 6.0, align="right")
        pdf.setStrokeColor(HexColor(color))
        pdf.setLineWidth(1.2)
        pdf.line(tx(row["speedup_min"]), y, tx(row["speedup_max"]), y)
        draw_marker(
            pdf,
            tx(row["speedup_mean"]),
            y,
            shape,
            3.0,
            color,
            color if rate == "0.01" else None,
        )
        draw_text(pdf, tx(row["speedup_max"]) + 4, y - 2.2, f"{row['speedup_mean']:.2f}x", 5.8)
    draw_text(pdf, left + plot_width / 2, 7, "Full/Local cumulative processing time", 6.3, align="center")
    pdf.showPage()
    pdf.save()


def plot_topology(topology: dict[str, Any]) -> None:
    """Plot the measured radius/depth surface and its Pareto frontier."""
    pdf, page_width, page_height = new_canvas("topology_ablation.pdf", 7.16, 2.62)
    datasets = ("dyn_cora", "dyn_pubmed", "arxivmath")
    radius_style = {
        0: ("circle", "#1F77B4"),
        1: ("square", "#D95F02"),
        2: ("triangle", "#2CA02C"),
    }
    x_axes = {
        "dyn_cora": (0.0, 26.0, [1, 5, 10, 15, 20, 25], False),
        "dyn_pubmed": (0.85, 220.0, [1, 10, 100], True),
        "arxivmath": (0.85, 900.0, [1, 10, 100], True),
    }
    # Preserve numbered markers; offset only labels that meet under the new data.
    badge_offsets = {
        "dyn_cora": {(0, 3): (0.0, -10.0), (1, 3): (0.0, 6.0),
                     (2, 2): (6.0, -6.0), (1, 4): (0.0, 0.0)},
        "dyn_pubmed": {(2, 1): (0.0, -10.0), (2, 3): (10.0, -8.0),
                       (2, 4): (-10.0, 6.0)},
        "arxivmath": {(2, 2): (-4.0, 10.0), (2, 3): (10.0, 0.0),
                      (2, 1): (-7.0, -4.0), (2, 4): (10.0, -16.0),
                      (1, 2): (0.0, 16.0), (1, 1): (12.0, -10.0),
                      (1, 4): (-10.0, -10.0), (0, 1): (4.0, -5.0),
                      (0, 2): (0.0, 8.0), (0, 3): (-7.0, -5.0),
                      (0, 4): (0.0, 0.0)},
    }

    def pareto_front(data: dict[str, Any]) -> list[tuple[float, float]]:
        candidates = [(1.0, float(data["full"]["q"]))]
        candidates.extend(
            (float(point["speedup"]), float(point["q"]))
            for point in data["points"]
        )
        front = []
        for speedup, quality in candidates:
            dominated = any(
                other_speedup >= speedup
                and other_quality >= quality
                and (other_speedup > speedup or other_quality > quality)
                for other_speedup, other_quality in candidates
            )
            if not dominated:
                front.append((speedup, quality))
        return sorted(front)

    left = 36.0
    right = 8.0
    gap = 30.0
    bottom = 36.0
    top = 27.0
    panel_width = (page_width - left - right - 2 * gap) / 3
    panel_height = page_height - bottom - top

    for panel, dataset in enumerate(datasets):
        data = topology[dataset]
        x0 = left + panel * (panel_width + gap)
        all_q = [data["full"]["q"]] + [point["q"] for point in data["points"]]
        qmin, qmax = min(all_q), max(all_q)
        qpad = max((qmax - qmin) * 0.11, 0.0007)
        ymin, ymax = qmin - qpad, qmax + qpad
        xmin, xmax, xticks, xlog = x_axes[dataset]
        yticks = [ymin + index * (ymax - ymin) / 4 for index in range(5)]
        tx, ty = draw_panel_axes(
            pdf,
            x0,
            bottom,
            panel_width,
            panel_height,
            xmin,
            xmax,
            ymin,
            ymax,
            xticks,
            yticks,
            xlog=xlog,
            xformat="{:.0f}x",
            yformat="{:.3f}",
            tick_size=6.3,
        )
        draw_text(
            pdf,
            x0 + panel_width / 2,
            page_height - 9.0,
            DISPLAY[dataset],
            8.0,
            FIGURE_FONT_BOLD,
            "center",
        )

        frontier = pareto_front(data)
        polyline(
            pdf,
            [(tx(speedup), ty(quality)) for speedup, quality in frontier],
            INK,
            width=1.0,
        )

        full_x = tx(1.0)
        full_y = ty(data["full"]["q"])
        draw_marker(pdf, full_x, full_y, "star", 5.2, "#FFFFFF", INK)

        badges: list[tuple[float, float, str, str, float, str]] = []
        for point in data["points"]:
            shape, color = radius_style[point["radius"]]
            is_default = point["level"] == 3 and point["radius"] == 1
            px = tx(point["speedup"])
            py = ty(point["q"])
            dx, dy = badge_offsets[dataset].get(
                (int(point["radius"]), int(point["level"])),
                (0.0, 0.0),
            )
            bx, by = px + dx, py + dy
            if dx or dy:
                pdf.setStrokeColor(HexColor(color))
                pdf.setLineWidth(0.55)
                pdf.line(px, py, bx, by)
                draw_marker(pdf, px, py, "circle", 1.25, "#FFFFFF", color)
            radius = 5.4 if is_default else 5.5 if shape == "triangle" else 4.8
            badges.append((bx, by, shape, color, radius, str(point["level"])))

        # Draw all badges after anchors and leaders so no line can erase a digit.
        for bx, by, shape, color, radius, _ in badges:
            draw_marker(
                pdf,
                bx,
                by,
                shape,
                radius,
                INK if shape == "square" and radius > 5.0 else "#FFFFFF",
                color,
            )
        for bx, by, _, _, _, label in badges:
            draw_text(
                pdf,
                bx,
                by - 2.8,
                label,
                7.6,
                FIGURE_FONT_BOLD,
                "center",
                "#FFFFFF",
            )
        draw_backed_text(
            pdf,
            full_x + 7.0,
            full_y + 3.5,
            "Full",
            6.4,
            color=INK,
        )
        draw_text(pdf, x0 + panel_width / 2, 10, "Full/ComNetX time", 6.8, align="center")

        if dataset == "arxivmath":
            legend_w = 40.0
            legend_h = 47.0
            legend_x = x0 + panel_width - legend_w - 2.0
            legend_y = bottom + panel_height - legend_h - 2.0
            pdf.setFillColor(HexColor("#FFFFFF"))
            pdf.setStrokeColor(HexColor("#C7CDD2"))
            pdf.setLineWidth(0.55)
            pdf.roundRect(legend_x, legend_y, legend_w, legend_h, 2.5, stroke=1, fill=1)
            legend_entries = [
                ("circle", "#1F77B4", "r=0"),
                ("square", "#D95F02", "r=1"),
                ("triangle", "#2CA02C", "r=2"),
            ]
            for index, (shape, color, label) in enumerate(legend_entries):
                row_y = legend_y + legend_h - 10.0 - index * 10.0
                draw_marker(pdf, legend_x + 8.0, row_y + 1.0, shape, 2.8, "#FFFFFF", color)
                draw_text(pdf, legend_x + 15.0, row_y - 1.2, label, 6.2)
            pareto_y = legend_y + 6.0
            pdf.setStrokeColor(HexColor(INK))
            pdf.setLineWidth(1.0)
            pdf.line(legend_x + 4.5, pareto_y + 1.5, legend_x + 11.5, pareto_y + 1.5)
            draw_text(pdf, legend_x + 15.0, pareto_y - 0.8, "Pareto", 6.2)

    draw_vertical_text(pdf, 7, bottom + panel_height / 2, "Final modularity", 6.8)
    pdf.showPage()
    pdf.save()


def plot_method_pipeline() -> None:
    """Draw a readable example whose first-pass atoms obey Eq. (base_atoms).

    The example has S={1,2,6}, B={1,2,3,4,6,7,9}, and U is V minus {5}.
    The two selected fine communities share a coarsest parent, so only
    residual vertices 8 and 10 are contracted. Every vertex of B stays
    separate. This is an illustration, not an additional experiment.
    """
    temporary = tempfile.TemporaryDirectory(prefix="comnetx-method-pipeline-")
    temporary_path = Path(temporary.name)
    base_path = temporary_path / "method_pipeline_base.pdf"
    pdf, page_width, page_height = new_canvas(
        "method_pipeline_base.pdf", 7.16, 5.15, output_path=base_path,
    )
    ink, muted = "#263341", "#536373"
    blue, light_blue = "#30648F", "#EAF2F8"
    coral, light_coral = "#C64D3C", "#FFE5DD"
    purple, light_purple = "#7959A3", "#F0EAF7"
    green, light_green = "#297F72", "#E2F3EE"
    gray, light_gray = "#89959F", "#F0F2F4"
    formula_nodes: list[dict[str, Any]] = []
    pdf.setLineCap(1)
    pdf.setLineJoin(1)

    def text(x: float, y: float, value: str, size: float = 8.3,
             *, bold: bool = False, align: str = "left", color: str = ink) -> None:
        draw_text(pdf, x, y, value, size,
                  FIGURE_FONT_BOLD if bold else FIGURE_FONT, align, color)

    def formula(x: float, y: float, value: str, *, size: float = 9.0,
                align: str = "left", color: str = ink) -> None:
        formula_nodes.append(dict(x=x, y=y, tex=value, scale=size / 10.0,
                                  align=align, color=color))

    def line(x1: float, y1: float, x2: float, y2: float,
             *, color: str = gray, width: float = 0.8,
             dash: tuple[float, float] | None = None) -> None:
        pdf.setStrokeColor(HexColor(color))
        pdf.setLineWidth(width)
        pdf.setDash(list(dash) if dash else [])
        pdf.line(x1, y1, x2, y2)
        pdf.setDash()

    def box(x: float, y: float, w: float, h: float, *, fill: str = "#FFFFFF",
            stroke: str = gray, dash: bool = False) -> None:
        pdf.setFillColor(HexColor(fill))
        pdf.setStrokeColor(HexColor(stroke))
        pdf.setLineWidth(0.7)
        pdf.setDash([3, 2] if dash else [])
        pdf.roundRect(x, y, w, h, 5, stroke=1, fill=1)
        pdf.setDash()

    def arrow(x1: float, y: float, x2: float) -> None:
        line(x1, y, x2, y, color=blue, width=1.1)
        line(x2 - 4, y + 2.5, x2, y, color=blue, width=1.1)
        line(x2 - 4, y - 2.5, x2, y, color=blue, width=1.1)

    def vertex(x: float, y: float, label: str, *, fill: str = "#FFFFFF",
               stroke: str = ink, radius: float = 8.0, bold: bool = False) -> None:
        pdf.setFillColor(HexColor(fill))
        pdf.setStrokeColor(HexColor(stroke))
        pdf.setLineWidth(1.5 if bold else 0.8)
        pdf.circle(x, y, radius, stroke=1, fill=1)
        text(x, y - 3.0, label, 8.2, bold=bold, align="center", color=stroke)

    # All edges have unit weight; their symmetric adjacency is the working
    # convention. New edges (1,2) and (2,6) give exactly the endpoints below.
    positions = {
        1: (24, 81), 3: (9, 52), 4: (43, 52), 8: (25, 20),
        2: (78, 81), 6: (125, 81), 7: (78, 47), 9: (125, 47),
        10: (103, 15), 5: (140, -7),
    }
    edges = [(1, 2), (2, 6), (1, 3), (1, 4), (2, 7), (6, 9),
             (3, 4), (3, 8), (4, 8), (7, 9), (7, 10), (9, 10),
             (8, 10), (10, 5)]
    new_edges = {(1, 2), (2, 6)}
    endpoints = {1, 2, 6}
    neighborhood = endpoints | {3, 4, 7, 9}
    old_fine = ({1, 3, 4, 8}, {2, 6, 7, 9, 10}, {5})
    old_coarse = (set(range(1, 11)) - {5}, {5})
    region = set().union(*(h for h in old_fine if h & neighborhood))
    atoms = [{v} for v in sorted(neighborhood)] + [
        (h & region) - neighborhood for h in old_coarse
        if (h & region) - neighborhood
    ]
    reached = endpoints | {v for u, v in edges if u in endpoints} | {
        u for u, v in edges if v in endpoints
    }
    assert reached == neighborhood
    assert region == set(range(1, 11)) - {5}
    assert atoms == [{1}, {2}, {3}, {4}, {6}, {7}, {9}, {8, 10}]

    text(8, 355, "Select update regions, then process the hierarchy from fine to coarse", 9.3, bold=True)
    formula(8, 337, r"S_t=\{1,2,6\},\qquad B_t=N_1(S_t)=\{1,2,3,4,6,7,9\}.", size=9.6)
    formula(8, 321, r"U_t^0=\{1,2,3,4,6,7,8,9,10\},\qquad B_t\subseteq U_t^0\subseteq\cdots\subseteq U_t^{L-1}.", size=9.6)
    text(8, 304, "All update regions use the pre-update partitions and remain fixed during this batch.", 8.3)
    line(8, 294, page_width - 8, 294, color="#B6C2CD", width=0.7)

    origins = (15.0, 187.0, 359.0)
    titles = ("(a) Updated graph", "(b) First-pass quotient", "(c) Lifted partition")
    for x, title in zip(origins, titles):
        text(x + 65, 278, title, 9.0, bold=True, align="center", color=blue)

    # Panel (a): selected pre-update communities; all B vertices are individual.
    x, y = origins[0], 178.0
    box(x - 3, y + 6, 58, 89, fill=light_purple, stroke=purple)
    box(x + 66, y + 1, 73, 94, fill=light_blue, stroke=blue)
    for u, v in edges:
        ux, uy = positions[u]; vx, vy = positions[v]
        line(x + ux, y + uy, x + vx, y + vy,
             color=coral if (u, v) in new_edges else gray,
             width=1.6 if (u, v) in new_edges else 0.75,
             dash=(3, 2) if (u, v) in new_edges else None)
    for v, (vx, vy) in positions.items():
        vertex(x + vx, y + vy, str(v),
               fill=light_coral if v in neighborhood else (light_gray if v == 5 else "#FFFFFF"),
               stroke=coral if v in neighborhood else (gray if v == 5 else ink),
               bold=v in endpoints)
    text(x + 65, 152, "Two selected fine communities", 8.0, align="center")
    text(x + 65, 139, "share one coarsest parent.", 8.0, align="center")

    # Panel (b): singleton B vertices plus the one residual atom {8,10}.
    x, y = origins[1], 178.0
    qpos = {1: (16, 81), 2: (67, 81), 3: (0, 47), 4: (33, 47),
            6: (120, 81), 7: (79, 47), 9: (128, 47), "R": (65, 12)}
    atom_of = {v: ("R" if v in {8, 10} else v) for v in region}
    quotient_edges: dict[tuple[Any, Any], int] = {}
    for u, v in edges:
        if u not in region or v not in region:
            continue
        a, b = atom_of[u], atom_of[v]
        if a == b:
            # One undirected internal edge yields two diagonal adjacency units.
            key = (a, a)
            quotient_edges[key] = quotient_edges.get(key, 0) + 2
        else:
            key = tuple(sorted((a, b), key=str))
            quotient_edges[key] = quotient_edges.get(key, 0) + 1
    assert quotient_edges[("R", "R")] == 2
    assert sum(w if a == b else 2 * w for (a, b), w in quotient_edges.items()) == 26
    for (a, b), weight in quotient_edges.items():
        if a == b:
            continue
        ax, ay = qpos[a]; bx, by = qpos[b]
        line(x + ax, y + ay, x + bx, y + by, width=0.8)
        assert weight == 1
    pdf.setStrokeColor(HexColor(purple))
    pdf.setLineWidth(0.8)
    pdf.ellipse(x + 40, y - 1, x + 62, y + 17, stroke=1, fill=0)
    text(x + 39, y - 4, "2", 8.0, color=purple)
    for a, (ax, ay) in qpos.items():
        vertex(x + ax, y + ay, str(a), fill=light_purple if a == "R" else light_coral,
               stroke=purple if a == "R" else coral, radius=10 if a == "R" else 8)
    formula(x + 65, 152, r"R=\{8,10\};\quad |\mathcal G_t^0|=8", size=9.4, align="center")
    formula(x + 65, 139, r"\text{Every vertex in }B_t\text{ remains separate.}", size=9.0, align="center")

    # Panel (c): an illustrative atom-constant backend result lifted to U.
    x, y = origins[2], 178.0
    output_groups = ({1, 2, 3, 4, 8, 10}, {6, 7, 9}, {5})
    for atom in atoms:
        assert any(atom <= group for group in output_groups)
    for u, v in edges:
        ux, uy = positions[u]; vx, vy = positions[v]
        line(x + ux, y + uy, x + vx, y + vy, width=0.75,
             color=gray if v != 5 else "#B7BEC4")
    for v, (vx, vy) in positions.items():
        group = next(i for i, h in enumerate(output_groups) if v in h)
        vertex(x + vx, y + vy, str(v),
               fill=(light_purple, light_green, light_gray)[group],
               stroke=(purple, green, gray)[group])
    formula(x + 65, 152, r"C_t^0\quad\text{(reported partition)}", size=9.2, align="center")
    text(x + 65, 139, "Vertex 5 remains unchanged.", 8.0, align="center")
    arrow(165, 222, 178)
    arrow(337, 222, 350)

    # A short explicit legend replaces tiny explanatory labels in the old chart.
    line(8, 128, page_width - 8, 128, color="#B6C2CD", width=0.7)
    line(12, 116, 29, 116, color=coral, width=1.5, dash=(3, 2))
    text(35, 113, "new edge", 8.0)
    vertex(117, 116, "", fill=light_coral, stroke=coral, radius=4)
    text(126, 113, "vertex in", 8.0)
    formula(167, 113, r"B_t", size=9.3)
    text(212, 113, "Other edges: weight 1; quotient loop: weight 2.", 8.0)

    box(8, 10, page_width - 16, 90, fill="#F7F9FB", stroke="#B6C2CD")
    text(18, 84, "For each coarser level", 8.7, bold=True, color=blue)
    formula(157, 84, r"\ell=1,\ldots,L-1:", size=9.4, color=blue)
    text(18, 67, "1. Reconstruct the induced subgraph on the fixed update region.", 8.3)
    text(18, 50, "2. Contract each complete block of the updated finer partition into one atom.", 8.3)
    text(18, 33, "3. Run the backend, lift its labels, and retain assignments outside the region.", 8.3)
    text(18, 17, "The resulting partitions remain nested; the partition at level 0 is the reported output.", 8.0)
    pdf.showPage()
    pdf.save()

    # Typeset mathematical labels in the same vector fonts as the manuscript.
    color_names = {color: f"FormulaColor{i}" for i, color in enumerate(
        dict.fromkeys(node["color"] for node in formula_nodes))}
    tex_lines = [
        r"\let\TeXprimitiveyear\year",
        r"\documentclass[class=ieeeaccess,crop,border=0pt]{standalone}",
        r"\let\year\TeXprimitiveyear",
        r"\ifdefined\pdfinfoomitdate\pdfinfoomitdate=1\fi",
        r"\ifdefined\pdfsuppressptexinfo\pdfsuppressptexinfo=-1\fi",
        r"\ifdefined\pdftrailerid\pdftrailerid{}\fi",
        r"\usepackage{amsmath,amssymb,amsfonts,bm,tikz,graphicx}",
    ]
    for color, name in color_names.items():
        tex_lines.append(f"\\definecolor{{{name}}}{{HTML}}{{{color.lstrip('#')}}}")
    tex_lines.extend([
        r"\begin{document}", r"\global\eoddefinedtrue",
        r"\begin{tikzpicture}[x=1bp,y=1bp]",
        f"\\path[use as bounding box] (0,0) rectangle ({page_width:.2f},{page_height:.2f});",
        r"\node[anchor=south west,inner sep=0bp,outer sep=0bp] at (0,0) {\includegraphics[width="
        + f"{page_width:.2f}bp,height={page_height:.2f}bp]{{{base_path.as_posix()}}}}};",
    ])
    anchors = {"left": "base west", "center": "base", "right": "base east"}
    for node in formula_nodes:
        tex_lines.append(
            "\\node[anchor=" + anchors[node["align"]]
            + ",inner sep=0bp,outer sep=0bp,transform shape,scale="
            + f"{node['scale']:.3f},text=" + color_names[node["color"]]
            + f"] at ({node['x']:.2f},{node['y']:.2f}) "
            + "{$" + node["tex"] + "$};"
        )
    tex_lines.extend([r"\end{tikzpicture}", r"\end{document}"])
    overlay_source = temporary_path / "method_pipeline_overlay.tex"
    write_text(overlay_source, "\n".join(tex_lines))
    compiler = shutil.which("pdflatex")
    if compiler:
        command = [compiler, "-interaction=nonstopmode", "-halt-on-error",
                   f"-output-directory={temporary_path}", str(overlay_source)]
    else:
        compiler = shutil.which("tectonic")
        if compiler is None:
            raise RuntimeError("pdflatex or tectonic is required to compose method_pipeline.pdf")
        command = [compiler, "--only-cached", "--outdir", str(temporary_path), str(overlay_source)]
    environment = os.environ.copy()
    environment.setdefault("SOURCE_DATE_EPOCH", "946684800")
    result = subprocess.run(command, cwd=JOURNAL, env=environment, check=False,
                            capture_output=True, text=True)
    if result.returncode != 0:
        diagnostic = (result.stdout + "\n" + result.stderr)[-5000:]
        raise RuntimeError(f"TeX composition of method_pipeline.pdf failed:\n{diagnostic}")
    composed_path = temporary_path / "method_pipeline_overlay.pdf"
    if not composed_path.exists():
        raise RuntimeError("TeX composition did not create method_pipeline_overlay.pdf")
    shutil.copyfile(composed_path, FIGURES / "method_pipeline.pdf")
    temporary.cleanup()


def legacy_main() -> None:
    ANALYSIS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    GENERATED.mkdir(parents=True, exist_ok=True)

    experiment_records = load_records(EXPERIMENTS)
    workload_records = load_records(WORKLOADS)
    neighborhood_records = load_records(NEIGHBORHOODS)
    cut_metric_records = load_records(CUT_METRICS)
    assert len(experiment_records) == 446
    assert len(workload_records) == 24
    assert len(neighborhood_records) == 6
    assert len(cut_metric_records) == 4

    info = data_info()
    nodes = {dataset: int(meta["n"]) for dataset, meta in info.items()}
    short = validate_short_horizon(experiment_records)
    repeatability = validate_backend_repeatability(experiment_records)
    long_horizon = validate_long_horizon(experiment_records)
    dsbm = validate_dsbm(experiment_records)
    workloads = validate_workloads(workload_records, nodes)
    neighborhoods = validate_neighborhoods(neighborhood_records)
    topology = validate_topology_ablation(experiment_records)
    directed = validate_directed_control(experiment_records)
    gamma_sweep = validate_gamma_sweep(experiment_records)
    feature_ablation = validate_feature_ablation(experiment_records)
    cut_metrics = validate_cut_metrics(cut_metric_records)

    evidence = {
        "sources": {
            "experiments": str(EXPERIMENTS.relative_to(ROOT)),
            "workloads": str(WORKLOADS.relative_to(ROOT)),
            "neighborhoods": str(NEIGHBORHOODS.relative_to(ROOT)),
            "cut_metrics": str(CUT_METRICS.relative_to(ROOT)),
        },
        "source_record_counts": {
            "experiments": len(experiment_records),
            "workloads": len(workload_records),
            "neighborhoods": len(neighborhood_records),
            "cut_metrics": len(cut_metric_records),
        },
        "short_horizon": short,
        "backend_repeatability": repeatability,
        "long_horizon": long_horizon,
        "dsbm": dsbm,
        "workloads": workloads,
        "neighborhoods": neighborhoods,
        "topology_ablation": topology,
        "directed_control": directed,
        "gamma_sweep": gamma_sweep,
        "feature_ablation": feature_ablation,
        "cut_metrics": cut_metrics,
    }
    write_text(
        ANALYSIS / "validated_results.json",
        json.dumps(evidence, indent=2, ensure_ascii=False, sort_keys=True),
    )
    emit_rows(
        info,
        short,
        repeatability,
        long_horizon,
        workloads,
        neighborhoods,
        dsbm,
        topology,
        directed,
        gamma_sweep,
        feature_ablation,
        cut_metrics,
    )

    plot_long_horizon(long_horizon)
    plot_dsbm(dsbm)
    plot_topology(topology)
    plot_method_pipeline()

    # Explicitly verify the headline values used by the manuscript macros.
    assert math.isclose(short["arxivmath"]["speedup"], 41.8805194204, rel_tol=1e-9)
    assert math.isclose(long_horizon["arxivmath"]["leidenalg"]["speedup"], 30.5365, rel_tol=1e-4)
    assert math.isclose(dsbm["0.05"]["random"]["speedup_mean"], 0.8893095922, rel_tol=1e-9)
    assert math.isclose(
        gamma_sweep["dyn_pubmed"]["2.0"]["delta_q"],
        -0.0529655814,
        rel_tol=1e-8,
    )
    assert directed["dyn_pubmed"]["updates"] == 10
    assert feature_ablation["dyn_pubmed"]["onehot"]["naive"]["updates"] == 44
    assert cut_metrics["datasets"]["arxivmath"]["smart"]["clusters"] == 8094
    print("Validated evidence and regenerated IEEE Access figures/tables.")


if __name__ == "__main__":
    from current_results import main
    import sys
    main(sys.modules[__name__])
