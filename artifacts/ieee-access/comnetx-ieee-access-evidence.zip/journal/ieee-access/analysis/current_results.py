"""Reproducible selection and rendering of ieee-access-2026-2 measurements.

No historical smart-mode measurements enter this evidence set. Source identities
include the file and all four JSON keys; duplicate executions remain separate.
"""
from pathlib import Path
import hashlib
import json
import math
from statistics import mean, stdev

ROOT = Path(__file__).resolve().parents[3]
BUNDLE = ROOT / 'results/ieee-access-2026-2'
JOURNAL = ROOT / 'journal/ieee-access'
DATASETS = ('dyn_cora', 'dyn_acm', 'dyn_citeseer', 'patent', 'dyn_pubmed', 'arxivmath')
# Display names are shared by tables, summaries and figures. Archive keys stay
# unchanged in selectors, source identities and the machine-readable ledger.
DISPLAY = {
    'dyn_cora': 'Cora', 'dyn_acm': 'ACM', 'dyn_citeseer': 'CiteSeer',
    'patent': 'Patent', 'dyn_pubmed': 'PubMed', 'arxivmath': 'ArxivMath',
}
MAIN = 'main_topology_20261001_1227.json'
GRID = 'ablation_topology_radius_depth_20260930_1707.json'
LONG = 'long_horizon_topology_20261001_1144.json'
LONG_LEIDEN = 'leidenalg_20261002_2221.json'
LONG_DF = 'dfleiden_20261002_2213.json'
FEATURE = 'main_gnn_feature_20261001_1236.json'
FEATURE_ADD = 'main_gnn_feature_add_20261002_2156.json'
SEED_SELECTION = ('For each seed 1–5 use the October 1 file with five completed graphs '
                  'and the October 2 CiteSeer supplement. Report the separate six-graph '
                  'seed-1 run at 21:40 as a sensitivity analysis.')


def tex(value):
    return DISPLAY.get(value, value).replace('_', r'\_')


def number(value):
    return f'{value:.3f}' if value < 100 else f'{value:.1f}'


def feature_seed_study(records, used, table):
    """Select the five prescribed seeds by file coverage before reading their scores."""
    method = 's2cag-i:10-L:3-r:1-agg:norm-gpu-feat:random'
    prefix = 'stability_gnn_seed_'
    files_by_seed = {seed: {} for seed in range(1, 6)}
    for record in records:
        if record['file'].startswith(prefix):
            seed = int(record['file'].removeprefix(prefix).split('_', 1)[0])
            assert record['method'] == method and record['protocol'] == '999:10'
            by_dataset = files_by_seed[seed].setdefault(record['file'], {})
            assert record['dataset'] not in by_dataset
            by_dataset[record['dataset']] = record
            used.add(record['id'])

    sweep = {}
    citeseer = 'dyn_citeseer'
    other_graphs = set(DATASETS) - {citeseer}
    rerun = 'stability_gnn_seed_1_20261001_2140.json'
    for seed, files in files_by_seed.items():
        initial, = [name for name, rows in files.items()
                    if name.startswith(f'{prefix}{seed}_20261001_') and set(rows) == other_graphs]
        supplement, = [name for name, rows in files.items()
                       if name.startswith(f'{prefix}{seed}_add_20261002_') and set(rows) == {citeseer}]
        assert set(files) == {initial, supplement} | ({rerun} if seed == 1 else set())
        sweep[seed] = {**files[initial], **files[supplement]}
    extra = files_by_seed[1][rerun]
    assert set(extra) == set(DATASETS)

    stability, main_rows, sensitivity_rows = {}, [], []
    for dataset in DATASETS:
        primary = [sweep[seed][dataset] for seed in range(1, 6)]
        identifiers = {(r['stored_dataset'], r['updates']) for r in [*primary, extra[dataset]]}
        assert len(identifiers) == 1, (dataset, identifiers)
        alternatives = {}
        for key, candidate in [('complete_2140', extra[dataset]), ('initial_series', primary[0])]:
            five = [candidate, *primary[1:]]
            alternatives[key] = {
                'seed_1_record': candidate,
                'five_seed_mean': {k: mean(r[k] for r in five) for k in ('q', 'nmi', 'time')},
                'five_seed_sample_sd': {k: stdev(r[k] for r in five) for k in ('q', 'nmi', 'time')},
            }
        stability[dataset] = {'selected_seeds': [1, 2, 3, 4, 5], 'selected': primary,
                              'seed_1_sensitivity': alternatives}
        row = [tex(dataset)]
        for key, decimals in [('q', 4), ('nmi', 4), ('time', 3)]:
            values = [r[key] for r in primary]
            row.append(f'{mean(values):.{decimals}f}$\\pm${stdev(values):.{decimals}f}')
        main_rows.append(row)
        # Preserve the supplemental comparison of five-seed means in its original order.
        sensitivity_rows.append([tex(dataset), *(f"{case['five_seed_mean'][k]:.4f}"
                                for k in ('q', 'nmi') for case in alternatives.values())])
    table('stability_rows.tex', main_rows)
    table('seed_sensitivity_rows.tex', sensitivity_rows)
    return stability


def main(v):
    records = []
    files = {}
    for path in sorted(BUNDLE.glob('*.json')):
        files[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        payload = json.loads(path.read_text())
        for method, datasets in payload.items():
            for dataset, resolutions in datasets.items():
                for resolution, protocols in resolutions.items():
                    assert resolution == 'null', (path, resolution)
                    for protocol, series in protocols.items():
                        assert series and all(isinstance(row, dict) for row in series)
                        for row in series:
                            assert all(math.isfinite(float(row[k])) for k in ('time', 'modularity'))
                            assert row['time'] >= 0
                        final = series[-1]
                        assert all(k in final for k in ('Final modularity', 'NMI'))
                        assert all(math.isfinite(float(final[k])) for k in ('Final modularity', 'NMI'))
                        assert 0 <= final['NMI'] <= 1
                        base = dataset.removesuffix('-sym')
                        if protocol.startswith('999:'):
                            tail = {'dyn_cora': 10, 'dyn_acm': 26,
                                    'dyn_citeseer': 8, 'patent': 41,
                                    'dyn_pubmed': 44, 'arxivmath': 799}[base]
                            expected = min(int(protocol.split(':')[1]), tail)
                        else:
                            expected = {'10': 10, '99:50': 50, '9:500': 500}[protocol]
                        assert len(series) == expected, (path.name, method, dataset, protocol)
                        records.append(dict(id=f'{path.name}::{method}/{dataset}/{resolution}/{protocol}',
                            file=path.name, method=method, dataset=base, stored_dataset=dataset,
                            protocol=protocol, updates=len(series), q=final['Final modularity'],
                            nmi=final['NMI'], time=sum(row['time'] for row in series), series=series))
    assert len(files) == 26 and len(records) == 305, 'Review selection policy when the bundle changes'
    by_id = {r['id']: r for r in records}
    assert len(by_id) == len(records)
    excluded = {
        r['id']: 'Native graph-growth initialization delivered the first bin '
                 'to both the constructor and update; requires a corrected rerun.'
        for r in records
        if r['method'] == 'dfleiden-dynamic' and r['protocol'] == '10'
    }
    assert len(excluded) == 6
    for r in records:
        r['terminal_modularity_difference'] = abs(r['series'][-1]['modularity'] - r['q'])
        if r['id'] not in excluded:
            assert r['terminal_modularity_difference'] < 1e-6, r['id']
    used = set()

    def get(files, method, dataset, protocol='999:10', optional=False):
        if isinstance(files, str): files = [files]
        rows = [r for r in records if r['file'] in files and r['method'] == method
                and r['dataset'] == dataset and r['protocol'] == protocol]
        if optional and not rows: return None
        assert len(rows) == 1, (files, method, dataset, protocol, len(rows))
        assert rows[0]['id'] not in excluded, rows[0]['id']
        used.add(rows[0]['id'])
        return rows[0]

    def pair(a, b):
        assert (a['stored_dataset'], a['protocol'], a['updates']) == (b['stored_dataset'], b['protocol'], b['updates'])
        assert b['time'] > 0
        return dict(base=a, local=b, speedup=a['time']/b['time'], dq=b['q']-a['q'], dnmi=b['nmi']-a['nmi'])

    def write(name, rows):
        v.write_text(JOURNAL/'generated'/name, '\n'.join(rows))

    def table(name, rows):
        write(name, [r' & '.join(row) + r' \\' for row in rows] + [r'\bottomrule'])

    def paired_row(dataset, p, prefix=()):
        a,b=p['base'],p['local']
        return [tex(dataset), *prefix, f"{a['q']:.4f}", f"{b['q']:.4f}",
                f"{a['nmi']:.4f}", f"{b['nmi']:.4f}", number(a['time']), number(b['time']), f"{p['speedup']:.2f}"]

    info = v.data_info()
    table('dataset_rows.tex', [[tex(d), f"{int(info[d]['n']):,}", f"{int(info[d]['m']):,}",
          'timestamp' if d in ('patent','arxivmath') else 'artificial', '8' if d=='dyn_citeseer' else '10'] for d in DATASETS])

    short = {}
    for d in DATASETS:
        if d == 'patent': continue
        source = MAIN if d in DATASETS[:3] else GRID
        short[d] = pair(get(source,'leidenalg-naive',d),get(source,'leidenalg-L:3-r:1-gpu',d))
    assert all(p['speedup'] > 1 and p['dq'] < 0 and p['dnmi'] < 0 for p in short.values())
    table('short_results_rows.tex',[paired_row(d,p) for d,p in short.items()])
    a=short['arxivmath']
    write('metrics_macros.tex',[
        rf"\newcommand{{\ArxivShortSpeedup}}{{{a['speedup']:.2f}}}",
        rf"\newcommand{{\ArxivShortFullQ}}{{{a['base']['q']:.4f}}}",
        rf"\newcommand{{\ArxivShortLocalQ}}{{{a['local']['q']:.4f}}}",
        rf"\newcommand{{\ArxivShortQGap}}{{{abs(a['dq']):.4f}}}",
        rf"\newcommand{{\ShortMinSpeedup}}{{{min(p['speedup'] for p in short.values()):.2f}}}"])
    write('short_summary.tex',[
        rf"Across the five available Leiden pairs, cumulative measured time ratios range from {min(p['speedup'] for p in short.values()):.2f}$\times$ to {max(p['speedup'] for p in short.values()):.2f}$\times$.",
        rf"All five final modularity differences are negative, ranging from {min(p['dq'] for p in short.values()):.4f} to {max(p['dq'] for p in short.values()):.4f}; NMI also decreases in every pair.",
        rf"On ArxivMath, time changes from {number(a['base']['time'])} s to {number(a['local']['time'])} s, while modularity changes from {a['base']['q']:.4f} to {a['local']['q']:.4f}."])

    dfshort=[]
    for d in DATASETS[:3]:
        for method, label in [('dfleiden-naive','Full'),('dfleiden-dynamic','Native dynamic'),('dfleiden-L:3-r:1-gpu','ComNetX')]:
            r=get(MAIN,method,d,optional=True)
            dfshort.append([tex(d),label, f"{r['q']:.4f}" if r else '--', f"{r['nmi']:.4f}" if r else '--',
                            ('0 (recorded)' if r['time']==0 else number(r['time'])) if r else '--'])
    table('df_short_rows.tex',dfshort)

    long={}
    for d in ('dyn_pubmed','arxivmath'):
        for protocol in ('99:50','9:500'):
            for method, mode in [('leidenalg','naive'),('dfleiden','dynamic')]:
                source = LONG_LEIDEN if method == 'leidenalg' else LONG_DF
                long[d,protocol,method]=pair(get(source,f'{method}-{mode}',d,protocol),get(source,f'{method}-L:3-r:1-gpu',d,protocol))
    table('long_horizon_rows.tex',[paired_row(d,p,('Leiden' if m=='leidenalg' else 'DF-Leiden',str(p['base']['updates']), proto.replace(':',r'{:}')))
            for (d,proto,m),p in long.items()])
    table('df_full_long_rows.tex',[[tex(d),proto.replace(':',r'{:}'),f"{r['q']:.4f}",f"{r['nmi']:.4f}",number(r['time'])]
         for d in ('dyn_pubmed','arxivmath') for proto in ('999:50','999:100')
         for r in [get(LONG,'dfleiden-naive',d,proto)]])
    p=long['arxivmath','9:500','leidenalg']
    with (JOURNAL/'generated/metrics_macros.tex').open('a') as macro_file:
        macro_file.write(rf"\newcommand{{\ArxivLongSpeedup}}{{{p['speedup']:.2f}}}"+'\n')
        macro_file.write(rf"\newcommand{{\ArxivLongQGap}}{{{abs(p['dq']):.4f}}}"+'\n')
        macro_file.write(rf"\newcommand{{\ArxivLongLocalQ}}{{{p['local']['q']:.4f}}}"+'\n')
        macro_file.write(rf"\newcommand{{\ArxivLongFullQ}}{{{p['base']['q']:.4f}}}"+'\n')
    write('long_summary.tex',[
        rf"For ArxivMath at 500 updates, the Leiden time ratio is {p['speedup']:.2f}$\times$: {number(p['base']['time'])} s versus {number(p['local']['time'])} s. Final modularity is {p['base']['q']:.4f} versus {p['local']['q']:.4f}, and NMI is {p['base']['nmi']:.4f} versus {p['local']['nmi']:.4f}."])

    features={}
    for mode in ('dataset','random'):
        for d in DATASETS:
            features[d,mode]=pair(get(FEATURE,f's2cag-i:10-naive-feat:{mode}',d),
                get([FEATURE,FEATURE_ADD],f's2cag-i:10-L:3-r:1-agg:norm-gpu-feat:{mode}',d))
    table('backend_rows.tex',[paired_row(d,p,(mode,)) for (d,mode),p in features.items()])
    feature_modes={}
    for d in ('dyn_cora','dyn_pubmed'):
        for mode in ('dataset','random','onehot'):
            feature_modes[d,mode]=pair(get('ablation_feature_modes_20260930_1625.json',f's2cag-i:10-naive-feat:{mode}',d),
                get('ablation_feature_modes_20260930_1625.json',f's2cag-i:10-L:3-r:1-agg:norm-gpu-feat:{mode}',d))
    table('feature_ablation_rows.tex',[paired_row(d,p,(mode,)) for (d,mode),p in feature_modes.items()])
    aggregation={}
    radius={}
    for d in ('dyn_cora','dyn_pubmed'):
        for agg in ('norm','sum'):
            aggregation[d,agg]=get('ablation_feature_aggregation_20260930_1623.json',f's2cag-i:10-L:3-r:1-agg:{agg}-gpu-feat:random',d)
        for r in range(3):
            radius[d,r]=get(['ablation_gnn_radius_light_20260930_1705.json','ablation_gnn_radius_light_add_20261002_2154.json'],f's2cag-i:10-L:3-r:{r}-agg:norm-gpu-feat:random',d)
    table('aggregation_rows.tex',[[tex(d),'mean' if agg=='norm' else 'sum', f"{r['q']:.4f}",f"{r['nmi']:.4f}",number(r['time'])] for (d,agg),r in aggregation.items()])
    table('feature_radius_rows.tex',[[tex(d),str(radius_),f"{r['q']:.4f}",f"{r['nmi']:.4f}",number(r['time'])] for (d,radius_),r in radius.items()])

    topology={}
    for d in ('dyn_cora','dyn_pubmed','arxivmath'):
        base=get(GRID,'leidenalg-naive',d)
        points=[]
        for L in range(1,5):
            for r in range(3):
                local=get(GRID,f'leidenalg-L:{L}-r:{r}-gpu',d)
                points.append(dict(L=L,r=r,**pair(base,local)))
        topology[d]=dict(base=base,points=points)
    table('topology_rows.tex',[[tex(d),str(p['L']),str(p['r']),f"{p['local']['q']:.4f}",f"{p['local']['nmi']:.4f}",number(p['local']['time']),f"{p['speedup']:.2f}"] for d,t in topology.items() for p in t['points']])
    assert all(p['speedup'] > 1 and p['dq'] < 0 for t in topology.values() for p in t['points'])
    write('topology_summary.tex',[
        'Within the complete radius/depth grid, every local configuration is faster than its same-file full baseline and has lower final modularity.',
        ' '.join(rf"For {tex(d)}, the time ratios span {min(p['speedup'] for p in t['points']):.2f}$\times$--{max(p['speedup'] for p in t['points']):.2f}$\times$." for d,t in topology.items())])
    stability = feature_seed_study(records, used, table)

    # Preserve the article's original visual grammar; update measured values only.
    v.plot_topology({d: {
        'full': {'q': t['base']['q']},
        'points': [{'level': p['L'], 'radius': p['r'], 'q': p['local']['q'],
                    'speedup': p['speedup']} for p in t['points']]
        } for d,t in topology.items()})
    long_plot = {}
    for d in ('dyn_pubmed','arxivmath'):
        p = long[d,'9:500','leidenalg']
        a,b = p['base']['series'],p['local']['series']
        gaps = [bb['modularity']-aa['modularity'] for aa,bb in zip(a,b)]
        p['trajectory_mean_dq'] = mean(gaps)
        p['trajectory_min_dq'] = min(gaps)
        long_plot[d] = {'leidenalg': {'series': {
            'base_q': [row['modularity'] for row in a],
            'local_q': [row['modularity'] for row in b],
            'base_time': [row['time'] for row in a],
            'local_time': [row['time'] for row in b]}}}
    v.plot_long_horizon(long_plot)
    v.plot_method_pipeline()

    # Original compact baseline/ComNetX table layout.
    table('backend_rows.tex', [[tex(d),mode,
        f"{p['base']['q']:.4f}/{p['local']['q']:.4f}",
        f"{p['base']['nmi']:.4f}/{p['local']['nmi']:.4f}",
        f"{number(p['base']['time'])}/{number(p['local']['time'])}",
        f"{p['speedup']:.2f}" ] for (d,mode),p in features.items()])
    long_rows=[]
    for protocol in ('9:500',):
        for d in ('dyn_pubmed','arxivmath'):
            for m,label in [('leidenalg','Leiden'),('dfleiden','DF-Leiden')]:
                p=long[d,protocol,m];a,b=p['base'],p['local']
                row=[tex(d),label,f"{a['q']:.4f}/{b['q']:.4f}",
                    f"{a['nmi']:.4f}/{b['nmi']:.4f}",
                    f"{number(a['time'])}/{number(b['time'])}",f"{p['speedup']:.2f}"]
                long_rows.append(' & '.join(row)+r' \\')
    write('long_horizon_rows.tex',long_rows+[r'\bottomrule'])
    feature_rows=[]
    for mode,name in [('dataset','dataset features'),('random','random features'),('onehot','one-hot input')]:
        for key,label in [('base','Full'),('local','ComNetX')]:
            cells=[label+', '+name]
            for d in ('dyn_cora','dyn_pubmed'):
                r=feature_modes[d,mode][key]
                cells.append(f"{r['q']:.4f}/{r['nmi']:.4f}/{number(r['time'])}")
            feature_rows.append(cells)
    table('feature_ablation_rows.tex',feature_rows)
    def clean(x):
        if isinstance(x,dict): return {str(k):clean(val) for k,val in x.items()}
        if isinstance(x,list): return [clean(val) for val in x]
        return x
    from extended_results import generate_extended
    extended = generate_extended(get, pair, table, write, records, long)
    from structural_results import generate_structural
    structural = generate_structural(ROOT, JOURNAL, info, table)
    from confirmatory_results import generate_confirmatory
    confirmatory = generate_confirmatory(ROOT, JOURNAL, table)
    evidence=dict(bundle=str(BUNDLE.relative_to(ROOT)),source_sha256=files,record_count=len(records),
        selected_ids=sorted(used),not_selected_ids=sorted(set(by_id)-used),
        excluded_records=excluded,records=records,
        selection_policy=dict(short='Main file for Cora/ACM/Citeseer; same-file grid pairs for PubMed/arxivmath; no patent Leiden pair.',
            long='Same-file expanded protocol studies; figure 3 uses 9:500. Earlier 999:50/100 runs remain separate.',
            additions='Fill absent keys; never concatenate update trajectories.',
            exclusions='Native DF-Leiden graph-growth trajectories are not admissible; '
                'the initial bin was delivered twice. Original records are retained.',
            additional_s2cag='Late subdivision/window/growth records have incomplete execution provenance. '
                'Keep as archive diagnostics; do not pool with the main feature comparison, '
                'invent a paired full baseline, or infer controlled parameter effects.',
            seeds=SEED_SELECTION),
        short=short,long=long,features=features,topology=topology,stability=stability,
        extended=extended,structural_diagnostics=structural,
        s2cag_confirmatory=confirmatory)
    v.write_text(JOURNAL/'analysis/validated_results.json',json.dumps(clean(evidence),indent=2,ensure_ascii=False))
    print(f'Validated {len(records)} trajectories in {len(files)} files; selected {len(used)} records. Historical measurements excluded.')
    print('Short ratios:',{d:round(p['speedup'],2) for d,p in short.items()})
