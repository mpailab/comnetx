"""Paired protocol controls and 500-update evidence for the journal article."""
from pathlib import Path
import csv
from statistics import mean
from current_results import tex

HERE = Path(__file__).resolve().parent
LEIDEN = 'leidenalg_20261002_2221.json'
DF = 'dfleiden_20261002_2213.json'
FEATURE = 's2cag-smart_20261003_0244.json'
GROWTH = 'main_topology_10b_20261003_0247.json'
GROWTH_FEATURE = 'main_gnn_feature_10b_20261003_0251.json'


def generate_extended(get, pair, table, write, records, long):
    def time(x):
        return f'{x:.3f}' if x < 100 else f'{x:.1f}'

    def cells(p):
        a, b = p['base'], p['local']
        return [f"{a['q']:.4f}/{b['q']:.4f}",
                f"{a['nmi']:.4f}/{b['nmi']:.4f}",
                f"{time(a['time'])}/{time(b['time'])}", f"{p['speedup']:.2f}"]

    batch = {}
    rows = []
    feature_rows = []
    for d, tail in [('dyn_pubmed', 44), ('arxivmath', 799)]:
        for q in (5, 10, 20, 40, 80, 160, 320):
            proto = f'999:{q}'
            l = pair(get(LEIDEN, 'leidenalg-naive', d, proto),
                     get(LEIDEN, 'leidenalg-L:3-r:1-gpu', d, proto))
            f = pair(get(DF, 'dfleiden-dynamic', d, proto),
                     get(DF, 'dfleiden-L:3-r:1-gpu', d, proto))
            s = get(FEATURE, 's2cag-i:10-L:3-r:1-agg:norm-gpu-feat:random', d, proto)
            count = min(tail, q)
            assert count == l['base']['updates'] == f['base']['updates'] == s['updates']
            lo, hi = tail // count, (tail + count - 1) // count
            edges = str(lo) if lo == hi else f'{lo}--{hi}'
            rows.append([tex(d), str(q), str(count), edges,
                         f"{l['dq']:+.4f}", f"{l['speedup']:.2f}",
                         f"{f['dq']:+.4f}", f"{f['speedup']:.2f}"])
            # This separate execution contains local S2CAG runs only. It has
            # no matched full run and must not be rendered as Delta Q/speedup.
            feature_rows.append([tex(d), str(q), str(count), f"{s['q']:.4f}",
                                 f"{s['nmi']:.4f}", time(s['time'])])
            batch[d, q] = dict(leiden=l, df=f, s2cag=s, tail_edges=tail,
                                min_edges_per_update=lo, max_edges_per_update=hi)
    table('batch_granularity_rows.tex', rows)
    table('s2cag_granularity_rows.tex', feature_rows)

    growth = {}
    growth_rows = []
    datasets = ('dyn_cora', 'dyn_acm', 'dyn_citeseer', 'patent', 'dyn_pubmed', 'arxivmath')
    # Native DF-Leiden growth runs delivered the initial bin twice. Keep the
    # original records in the ledger, but do not use them as comparisons.
    for method, mode, name in [('leidenalg', 'naive', 'Leiden')]:
        for d in datasets:
            a = get(GROWTH, f'{method}-{mode}', d, '10')
            b = get(GROWTH, f'{method}-L:3-r:1-gpu', d, '10', optional=True)
            if b is None:
                growth[d, method] = dict(base=a, local=None)
                continue
            p = pair(a, b)
            growth[d, method] = p
            growth_rows.append([tex(d), *cells(p)])
    table('growth_rows.tex', growth_rows)
    # Keep full DF-Leiden controls as separate evidence, not a native-stream ratio.
    df_full = {d: get(GROWTH, 'dfleiden-naive', d, '10') for d in datasets}

    growth_features = {}
    for mode in ('dataset', 'random'):
        for d in datasets:
            a = get(GROWTH_FEATURE, f's2cag-i:10-naive-feat:{mode}', d, '10')
            b = get(GROWTH_FEATURE, f's2cag-i:10-L:3-r:1-agg:norm-gpu-feat:{mode}', d,
                    '10', optional=True)
            growth_features[d, mode] = dict(base=a, local=b)
            if b:
                # This initialization control yields identical quality across calls.
                assert abs(a['q'] - b['q']) < 1e-10
                assert abs(a['nmi'] - b['nmi']) < 1e-10
    for d in datasets:
        assert growth_features[d, 'dataset']['base']['q'] == growth_features[d, 'random']['base']['q']
        assert growth_features[d, 'dataset']['base']['nmi'] == growth_features[d, 'random']['base']['nmi']

    # Wider-window controls keep the original baseline/ComNetX table grammar.
    table('window_rows.tex', [[tex(d), name, *cells(long[d, '99:50', method])]
          for d in ('dyn_pubmed', 'arxivmath')
          for method, name in [('leidenalg', 'Leiden'), ('dfleiden', 'DF-Leiden')]])
    feature_windows = {}
    rows = []
    for d in ('dyn_pubmed', 'arxivmath'):
        for proto in ('99:50', '9:500'):
            s = get(FEATURE, 's2cag-i:10-L:3-r:1-agg:norm-gpu-feat:random', d, proto)
            feature_windows[d, proto] = s
            rows.append([tex(d), '$' + proto.replace(':', r'{:}') + '$',
                         f"{s['q']:.4f}", f"{s['nmi']:.4f}", time(s['time'])])
    table('feature_window_rows.tex', rows)

    trajectory = {}
    for d in ('dyn_pubmed', 'arxivmath'):
        p = long[d, '9:500', 'leidenalg']
        gaps = [b['modularity'] - a['modularity']
                for a, b in zip(p['base']['series'], p['local']['series'])]
        trajectory[d] = dict(mean_gap=mean(gaps), min_gap=min(gaps),
                             min_gap_batch=gaps.index(min(gaps)) + 1, max_gap=max(gaps))
        assert len(gaps) == 500
        assert max(abs(g) for g in gaps) < 0.008

    # A flat audit ledger permits independent recalculation without LaTeX parsing.
    with (HERE / 'measurement_ledger.csv').open('w', newline='') as out:
        names = ['file', 'method', 'stored_dataset', 'protocol', 'updates', 'q', 'nmi', 'time']
        writer = csv.DictWriter(out, fieldnames=names, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(records)
    return dict(batch_granularity=batch, growth=growth, growth_df_full=df_full,
                growth_features=growth_features, feature_windows=feature_windows,
                long_trajectory=trajectory)
