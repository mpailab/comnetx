"""Independent arithmetic, algebra, citation, and source-integrity checks.

Run with a Python environment containing numpy. No measurements are rerun.
The optimizer's separate unit suite checks the actual hierarchy implementation.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
JOURNAL = ROOT / 'journal/ieee-access'


def partitions(n):
    if n == 0:
        yield []
        return
    def walk(a):
        if len(a) == n:
            yield a
        else:
            for x in range(max(a, default=-1) + 2):
                yield from walk(a + [x])
    yield from walk([0])


def modularity(a, c, gamma=1):
    w = a.sum()
    if w == 0:
        return 0.0
    c = np.asarray(c)
    return ((a / w - gamma * np.outer(a.sum(1), a.sum(0)) / w**2)
            * (c[:, None] == c[None, :])).sum()


def check_algebra():
    rng = np.random.default_rng(20261007)
    quotient_checks = boundary_checks = optimum_checks = 0
    for symmetric in (False, True):
        for _ in range(20):
            a = rng.integers(0, 8, (7, 7)).astype(float)
            a[rng.random(a.shape) < .4] = 0
            if symmetric:
                a = a + a.T
            u = a[:4, :4]
            w, wu = a.sum(), u.sum()
            assert wu > 0
            groups = np.array([0, 0, 1, 2])
            p = np.eye(3)[groups].T
            quotient = p @ u @ p.T
            for gamma in (0., .5, 1., 2.):
                for z in partitions(3):
                    assert abs(modularity(quotient, z, gamma)
                               - modularity(u, np.asarray(z)[groups], gamma)) < 1e-12
                    quotient_checks += 1
                outside = np.array([8, 8, 9])
                fout, lout = [], []
                bout, binn = a[:4, 4:].sum(), a[4:, :4].sum()
                bp = gamma * wu * (w - wu) / w**2
                bm = gamma * (wu * (bout + binn) + bout * binn) / w**2
                null = a / w - gamma * np.outer(a.sum(1), a.sum(0)) / w**2
                kout = (null[4:, 4:] * (outside[:, None] == outside[None, :])).sum()
                for z in partitions(4):
                    z = np.asarray(z)
                    full = modularity(a, np.r_[z, outside], gamma) - kout
                    local = wu / w * modularity(u, z, gamma)
                    term1 = term2 = 0.
                    for label in np.unique(z):
                        idx = np.flatnonzero(z == label)
                        x = u[idx, :].sum(); y = u[:, idx].sum()
                        pp = a[idx, 4:].sum(); qq = a[4:, idx].sum()
                        term1 += x * y
                        term2 += x * qq + y * pp + pp * qq
                    formula = gamma / w**2 * ((w-wu)/wu * term1 - term2)
                    assert abs(full - local - formula) < 1e-12
                    assert -bm - 1e-12 <= formula <= bp + 1e-12
                    fout.append(full); lout.append(local)
                    boundary_checks += 1
                gap = max(fout) - fout[int(np.argmax(lout))]
                assert -1e-12 <= gap <= bp + bm + 1e-12
                optimum_checks += 1
    return dict(quotient_checks=quotient_checks, boundary_checks=boundary_checks,
                restricted_optimum_checks=optimum_checks)


def main():
    evidence = json.loads((JOURNAL/'analysis/validated_results.json').read_text())
    frozen = json.loads((JOURNAL/'analysis/measurement_manifest.json').read_text())
    assert evidence['source_sha256'] == frozen['source_sha256']
    for file, sha in evidence['source_sha256'].items():
        assert hashlib.sha256((ROOT/evidence['bundle']/file).read_bytes()).hexdigest() == sha
    for file, sha in frozen['confirmatory_source_sha256'].items():
        assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest() == sha
    confirmatory_provenance = json.loads(subprocess.check_output([
        sys.executable, str(ROOT / 'scripts/paper/export_s2cag_provenance.py'),
        '--verify-public',
        str(ROOT / 'results/ieee-access-2026-4/s2cag-paired-20261105/provenance'),
    ], text=True))
    assert confirmatory_provenance['status'] == 'passed'
    assert confirmatory_provenance['paired_executions'] == 20 and confirmatory_provenance['update_records'] == 300
    assert confirmatory_provenance['summary_reconstructed'] and confirmatory_provenance['repeated_label_trajectories_equal']
    initial_partition = json.loads(subprocess.check_output([
        sys.executable, str(ROOT / 'scripts/paper/check_s2cag_initial_partition.py'),
    ], text=True))
    repeated = evidence['s2cag_confirmatory']
    original = json.loads((ROOT/repeated['source']).read_text())
    repeated_pairs = 0
    for key, cell in original['cells'].items():
        observations = cell['paired_repeats']
        assert len(observations) == cell['repetitions'] == 5
        target = repeated['cells'][key]
        for p in observations:
            assert p['updates'] == int(target['protocol'].split(':')[1])
            assert p['final'] == target['final']
            assert np.isclose(p['delta_q'], p['final']['local']['modularity'] - p['final']['full']['modularity'])
            assert np.isclose(p['delta_nmi'], p['final']['local']['nmi'] - p['final']['full']['nmi'])
            repeated_pairs += 1
        for timer, stats in target['timings'].items():
            full = np.array([p['time']['full'][timer] for p in observations])
            local = np.array([p['time']['local'][timer] for p in observations])
            ratios = full / local
            for mode, values in [('full', full), ('local', local)]:
                assert np.isclose(values.mean(), stats[mode]['mean'], rtol=1e-12)
                assert np.isclose(values.std(ddof=1), stats[mode]['sample_sd'], rtol=1e-12)
            assert np.isclose(np.median(ratios), stats['speedup']['median'], rtol=1e-12)
            assert np.allclose(ratios, [p['speedup'][timer] for p in observations], rtol=1e-12)
    assert repeated_pairs == repeated['paired_executions'] == 20
    count = 0
    def visit(item):
        nonlocal count
        if isinstance(item, dict):
            if 'speedup' in item and 'base' in item and 'local' in item:
                a, b = item['base'], item['local']
                assert a['updates'] == b['updates'] == len(a['series']) == len(b['series'])
                ta = sum(x['time'] for x in a['series'])
                tb = sum(x['time'] for x in b['series'])
                assert abs(ta/tb - item['speedup']) < 1e-10
                assert abs(b['q']-a['q']-item['dq']) < 1e-12
                assert abs(b['nmi']-a['nmi']-item['dnmi']) < 1e-12
                count += 1
            for value in item.values(): visit(value)
        elif isinstance(item, list):
            for value in item: visit(value)
    visit(evidence)
    source = (JOURNAL/'main.tex').read_text()
    bibliography = (JOURNAL/'references.bib').read_text()
    entries = re.findall(r'^@\w+\{\s*([^,]+),', bibliography, re.M)
    assert len(entries) == len(set(entries)), 'Duplicate bibliography keys'
    citations = re.findall(r'\\cite\{([^}]+)\}', source)
    cited_keys = {key.strip() for group in citations for key in group.split(',')}
    assert cited_keys <= set(entries), cited_keys - set(entries)
    assert {'Rosvall2008MapEquation', 'Arenas2007ModularityReduction',
            'Sahu2025DynamicLeiden', 'Sahu2026TrackingLeiden'} <= cited_keys
    # Metadata assertions for the source corrections identified in the review.
    corrected_dois = {'Rosvall2008MapEquation': '10.1073/pnas.0706851105',
                      'Gkartzios2025Fair': '10.1109/ICDM65498.2025.00036',
                      'Arenas2007ModularityReduction': '10.1088/1367-2630/9/6/176',
                      'Sahu2025DynamicLeiden': '10.1109/SCI68648.2025.11333864',
                      'Sahu2026TrackingLeiden': '10.1145/3806645.3807601'}
    for key, doi in corrected_dois.items():
        entry = re.search(r'^@\w+\{' + key + r',.*?(?=^@|\Z)',
                          bibliography, re.M | re.S).group()
        match = re.search(r'\bdoi\s*=\s*\{([^}]+)\}', entry, re.I)
        assert match and match[1].lower() == doi.lower(), key
    excluded = set(evidence['excluded_records'])
    assert len(excluded) == 6 and not (excluded & set(evidence['selected_ids']))
    for record in evidence['records']:
        if record['id'] in excluded:
            assert record['method'] == 'dfleiden-dynamic' and record['protocol'] == '10'
        else:
            assert abs(record['series'][-1]['modularity'] - record['q']) < 1e-6
    assert all('dfleiden' not in key for key in evidence['extended']['growth'])
    structural = evidence['structural_diagnostics']
    assert hashlib.sha256((ROOT/structural['source']).read_bytes()).hexdigest() == structural['sha256']
    provenance_path = ROOT/Path(structural['source']).parent/'provenance.json'
    provenance = json.loads(provenance_path.read_text())
    assert provenance['profile_sha256'] == structural['sha256']
    for path, sha in provenance['initial_hierarchy_sha256'].items():
        assert hashlib.sha256((provenance_path.parent/path).read_bytes()).hexdigest() == sha
    labels = re.findall(r'\\label\{([^}]+)\}', source)
    assert len(labels) == len(set(labels))
    refs = re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', source)
    assert set(refs) <= set(labels)
    for file in re.findall(r'\\input\{([^}]+)\}', source):
        assert (JOURNAL/file).is_file(), file
    for file in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}', source):
        assert (JOURNAL/'figures'/file).is_file(), file
    for d in ('dyn_pubmed','arxivmath'):
        p = evidence['long'][str((d,'9:500','leidenalg'))]
        assert len(p['base']['series']) == len(p['local']['series']) == 500
        ct1 = ct2 = 0.
        for a,b in zip(p['base']['series'],p['local']['series']):
            assert abs(a['modularity']-b['modularity']) < .008
            ct1 += a['time']; ct2 += b['time']
            assert ct1/ct2 > 1
    forbidden = ('label-free', 'parent-quotient updates', '430.11', '44--100')
    assert not any(x in source for x in forbidden)
    assert r'\corresp{Corresponding author: Grigoriy Bokov (e-mail: grigoriy.bokov@math.msu.ru).}' in source
    report = dict(algebra=check_algebra(), checked_pairs=count,
                  confirmatory_pairs_checked=repeated_pairs,
                  confirmatory_provenance=confirmatory_provenance,
                  frozen_initial_partition=initial_partition,
                  original_measurement_files_unchanged=len(evidence['source_sha256']),
                  excluded_native_growth_trajectories=len(excluded),
                  structural_diagnostic_updates=sum(d['updates'] for d in structural['datasets'].values()),
                  bibliography_entries=len(entries),
                  uncited_bibliography_entries=sorted(set(entries)-cited_keys),
                  corrected_doi_checks=len(corrected_dois),
                  cited_references=len(cited_keys), citation_groups=len(citations),
                  labels=len(labels), references=len(refs),
                  manuscript_sha256=hashlib.sha256(source.encode()).hexdigest(),
                  bibliography_sha256=hashlib.sha256(bibliography.encode()).hexdigest())
    (JOURNAL/'analysis/submission_audit_results.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
