"""Validate separately collected graph-size diagnostics and generate their table.

These CPU executions are not timing replications of the archived GPU study.
Only graph dimensions enter the manuscript.
"""
import hashlib
import json
from statistics import mean
from current_results import tex


def generate_structural(root, journal, info, table):
    path = root / 'results/ieee-access-2026-3/structural-diagnostics/scope-sizes.json'
    payload = json.loads(path.read_text())
    assert payload['status'] == 'completed' and not payload['errors']
    parameters = payload['parameters']
    assert parameters['batches'] == ['999:10']
    assert parameters['methods'] == ['leidenalg']
    assert parameters['variants'] == ['full']
    assert parameters['smart_depth'] == 3 and parameters['smart_radius'] == 1
    assert not parameters['use_gpu'] and parameters['force_undirected']
    summaries, rows = {}, []
    for profile in payload['profiles']:
        dataset = profile['base_dataset']
        assert dataset not in summaries
        n = int(info[dataset]['n'])
        updates = profile['rows']
        assert profile['updates_profiled'] == len(updates) == 10
        assert profile['state_policy'] == 'persistent_variant_trajectory'
        for index, update in enumerate(updates, 1):
            assert update['batch_idx'] == index
            assert 0 < update['affected_vertices'] <= update['radius_vertices'] <= n
            assert len(update['levels']) == 3
            previous_scope = update['radius_vertices']
            for level, item in enumerate(update['levels']):
                h, k, q = (item[key] for key in
                           ('closure_vertices', 'contracted_nodes', 'contracted_edges'))
                assert item['level'] == level
                assert previous_scope <= h <= n
                assert 0 < k <= h and 0 <= q <= k * k
                if level == 0:
                    assert k >= update['radius_vertices']
                previous_scope = h
        result = dict(n=n, updates=len(updates),
                      mean_endpoints=mean(r['affected_vertices'] for r in updates),
                      mean_neighborhood=mean(r['radius_vertices'] for r in updates),
                      # Count equality from separately recorded levels before
                      # averaging, so rounded table cells cannot hide a mismatch.
                      equal_upper_pass_sizes=sum(
                          all(r['levels'][1][key] == r['levels'][2][key]
                              for key in ('closure_vertices', 'contracted_nodes',
                                          'contracted_edges'))
                          for r in updates),
                      levels=[])
        for level in range(3):
            summary = {}
            for key in ('closure_vertices', 'contracted_nodes', 'contracted_edges'):
                values = [r['levels'][level][key] for r in updates]
                summary[key] = dict(mean=mean(values), min=min(values), max=max(values))
            result['levels'].append(summary)
        summaries[dataset] = result
        h = result['levels'][0]['closure_vertices']['mean']
        k = result['levels'][0]['contracted_nodes']['mean']
        q = result['levels'][0]['contracted_edges']['mean']
        # Merge equal columns only after checking every independent raw record.
        assert result['equal_upper_pass_sizes'] == len(updates)
        rows.append([tex(dataset),
                     f"{result['mean_neighborhood']:,.1f}",
                     f'{h:,.1f} ({100*h/n:.1f}\\%)',
                     f'{k:,.1f} ({100*k/n:.2f}\\%)', f'{q:,.1f}',
                     f"{result['levels'][1]['contracted_nodes']['mean']:,.1f}"])
    assert set(summaries) == {'dyn_cora', 'dyn_pubmed', 'arxivmath'}
    table('structural_rows.tex', rows)
    return dict(source=str(path.relative_to(root)),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                interpretation='Separate CPU graph-size diagnostics; no timing ratios.',
                datasets=summaries)
