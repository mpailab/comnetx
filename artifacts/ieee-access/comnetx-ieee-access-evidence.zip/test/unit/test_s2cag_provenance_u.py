"""Portable provenance checks with synthetic records; no detector is imported."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import zipfile

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[2]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


exporter = load_module('s2cag_exporter_under_test', ROOT/'scripts/paper/export_s2cag_provenance.py')
fixture_module = load_module('paired_fixture_for_provenance', ROOT/'test/unit/test_s2cag_pairs_u.py')


@pytest.fixture
def exported_case(tmp_path):
    raw = tmp_path/'raw'
    raw.mkdir()
    raw, full, local, campaign = fixture_module.paired_case.__wrapped__(raw)
    initial_path = raw/'initial/shared.npz'
    with np.load(initial_path, allow_pickle=False) as archive:
        hierarchy = archive['hierarchy']
    private_environment = {'executable':'/scratch/private-user/venv/bin/python',
                           'blas':[{'filepath':'/scratch/private-user/venv/lib/libblas.so',
                                    'num_threads':1}], 'platform':'synthetic platform'}
    initial = deepcopy(full['initial'])
    initial.update(hierarchy_sha256=exporter.tensor_hash(hierarchy),
                   fine_partition_sha256=exporter.tensor_hash(hierarchy[0]),
                   initial_graph_sha256=full['input']['batches'][0],
                   community_counts=[2,2,2], environment=deepcopy(private_environment))
    runner = fixture_module.runner
    runner.write_json(initial_path.with_suffix('.json'), initial)
    prepared_path = raw/'prepared'/(full['job']['cell_id']+'.json')
    prepared = runner.read_json(prepared_path)
    prepared['initial'] = initial
    runner.write_json(prepared_path, prepared)
    for result in (full, local):
        result['initial'] = initial
        result['environment'].update(private_environment)
        for row in result['rows']:
            with np.load(raw/row['label_file'], allow_pickle=False) as archive:
                row['label_sha256'] = exporter.tensor_hash(archive['labels'])
        runner.write_json(raw/'pairs'/result['job']['pair_id']/(result['mode']+'.json'), result)
    runner.summarize(raw)
    received = raw.with_suffix('.zip')
    with zipfile.ZipFile(received, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in raw.rglob('*'):
            if path.is_file():
                archive.write(path, raw.name+'/'+path.relative_to(raw).as_posix())
    before = {p.relative_to(raw).as_posix():exporter.digest(p) for p in raw.rglob('*') if p.is_file()}
    public = tmp_path/'public'
    result = exporter.export(raw, public)
    return raw, public, before, result


def test_export_is_private_portable_deduplicated_and_does_not_change_raw(exported_case):
    raw, public, before, result = exported_case
    assert result['summary_reconstructed'] is True
    assert result['mapped_npz_files'] == 5
    assert result['unique_npz_objects'] == 3
    assert result['label_files'] == 4
    assert {p.relative_to(raw).as_posix():exporter.digest(p) for p in raw.rglob('*') if p.is_file()} == before
    assert exporter.verify_public(public) == result
    manifest = exporter.read_json(public/exporter.MANIFEST)
    assert not (public/'execution-sources.zip').exists()
    assert not (public/'paths.json').exists()
    assert not (public/'jobs').exists()
    for path in public.rglob('*.json'):
        assert b'/scratch/' not in path.read_bytes()
    name = next(n for n in manifest['json_files'] if n.endswith('/full.json'))
    metadata = manifest['json_files'][name]
    assert metadata['original_sha256'] == exporter.digest(raw/name)
    assert '/environment/executable' in metadata['changed_json_pointers']
    assert '/initial/environment/blas/0/filepath' in metadata['changed_json_pointers']
    exported = exporter.read_json(public/name)
    original = exporter.read_json(raw/name)
    assert exported['rows'] == original['rows']
    assert exported['environment']['executable'] == 'python'
    assert exported['environment']['blas'][0]['filepath'] == 'libblas.so'
    assert exported['environment']['platform'] == original['environment']['platform']


def test_changed_npz_object_is_rejected(exported_case):
    _, public, _, _ = exported_case
    obj = next((public/'objects').glob('*.npz'))
    with obj.open('ab') as stream:
        stream.write(b'tampered')
    with pytest.raises(ValueError, match='NPZ hash mismatch'):
        exporter.verify_public(public)


def test_self_consistent_manifest_cannot_hide_forged_summary(exported_case):
    _, public, _, _ = exported_case
    summary = exporter.read_json(public/'paired-summary.json')
    next(iter(summary['cells'].values()))['mean_delta_q'] += 0.1
    data = exporter.json_bytes(summary)
    (public/'paired-summary.json').write_bytes(data)
    manifest = exporter.read_json(public/exporter.MANIFEST)
    manifest['json_files']['paired-summary.json']['exported_sha256'] = exporter.sha(data)
    (public/exporter.MANIFEST).write_bytes(exporter.json_bytes(manifest))
    with pytest.raises(ValueError, match='Reconstructed summary differs'):
        exporter.verify_public(public)
