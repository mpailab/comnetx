"""Distribution checks that do not require data or optional detector packages."""
import pytest

from scripts.paper.package_ieee_access import (
    optional_stub,
    validate_member,
    verify_archive,
    write_archive,
)


@pytest.mark.parametrize(
    ("name", "contents"),
    [
        ("../secret.txt", b"text"),
        ("data/graph.json", b"{}"),
        (".venv/lib/module.py", b"text"),
        ("src/__pycache__/module.pyc", b"text"),
        ("docs/setup.md", b"local path: /" + b"Users/researcher/work"),
    ],
)
def test_archive_rejects_unsafe_or_private_inputs(name, contents):
    with pytest.raises(ValueError):
        validate_member(name, contents)


def test_archive_round_trip_is_deterministic_and_manifest_checked(tmp_path):
    files = {"src/core.py": b"pass\n", "results/run.json": b'{"q": 0.5}\n'}
    first, second = tmp_path / "one.zip", tmp_path / "two.zip"
    report = write_archive(first, files, "test")
    write_archive(second, dict(reversed(list(files.items()))), "test")
    assert first.read_bytes() == second.read_bytes()
    assert report["files"] == 2
    assert verify_archive(first)["sha256"] == report["sha256"]


def test_optional_adapter_placeholder_fails_with_actionable_reason():
    namespace = {}
    exec(optional_stub("s2cag", "s2cag"), namespace)
    with pytest.raises(ImportError, match="not distributed.*obtained separately"):
        namespace["s2cag"](object())
