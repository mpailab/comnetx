"""Static-stream replay checks using small sources with known edge order."""

import numpy as np
import pytest

from scripts.paper.prepare_static_streams import (
    apply_permutation,
    build_payloads,
    load_adgc,
    load_pubmed,
)


def test_adgc_replay_removes_loops_and_preserves_paired_update_bins(tmp_path):
    adjacency = np.array(
        [[1, 1, 0, 1], [1, 0, 0, 0], [0, 0, 1, 1], [1, 0, 1, 0]],
        dtype=np.float64,
    )
    features = np.arange(8, dtype=np.float64).reshape(4, 2)
    labels = np.array([1, 0, 1, 0], dtype=np.int32)
    np.save(tmp_path / "cora_adj.npy", adjacency)
    np.save(tmp_path / "cora_feat.npy", features)
    np.save(tmp_path / "cora_label.npy", labels)

    edges, loaded_features, loaded_labels = load_adgc("cora", tmp_path)
    np.testing.assert_array_equal(edges, [[0, 1], [0, 3], [2, 3]])
    ordered = apply_permutation(edges, np.array([2, 0, 1]))
    dynamic, attributes = build_payloads("cora", ordered, loaded_features, loaded_labels, 2)

    # The second half reverses the same edges and keeps the same coarse bins.
    # It is not independently shuffled or split into a later range of bins.
    np.testing.assert_array_equal(
        dynamic["indices"], [[2, 0, 0, 3, 1, 3], [3, 1, 3, 2, 0, 0]]
    )
    np.testing.assert_array_equal(dynamic["batch_indices"], [0, 0, 1, 0, 0, 1])
    np.testing.assert_array_equal(dynamic["values"], np.ones(6, dtype=np.float32))
    assert dynamic["seed"].tolist() == [42]
    assert dynamic["num_classes"].tolist() == [2]
    assert dynamic["batch_size_approx"].tolist() == [1]
    assert dynamic["original_source"].tolist() == ["small_graphs"]
    assert attributes["features"].dtype == np.float32
    assert attributes["labels"].dtype == np.int64
    np.testing.assert_array_equal(attributes["features"], features)
    np.testing.assert_array_equal(attributes["labels"], labels)


@pytest.mark.parametrize(
    "permutation",
    [np.array([0, 0, 2]), np.array([0, 1]), np.array([0, 1, 3]), np.array([0., 1., 2.])],
)
def test_saved_order_must_be_a_complete_integer_permutation(permutation):
    with pytest.raises(ValueError, match="complete edge permutation"):
        apply_permutation(np.array([[0, 1], [0, 2], [1, 2]]), permutation)


def test_pubmed_replay_keeps_directed_arcs_selfloops_and_label_mapping(tmp_path):
    np.savez(
        tmp_path / "attrs.npz",
        format=np.array(b"csr"),
        shape=np.array([2, 3]),
        indptr=np.array([0, 2, 3], dtype=np.int32),
        indices=np.array([0, 2, 1], dtype=np.int32),
        data=np.array([1.25, 0.5, 2.0], dtype=np.float64),
    )
    (tmp_path / "edgelist.txt").write_text("1 1\n1 0\n0 1\n0 1\n")
    (tmp_path / "labels.txt").write_text("0 1\n1 2\n")
    edges, features, labels = load_pubmed(tmp_path)
    np.testing.assert_array_equal(edges, [[0, 1], [1, 0], [1, 1]])
    np.testing.assert_array_equal(features, [[1.25, 0, 0.5], [0, 2, 0]])
    np.testing.assert_array_equal(labels, [0, 1])
    ordered = apply_permutation(edges, np.array([2, 0, 1]))
    dynamic, _ = build_payloads("pubmed", ordered, features, labels, 2)
    np.testing.assert_array_equal(dynamic["indices"], [[1, 0, 1], [1, 1, 0]])
    np.testing.assert_array_equal(dynamic["batch_indices"], [0, 0, 1])
    assert dynamic["is_directed"].tolist() == [True]
    assert dynamic["original_source"].tolist() == ["attr_graphs"]


def test_adgc_asymmetric_source_is_rejected(tmp_path):
    np.save(tmp_path / "acm_adj.npy", np.array([[0, 1], [0, 0]]))
    np.save(tmp_path / "acm_feat.npy", np.ones((2, 1)))
    np.save(tmp_path / "acm_label.npy", np.zeros(2))
    with pytest.raises(ValueError, match="not symmetric"):
        load_adgc("acm", tmp_path)


def test_more_bins_than_edges_keeps_empty_bins_without_duplicating_edges():
    dynamic, _ = build_payloads(
        "cora", np.array([[0, 1], [0, 2]]), np.ones((3, 1)), np.zeros(3), 4
    )
    np.testing.assert_array_equal(dynamic["batch_indices"], [0, 1, 0, 1])
    assert dynamic["num_batches"].tolist() == [4]
    assert dynamic["batch_size_approx"].tolist() == [0]
